package com.hotel.admin.packagebox;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.PackageDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class AdminPackageRegisterOkAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      
      PackageDTO dto = new PackageDTO();
      
      String saveFolder ="D:\\jsp_work\\Hotel_delus\\Hotel_delus\\src\\main\\webapp\\upload_images";
      
      int fileSize = 10 * 1024 * 1024;
      
      MultipartRequest multi = new MultipartRequest(
            request,       // 일반적인 request 객체
            saveFolder,    // 첨부파일이 저장될 경로
            fileSize,      // 업로드할 첨부파일의 최대 크기
            "UTF-8",      // 문자 인코딩 방식
            new DefaultFileRenamePolicy());   // 첨부파일의 이름이 같은 경우 중복이 안되게 설정
      
      
      String package_name = multi.getParameter("package_name").trim();
      String package_age = multi.getParameter("package_age").trim();
      String package_start = multi.getParameter("package_start").trim();
      String package_end = multi.getParameter("package_end").trim();
      String package_type = multi.getParameter("package_type").trim();
      String package_option = multi.getParameter("package_option").trim();
      String package_Details = multi.getParameter("package_Details").trim();
      String package_price = multi.getParameter("package_price").trim();
      
      File upload_file = multi.getFile("package_files");
      
      if(upload_file != null) {
         
         String fileName = upload_file.getName();
         
         Calendar cal = Calendar.getInstance();
         
         int year = cal.get(Calendar.YEAR);
         int month = cal.get(Calendar.MONTH) + 1;
         int day = cal.get(Calendar.DAY_OF_MONTH);
         
         String homedir = saveFolder + "/" + year + "-" + month + "-" + day;
         
         // 날짜 폴더를 만들어 보자
         File path1 = new File(homedir);
         
         if(!path1.exists()) { // 폴더가 존재하지 않는다면..
            path1.mkdir();     // 실제 폴더를 만들어 주는 메서드.
         }
         
         // 파일을 만들어 보자 => 예) 홍길동_파일명
         String reFileName = package_name + "_" + fileName;
         
         upload_file.renameTo(new File(homedir+"/"+reFileName));
         
         // 실제로 DB의 upload_file 컬럼에 들어가는 파일 이름.
         // "/2024-05-27/홍길동_파일명" 으로 저장할 예정
         String fileDBName = year +"-" + month + "-" + day + "/" + reFileName;
         
         dto.setPackage_file(fileDBName);
         
         
      }
      
      dto.setPackage_title(package_name);
      dto.setPackage_date(package_age);
      dto.setPackage_start_date(package_start);
      dto.setPackage_end_date(package_end);
      dto.setRoom_type(package_type);
      dto.setOption_type(package_option);
      dto.setPackage_cont(package_Details);
      dto.setPackage_price(package_price);
      
      HotelTotalDAO dao = HotelTotalDAO.getInstance();
      
      int check = dao.insertPackage(dto);
      
      PrintWriter out = response.getWriter();
      
      if(check > 0) {
         out.println("<script>");
         out.println("alert('자료실 업로드 게시글 추가 성공!!')");
         out.println("location.href='admin_package_list'"); // 페이지 새로 고침
         out.println("</script>");
      } else {
         out.println("<script>");
         out.println("alert('자료실 업로드 게시글 추가 실패~~~')");
         out.println("history.back()");
         out.println("</script>");
      }
      
      return null;
   }

}