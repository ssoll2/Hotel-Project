package com.hotel.model;

public class ReservateCancelRoomDTO {
	
	public String getReservate_cancel_no() {
		return reservate_cancel_no;
	}
	public void setReservate_cancel_no(String reservate_cancel_no) {
		this.reservate_cancel_no = reservate_cancel_no;
	}
	public String getReservate_cancel_date() {
		return reservate_cancel_date;
	}
	public void setReservate_cancel_date(String reservate_cancel_date) {
		this.reservate_cancel_date = reservate_cancel_date;
	}
	public boolean isReservate_cancel_status() {
		return reservate_cancel_status;
	}
	public void setReservate_cancel_status(boolean reservate_cancel_status) {
		this.reservate_cancel_status = reservate_cancel_status;
	}
	public String getReservate_room() {
		return reservate_room;
	}
	public void setReservate_room(String reservate_room) {
		this.reservate_room = reservate_room;
	}
	public String getReservate_cancel_package_merchandise_no() {
		return reservate_cancel_package_merchandise_no;
	}
	public void setReservate_cancel_package_merchandise_no(String reservate_cancel_package_merchandise_no) {
		this.reservate_cancel_package_merchandise_no = reservate_cancel_package_merchandise_no;
	}
	
	private String reservate_cancel_no;
	private String reservate_cancel_date;
	private boolean reservate_cancel_status;
	private String reservate_room;
	private String reservate_cancel_package_merchandise_no;

}
