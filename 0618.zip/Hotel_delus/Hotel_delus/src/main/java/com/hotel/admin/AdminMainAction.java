package com.hotel.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.QnaBoardDTO;
import com.hotel.model.ReservateDTO;

public class AdminMainAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      
      HotelTotalDAO dao = HotelTotalDAO.getInstance();
      
      List<HotelUserDTO> list = dao.getHotelUserList();
      List<ReservateDTO> reservateList = dao.getReservateList();
      List<QnaBoardDTO> qnalist = dao.getQnaBoardList();
      
      int NewCount = dao.NewReservateCount();
      int CheckinCount = dao.CheckinCount();
      int CheckoutCount = dao.CheckoutCount();
      int QnaCount = dao.QnaCount();
      int NewQnaCount = dao.NewQnaCount();
      
      request.setAttribute("List", list);
      request.setAttribute("Qnalist",qnalist);
      request.setAttribute("rsList", reservateList);
      request.setAttribute("NewCount", NewCount);
      request.setAttribute("CheckInCount", CheckinCount);
      request.setAttribute("CheckOutCount", CheckoutCount);
      request.setAttribute("QnaCount", QnaCount);
      request.setAttribute("NewQnaCount", NewQnaCount);
      
      ActionForward forward = new ActionForward();

      forward.setPath("/WEB-INF/views/admin/admin_main.jsp");

      return forward;
      
      
   }

}
