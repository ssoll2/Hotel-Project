package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.AdminDTO;
import com.hotel.model.HotelTotalDAO;

public class AdminModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String admin_no = request.getParameter("admin_no").trim();
		String admin_name = request.getParameter("admin_name").trim();
		String admin_major = request.getParameter("admin_major").trim();
		String admin_id = request.getParameter("admin_id").trim();
		String admin_password = request.getParameter("admin_password").trim();
		String admin_phone = request.getParameter("admin_phone");
		
		int page = Integer.parseInt(request.getParameter("page").trim());
		
		AdminDTO dto = new AdminDTO();
		
		dto.setAdmin_no(admin_no);
		dto.setAdmin_name(admin_name);
		dto.setAdmin_major(admin_major);
		dto.setAdmin_id(admin_id);
		dto.setAdmin_password(admin_password);
		dto.setAdmin_phone(admin_phone);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.AdminUpdate(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('수정 성공')");
			out.println("location.href='admin_content?no="+admin_no+"&page="+page+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('수정 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
	
		
		
		
		// TODO Auto-generated method stub
		return null;
	}

}
