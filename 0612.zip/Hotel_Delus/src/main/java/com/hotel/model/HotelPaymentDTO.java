package com.hotel.model;

public class HotelPaymentDTO {

}
