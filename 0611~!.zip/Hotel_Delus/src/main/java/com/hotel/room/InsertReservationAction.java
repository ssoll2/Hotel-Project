package com.hotel.room;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.ReservateDTO;

public class InsertReservationAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
		StringBuilder jsonStr = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			jsonStr.append(line);
		}
		reader.close();

		JSONParser parser = new JSONParser();

		JSONObject jsonData = null;
		try {
			jsonData = (JSONObject) parser.parse(jsonStr.toString());
		} catch (ParseException e) {
			e.printStackTrace();
		}

		String startDate = (String) jsonData.get("startDate");
		String endDate = (String) jsonData.get("endDate");
		int adult = (int) jsonData.get("AdultCount");
	    int children = (int) jsonData.get("ChildrenCount");
		
	    int total_people = (adult + children);
	    
	    
		ReservateDTO dto = new ReservateDTO();

		dto.setReservate_headcount(total_people);
		dto.setCheck_in_date(startDate);
		dto.setCheck_in_hour("15:00");
		dto.setCheck_out_date(endDate);
		dto.setCheck_out_hour("11:00");

		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		int result = dao.insertReservation(dto);

		if (result > 0) {
			System.out.println("start Date: " + startDate);
			System.out.println("end Date: " + endDate);
			System.out.println("Headcount:" + total_people );

			request.setAttribute("startDate", startDate);
			request.setAttribute("endDate", endDate);
			request.setAttribute("total_people", total_people);

			ActionForward forward = new ActionForward();

			forward.setPath("/WEB-INF/views/room/reservation_list.jsp");

			return forward;
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('예약에 실패했습니다!')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}

		return null;
	}
}
