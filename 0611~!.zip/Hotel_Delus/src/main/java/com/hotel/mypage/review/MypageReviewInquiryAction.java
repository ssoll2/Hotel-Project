package com.hotel.mypage.review;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.PurchaseHistoryDTO;

public class MypageReviewInquiryAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int rowsize = 3; // 한 페이지당 보여질 리스트 수
		int block = 3; // 하단에 보여질 페이지 최대 수
		int totalRecord = 0; // DB 상의 전체 게시물 수
		int allPage = 0; // 전체 페이지 수
		int page = 0; // 현재 페이지 변수

		if (request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page").trim());
		} else {
			page = 1; // 처음으로 "내 예약 방 리스트" 페이지에 접속한 경우
		}

		// 페이지별 시작번호와 끝번호
		int startNo = (page * rowsize) - (rowsize - 1);
		int endNo = (page * rowsize);

		// 페이지별 시작 블럭과 끝 블럭
		int startBlock = (((page - 1) / block) * block) + 1;
		int endBlock = (((page - 1) / block) * block) + block;

		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		HttpSession session = request.getSession(false);
		HotelUserDTO user = (HotelUserDTO) session.getAttribute("dto");

		if (user == null) {
			ActionForward forward = new ActionForward();
			forward.setRedirect(true);
			forward.setPath("/Hotel_Delus/user_login");
			return forward;
		}

		String userNo = user.getHotel_user_no();
		totalRecord = dao.getPurchaseHistoryCount(userNo);
		allPage = (int) Math.ceil(totalRecord / (double) rowsize);

		System.out.println(userNo);
		
		if (endBlock > allPage) {
			endBlock = allPage;
		}
        List<PurchaseHistoryDTO> reservedRooms = dao.getPurchaseHistoryUser(userNo, page, rowsize);

        for(PurchaseHistoryDTO temp : reservedRooms) {
        	System.out.println(temp.getPurchase_no());
        }
        
        request.setAttribute("page", page);
		request.setAttribute("rowsize", rowsize);
		request.setAttribute("block", block);
		request.setAttribute("totalRecord", totalRecord);
		request.setAttribute("allPage", allPage);
		request.setAttribute("startNo", startNo);
		request.setAttribute("endNo", endNo);
		request.setAttribute("startBlock", startBlock);
		request.setAttribute("endBlock", endBlock);
		request.setAttribute("roomList", reservedRooms);

	
        ActionForward forward = new ActionForward();
        forward.setRedirect(false);
        forward.setPath("/WEB-INF/views/mypage/review/room_inquiry_list.jsp");

        return forward;
    }
}