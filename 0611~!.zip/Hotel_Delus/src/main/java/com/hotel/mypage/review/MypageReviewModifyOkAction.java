package com.hotel.mypage.review;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomReviewDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class MypageReviewModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		RoomReviewDTO dto = new RoomReviewDTO();
		
		String saveFolder = "C:\\Users\\User\\Desktop\\JSP\\Hotel_Delus\\src\\main\\webapp\\upload_images";
		
		int fileSize = 10 * 1024 * 1024;
		
		 MultipartRequest multi = new MultipartRequest(
		            request,       // 일반적인 request 객체
		            saveFolder,    // 첨부파일이 저장될 경로
		            fileSize,      // 업로드할 첨부파일의 최대 크기
		            "UTF-8",      // 문자 인코딩 방식
		            new DefaultFileRenamePolicy());  
		 
		 String review_no = multi.getParameter("review_no").trim();
		 String review_writer_id = multi.getParameter("review_writer").trim();
		 String review_title = multi.getParameter("review_title").trim();
		 String review_cont = multi.getParameter("review_cont").trim();
		 String review_purchase_no = multi.getParameter("review_purchase_no").trim();
		 
		 File review_file = multi.getFile("review_file");
		 
		 if(review_file != null) {
				String fileName = review_file.getName();
				System.out.println("fileName = " + fileName);
				
				Calendar cal = Calendar.getInstance();
				int year = cal.get(Calendar.YEAR);
				int month = cal.get(Calendar.MONTH) + 1;
				int day = cal.get(Calendar.DAY_OF_MONTH);
				
				String homedir = saveFolder + "/" + year + "-" + month + "-" + day;
				
				File path = new File(homedir);
				
				if(!path.exists()) {
					path.mkdir();
				}
				String reFileName = "review_" + fileName;
				
				review_file.renameTo(new File(homedir + "/" + reFileName));
				
				String fileDBName = year + "-" + month + "-" + day + "/" + reFileName;
				
				dto.setRoom_review_file(fileDBName);
				
		 }
		 
		 dto.setRoom_review_no(review_no);
		 dto.setRoom_review_writer_id(review_writer_id);
		 dto.setRoom_review_title(review_title);
		 dto.setRoom_review_cont(review_cont);
		 dto.setRoom_review_purchase_no(review_purchase_no);
		 
		 HotelTotalDAO dao = HotelTotalDAO.getInstance();
		 
		 int check = dao.updateMypageReview(dto);
		 
		 PrintWriter out = response.getWriter();
			
			if(check > 0) {
				out.println("<script>");
				out.println("alert('리뷰 수정 성공')");
				out.println("location.href='my_review_list'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('리뷰 수정 실패')");
				out.println("history.back()");
				out.println("</script>");
			}
			
			
		 
		return null;
	}

}
