package com.hotel.mypage.review;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;

public class MypageReviewDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String review_no = request.getParameter("no").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.deleteMypageReview(review_no);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('리뷰 삭제 성공')");
			out.println("location.href='my_review_list'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('리뷰 삭제 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;
	}

}
