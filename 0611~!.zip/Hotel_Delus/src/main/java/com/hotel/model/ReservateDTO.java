package com.hotel.model;

import java.time.LocalDate;

public class ReservateDTO {
	private String reservate_no;        
	private String reservate_room_no; 
	private String reservate_room_price ;    
	private String reservate_user_no;   
	private int reservate_headcount;                  
	private String reservate_date;                    
	private String check_in_date;                
	private String check_in_hour;            
	private String check_out_date;        
	private String check_out_hour ;            
	private boolean payment_status;
	public String getReservate_no() {
		return reservate_no;
	}
	public void setReservate_no(String reservate_no) {
		this.reservate_no = reservate_no;
	}
	public String getReservate_room_no() {
		return reservate_room_no;
	}
	public void setReservate_room_no(String reservate_room_no) {
		this.reservate_room_no = reservate_room_no;
	}
	public String getReservate_room_price() {
		return reservate_room_price;
	}
	public void setReservate_room_price(String reservate_room_price) {
		this.reservate_room_price = reservate_room_price;
	}
	public String getReservate_user_no() {
		return reservate_user_no;
	}
	public void setReservate_user_no(String reservate_user_no) {
		this.reservate_user_no = reservate_user_no;
	}
	public int getReservate_headcount() {
		return reservate_headcount;
	}
	public void setReservate_headcount(int reservate_headcount) {
		this.reservate_headcount = reservate_headcount;
	}
	public String getReservate_date() {
		return reservate_date;
	}
	public void setReservate_date(String reservate_date) {
		this.reservate_date = reservate_date;
	}
	public String getCheck_in_date() {
		return check_in_date;
	}
	public void setCheck_in_date(String check_in_date) {
		this.check_in_date = check_in_date;
	}
	public String getCheck_in_hour() {
		return check_in_hour;
	}
	public void setCheck_in_hour(String check_in_hour) {
		this.check_in_hour = check_in_hour;
	}
	public String getCheck_out_date() {
		return check_out_date;
	}
	public void setCheck_out_date(String check_out_date) {
		this.check_out_date = check_out_date;
	}
	public String getCheck_out_hour() {
		return check_out_hour;
	}
	public void setCheck_out_hour(String check_out_hour) {
		this.check_out_hour = check_out_hour;
	}
	public boolean isPayment_status() {
		return payment_status;
	}
	public void setPayment_status(boolean payment_status) {
		this.payment_status = payment_status;
	}
	     
}
