package com.hotel.board;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.NoticeDTO;

public class NoticeListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int cnt = 0;
		
		cnt = dao.countNoticeList();
		List<NoticeDTO> list = dao.getNoticeList();
		
		request.setAttribute("cnt", cnt);
		request.setAttribute("list", list);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/board/notice.jsp");

		return forward;
		

	}

}
