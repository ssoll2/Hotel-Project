package com.hotel.room;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;


public class ChangePickReservationAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      /*
       * BufferedReader reader = new BufferedReader(new
       * InputStreamReader(request.getInputStream())); StringBuilder jsonStr = new
       * StringBuilder(); String line; while ((line = reader.readLine()) != null) {
       * jsonStr.append(line); } reader.close();
       * 
       * JSONParser parser = new JSONParser();
       * 
       * JSONObject jsonData = null; try { jsonData = (JSONObject)
       * parser.parse(jsonStr.toString()); } catch (ParseException e) {
       * e.printStackTrace(); }
       */
      // AdultCount: adultCount, ChildrenCount: childrenCount, StartDate: start_date,
      // EndDate: end_date, Total: total
	   
	  HotelTotalDAO dao = HotelTotalDAO.getInstance();
	  
	  dao.TotalReset();
	  
	  
	  
      int adult = Integer.parseInt(request.getParameter("adult"));
      int child = Integer.parseInt(request.getParameter("children"));
      int total = Integer.parseInt(request.getParameter("total"));
      
      total = adult + child;
      
      String check_in_date = request.getParameter("check_in_date");
      String check_out_date = request.getParameter("check_out_date");
      
      int DRScount = dao.DRScount(check_in_date, check_out_date);
      int DRDcount = dao.DRDcount(check_in_date, check_out_date);
      int SDRcount = dao.SDRcount(check_in_date, check_out_date);
      int PDRcount = dao.PDRcount(check_in_date, check_out_date);
      int PPRcount = dao.PPRcount(check_in_date, check_out_date);
      int SPRcount = dao.SPRcount(check_in_date, check_out_date);
      int PSRcount = dao.PSRcount(check_in_date, check_out_date);

      System.out.println("PDRcount = " + PDRcount);
       
      List<RoomInfoDTO> list = dao.getRoomInfo_res_change_List(check_in_date, check_out_date, total, 
    		  DRScount, DRDcount, SDRcount, PDRcount, PPRcount, SPRcount, PSRcount);
       
          
      request.setAttribute("List", list);
      request.setAttribute("adult", adult); 
      request.setAttribute("children", child);
      request.setAttribute("start_date", check_in_date);
      request.setAttribute("end_date", check_out_date);
      request.setAttribute("total", total);

       System.out.println(check_in_date);
       System.out.println(check_out_date);
       ActionForward forward = new ActionForward();
       
       forward.setPath("/WEB-INF/views/public/room/reservation_list.jsp");
       
       return forward;

   }

}
