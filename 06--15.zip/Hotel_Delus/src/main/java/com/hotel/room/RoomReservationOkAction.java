package com.hotel.room;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.ReservateDTO;

public class RoomReservationOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String room_type = request.getParameter("room_type").trim();
		
		ReservateDTO dto = new ReservateDTO();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		HttpSession session = request.getSession();

	    HotelUserDTO cont = (HotelUserDTO) session.getAttribute("dto");
	    
	    String reservate_user_no = cont.getHotel_user_no();

		int reservate_room_price = Integer.parseInt(request.getParameter("total_amount"));
		int reservate_headcount = Integer.parseInt(request.getParameter("total"));
		String check_in_date = request.getParameter("check_in_date").trim();
		String check_out_date = request.getParameter("check_out_date").trim();
		String check_in_hour = request.getParameter("check_in_time").trim();
		String check_out_hour = request.getParameter("check_out_time").trim();
		
		String room_name = dao.getRoomName(room_type);
		int reservate_room_no = dao.getRoomNum(room_name);
		String st_room_no = Integer.toString(reservate_room_no);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c1 = Calendar.getInstance();
		String date = sdf.format(c1.getTime());
		
		String reservate_no = date + st_room_no;
		
		LocalDate checkstartDate = LocalDate.parse(check_in_date);
        LocalDate checkendDate = LocalDate.parse(check_out_date);
        
		dto.setReservate_no(reservate_no);
		dto.setReservate_room_no(reservate_room_no);
		dto.setReservate_room_price(reservate_room_price);
		dto.setReservate_user_no(reservate_user_no);
		dto.setReservate_headcount(reservate_headcount);
		dto.setCheck_in_date(checkstartDate);
		dto.setCheck_in_hour(check_in_hour);
		dto.setCheck_out_date(checkendDate);
		dto.setCheck_out_hour(check_out_hour);
		
		int check = dao.ReservateInsert(dto);
		
		PrintWriter out = response.getWriter();
		
		if (check > 0) {
			out.println("<script>");
			out.println("alert('예약완료')");
			out.println("location.href='main'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('예약오류')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
