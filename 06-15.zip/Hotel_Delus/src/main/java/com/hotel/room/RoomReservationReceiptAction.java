package com.hotel.room;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;

public class RoomReservationReceiptAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String type = request.getParameter("type").trim();
		int price = Integer.parseInt(request.getParameter("price").trim());
		
		int adult = Integer.parseInt(request.getParameter("adult").trim());
		int children = Integer.parseInt(request.getParameter("children").trim());
		int total = Integer.parseInt(request.getParameter("total").trim());
		
		String startdate = request.getParameter("check_in").trim();
		String enddate = request.getParameter("check_out").trim();
		String strFormat = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(strFormat);
		try {
			Date startDate  = sdf.parse(startdate);
			Date endDate  = sdf.parse(enddate);
			
			long diffDay = (endDate.getTime() - startDate.getTime()) / (24*60*60*1000);
			
			request.setAttribute("diffDay", diffDay);
			
			int amount = price * (int)diffDay;
			
			request.setAttribute("amount", amount);
			System.out.println(price);
			System.out.println(diffDay);
			System.out.println(amount);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 HotelTotalDAO dao = HotelTotalDAO.getInstance();

	      
	       
	    List<RoomInfoDTO> list = dao.getRoomInfo_res_change_List(startdate, enddate, total);
	       
	          
	    request.setAttribute("List", list);
		request.setAttribute("type", type);
		request.setAttribute("price", price);
		request.setAttribute("start_date", startdate);
		request.setAttribute("end_date", enddate);
		request.setAttribute("adult", adult);
		request.setAttribute("children", children);
		request.setAttribute("total", total);
		
		
		ActionForward forward = new ActionForward();
	       
		forward.setPath("/WEB-INF/views/public/room/reservation_list.jsp");
	       
	    return forward;
	}

}
