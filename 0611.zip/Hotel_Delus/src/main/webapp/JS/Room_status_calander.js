
function handleMouseOver(element) {
    // 해당 li 요소의 다음 형제 요소인 hr 요소를 선택하여 너비를 100%로 변경
    $(element).next('.management_li_text_hr').css('width', '80%' ,500);
}

function handleMouseLeave(element) {
    // 해당 li 요소의 다음 형제 요소인 hr 요소의 너비를 0%로 변경
    $(element).next('.management_li_text_hr').css('width', '0%', 500);
}
// script.js
document.addEventListener('DOMContentLoaded', function () {
    const calendarDays = document.querySelector('.calendar-days');
    const monthYear = document.getElementById('month-year');
    const prevButton = document.getElementById('prev');
    const nextButton = document.getElementById('next');
    const startDateInput = document.getElementById('start-date');
    const endDateInput = document.getElementById('end-date');
    const searchCheckinInput = document.getElementById('search-checkin');
    const searchCheckoutInput = document.getElementById('search-checkout');
    const searchButton = document.getElementById('search-btn');
    const searchResults = document.getElementById('search-results');

    let date = new Date();
    let year = date.getFullYear();
    let month = date.getMonth();

    // 예시로 사용할 예약 데이터
    const reservations = {
        '2023-05-15': [
            { room: '객실 101', checkIn: '14:00', checkOut: '11:00', status: 'reserved' },
            { room: '객실 102', checkIn: '15:00', checkOut: '12:00', status: 'canceled' }
        ],
        '2023-05-16': [
            { room: '객실 103', checkIn: '16:00', checkOut: '13:00', status: 'reserved' }
        ],
        '2023-05-17': [
            { room: '객실 101', checkIn: '14:00', checkOut: '11:00', status: 'reserved' },
            { room: '객실 102', checkIn: '15:00', checkOut: '12:00', status: 'reserved' },
            { room: '객실 103', checkIn: '16:00', checkOut: '13:00', status: 'canceled' }
        ],
        '2024-05-18' :[
            { room: '객실 101', checkIn: '14:00', checkOut: '11:00', status: 'reserved' },
            { room: '객실 102', checkIn: '15:00', checkOut: '12:00', status: 'reserved' },
            { room: '객실 103', checkIn: '16:00', checkOut: '13:00', status: 'reserved' },
            { room: '객실 104', checkIn: '16:00', checkOut: '13:00', status: 'reserved' },
            { room: '객실 105', checkIn: '16:00', checkOut: '13:00', status: 'canceled' }
        ]
    };

    const renderCalendar = () => {
        calendarDays.innerHTML = '';
        const firstDay = new Date(year, month, 1).getDay();
        const lastDate = new Date(year, month + 1, 0).getDate();
        
        monthYear.textContent = `${year}년 ${month + 1}월`;

        const daysInWeek = 7;
        const totalDays = firstDay + lastDate;
        const rows = Math.ceil(totalDays / daysInWeek);
        const totalCells = rows * daysInWeek;

        for (let i = 0; i < firstDay; i++) {
            const emptyDiv = document.createElement('div');
            calendarDays.appendChild(emptyDiv);
        }

        for (let i = 1; i <= lastDate; i++) {
            const dayDiv = document.createElement('div');
            dayDiv.textContent = i;
            const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            
            let reservedRoomsCount = 0; // 예약된 객실 수를 초기화
            let canceledRoomsCount = 0; // 취소된 객실 수를 초기화

            if (reservations[dateString]) {
                reservations[dateString].forEach(reservation => {
                    if (reservation.status === 'reserved') {
                        reservedRoomsCount++; // 해당 날짜의 예약된 객실 수 계산
                    } else if (reservation.status === 'canceled') {
                        canceledRoomsCount++; // 해당 날짜의 취소된 객실 수 계산
                    }
                });
            }

            const reservationCountDiv = document.createElement('div');
            reservationCountDiv.classList.add('reservation-count');
            reservationCountDiv.innerHTML = `예약 객실 수: ${reservedRoomsCount}<br>취소 객실 수: ${canceledRoomsCount}`; // 예약 및 취소된 객실 수를 표시

            dayDiv.appendChild(reservationCountDiv);
            calendarDays.appendChild(dayDiv);
        }

        for (let i = totalDays; i < totalCells; i++) {
            const emptyDiv = document.createElement('div');
            calendarDays.appendChild(emptyDiv);
        }
    };

    const searchReservations = () => {
        const startDate = new Date(startDateInput.value);
        const endDate = new Date(endDateInput.value);
        const searchCheckin = searchCheckinInput.value;
        const searchCheckout = searchCheckoutInput.value;
        searchResults.innerHTML = '';

        if (isNaN(startDate) || isNaN(endDate) || startDate > endDate) {
            const invalidDateRange = document.createElement('div');
            invalidDateRange.textContent = '유효한 날짜 범위를 선택하세요.';
            searchResults.appendChild(invalidDateRange);
            return;
        }

        let hasResults = false;
        for (let d = startDate; d <= endDate; d.setDate(d.getDate() + 1)) {
            const dateString = d.toISOString().split('T')[0];
            if (reservations[dateString]) {
                reservations[dateString].forEach(reservation => {
                    if ((!searchCheckin || reservation.checkIn === searchCheckin) &&
                        (!searchCheckout || reservation.checkOut === searchCheckout)) {
                        const result = document.createElement('div');
                        result.classList.add('search-result');
                        result.innerHTML = `${dateString}<br>${reservation.room}<br><span class="check-in">체크인: ${reservation.checkIn}</span><span class="check-out">체크아웃: ${reservation.checkOut}</span><hr>`;
                        searchResults.appendChild(result);
                        hasResults = true;
                    }
                });
            }
        }

        if (!hasResults) {
            const noResult = document.createElement('div');
            noResult.textContent = '일치하는 예약 정보가 없습니다.';
            searchResults.appendChild(noResult);
        }
    };

    prevButton.addEventListener('click', () => {
        month--;
        if (month < 0) {
            month = 11;
            year--;
        }
        renderCalendar();
    });

    nextButton.addEventListener('click', () => {
        month++;
        if (month > 11) {
            month = 0;
            year++;
        }
        renderCalendar();
    });

    searchButton.addEventListener('click', searchReservations);

    renderCalendar();
});