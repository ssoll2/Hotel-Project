package com.hotel.ask;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.QnaBoardDTO;

public class userQnaListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

	    HotelUserDTO cont = (HotelUserDTO) session.getAttribute("dto");
	    System.out.println("cont = " + cont);
	    
	    String user_id = cont.getHotel_user_id();
	    System.out.println("user_id = " + user_id);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int rowsize = 6;

		int block = 9;

		int totalRecord = 0;

		int allPage = 0;

		int page = 0;
		
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page").trim());
		} else {

			page = 1;
		}

		int startNo = (page * rowsize) - (rowsize - 1);

		int endNo = (page * rowsize);

		int startBlock = (((page - 1) / block) * block) + 1;
		
		int endBlock = (((page - 1) / block) * block) + block;
		
		totalRecord = dao.getqnaCount();

		allPage = (int)Math.ceil(totalRecord / (double)rowsize);
		
		if(endBlock > allPage) {
			endBlock = allPage;
		}
		
		List<QnaBoardDTO> list = dao.getqnaList(page, rowsize, user_id);
		
		request.setAttribute("page", page);
		request.setAttribute("rowsize", rowsize);
		request.setAttribute("block", block);
		request.setAttribute("totalRecord", totalRecord);
		request.setAttribute("allPage", allPage);
		request.setAttribute("startNo", startNo);
		request.setAttribute("endNo", endNo);
		request.setAttribute("startBlock", startBlock);
		request.setAttribute("endBlock", endBlock);
		request.setAttribute("List", list);
		
		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/qna/user_qna_list.jsp");
			
		return forward;
	}

}
