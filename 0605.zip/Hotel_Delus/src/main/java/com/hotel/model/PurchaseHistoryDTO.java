package com.hotel.model;

public class PurchaseHistoryDTO {

	private String purchase_no;
	private String purchase_user_no;
	private String purchase_room_no;
	private String purchase_room_price;
	private String purchase_reservate_no;
	private String purchase_date;
	private boolean purchase_room_reivew_status;
	
	
	public String getPurchase_no() {
		return purchase_no;
	}
	public void setPurchase_no(String purchase_no) {
		this.purchase_no = purchase_no;
	}
	public String getPurchase_user_no() {
		return purchase_user_no;
	}
	public void setPurchase_user_no(String purchase_user_no) {
		this.purchase_user_no = purchase_user_no;
	}
	public String getPurchase_room_no() {
		return purchase_room_no;
	}
	public void setPurchase_room_no(String purchase_room_no) {
		this.purchase_room_no = purchase_room_no;
	}
	public String getPurchase_room_price() {
		return purchase_room_price;
	}
	public void setPurchase_room_price(String purchase_room_price) {
		this.purchase_room_price = purchase_room_price;
	}
	public String getPurchase_reservate_no() {
		return purchase_reservate_no;
	}
	public void setPurchase_reservate_no(String purchase_reservate_no) {
		this.purchase_reservate_no = purchase_reservate_no;
	}
	public String getPurchase_date() {
		return purchase_date;
	}
	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}
	public boolean isPurchase_room_reivew_status() {
		return purchase_room_reivew_status;
	}
	public void setPurchase_room_reivew_status(boolean purchase_room_reivew_status) {
		this.purchase_room_reivew_status = purchase_room_reivew_status;
	}
	
}
