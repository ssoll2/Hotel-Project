package com.hotel.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.hotel.model.HotelTotalDAO;

public class HotelTotalDAO {
	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	// TotalDAO 객체를 싱글톤 방식으로 만든다.

	// 1. TotalDAO 객체를 정적(static) 멤버로 선언 해 준다.
	private static HotelTotalDAO instance = null;

	// 2. 기본 생성자를 private 로 선언한다.
	private HotelTotalDAO() {
	}

	// 3. 기본 생성자 대신 instance 를 return 해 주는 getInstance() 매서드 선언.
	public static HotelTotalDAO getInstance() {

		if (instance == null) {
			instance = new HotelTotalDAO();
		}

		return instance;
	} // getInstance() end.

	// JDBC 방식이 아닌 DBCP 방식으로 DB와 연동 작업 진행.
	public void openConn() {

		try {

			// 1. JNDI 서버 객체 생성.
			// 자바의 네이밍 서비스(JNDI)에서 이름과 실제 객체를 연결 해 주는 개념이 Context 객체이며
			// , InitialContext 객체는 네이밍 서비스를 이용하기 위한 시작점이 된다.
			Context initCtx = new InitialContext();

			// 2. Context 객체를 얻어와야 함.
			// "java:comp/env" 라는 이름의 인수로 Context 객체를 얻어옴.
			// "java:comp/env" 는 현재 웹 애플리케이션에서 네이밍 서비스를 이용시 루트 디렉토리라고 생각하면 됨.
			// 즉, 현재 웹 애플리케이션이 사용 할 수 있는 모든 자원은 "java:comp/env" 아래에 위치를 하게 됨.
			Context ctx = (Context) initCtx.lookup("java:comp/env");

			// 3. lookup() 매서드를 이용하여 매칭되는 커넥션을 찾아옴.
			// "java:comp/env" 아래에 위치한 "jdbc/mysql" 자원을 얻어옴
			// 이 자원이 바로 데이터 소스(커넥션 풀)임.
			// 여기서 "jdbc/mysql" 은 context.xml 파일에 추가했던
			// <Resource> 태그 안에 있던 name 속성의 값임.
			DataSource ds = (DataSource) ctx.lookup("jdbc/mysql");

			// 4. DataSource 객체를 이용하여 커넥션을 하나 가져오면 됨.
			con = ds.getConnection();

		} catch (Exception e) {
			e.printStackTrace();
		}

	} // openConn() end.

	// DB에 연결된 자원을 종료하는 매서드.
	public void closeConn(ResultSet rs, PreparedStatement pstmt, Connection con) {

		try {

			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	} // closeConn() end.

	public void closeConn(PreparedStatement pstmt, Connection con) {

		try {

			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	} // closeConn() end.

	// 회원 가입 페이지에서 입력받은 회원의 정보를 추가하는 메서드
	public int insertHotelUser(HotelUserDTO dto) {
		
		int result = 0, cnt = 0;
		
		try {
			openConn();
			
			sql = "select count(hotel_user_no) from hotel_user where hotel_user_no like ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getHotel_user_no() + "%");
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cnt = rs.getInt(1) + 1;
			}
			
			sql = "insert into hotel_user values(?,?,?,?,?,?, default, now(), null )";

			
			pstmt = con.prepareStatement(sql);
			
			if(cnt < 10) {
				pstmt.setString(1, dto.getHotel_user_no() + "00" + cnt);
			}else if(cnt < 100) {
				pstmt.setString(1, dto.getHotel_user_no() + "0" + cnt);
			}else {
				pstmt.setString(1, dto.getHotel_user_no() + cnt);
			}
			
			pstmt.setString(2, dto.getHotel_user_name());
			pstmt.setString(3, dto.getHotel_user_id());
			pstmt.setString(4, dto.getHotel_user_pwd());
			pstmt.setString(5, dto.getHotel_user_phone());
			pstmt.setString(6, dto.getHotel_user_email());
			
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	} // insertHotelUser(HotelUserDTO dto) end

	// 회원가입에서 id중복 체크하는 메서드
	public int checkUserId(String user_id) {
		int result = 0;
		
		try {
			openConn();
			
			sql = "select * from hotel_user where hotel_user_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, user_id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = -1;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		
		
		
		return result;
	} // int checkUserId(String user_id)  end

	// 부대 시설 추가하는 메서드
	public int insertAme(AmenitieDTO dto) {
		int result = 0;
		
		try {
			openConn();
			
			sql = "insert into hotel_amenities_info value(?,?,?,?,?,?,?,?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getAme_type());			
			pstmt.setInt(2, dto.getAme_price());
			pstmt.setBoolean(3, dto.isAme_status());
			pstmt.setString(4, dto.getAme_open());
			pstmt.setString(5, dto.getAme_close());	
			pstmt.setString(6, dto.getAme_file());
			pstmt.setString(7, dto.getAme_title());
			pstmt.setString(8, dto.getAme_cont());
			
			
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, pstmt, con);
		}
		return result;
	}

	public void remainLogout(String user_no) {
		  String user_id = null;
	      String log_type = "logout";

	      try {
	         openConn();

	         sql = "select hotel_user_id from hotel_user where hotel_user_no like ?";

	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, user_no);

	         rs = pstmt.executeQuery();

	         if (rs.next()) {
	            user_id = rs.getString(1);
	         }

	         sql = "insert into log values(default, ?, ?, ?)";

	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, user_no);
	         pstmt.setString(2, user_id);
	         pstmt.setString(3, log_type);

	         pstmt.executeUpdate();

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         closeConn(rs, pstmt, con);
	      }

		
	} //remainLogout(String user_no)end

	public void remainLogin(String user_id) {

		 String user_no = null;
	      String log_type = "login";

	      try {
	         openConn();

	         sql = "select hotel_user_no from hotel_user where hotel_user_id like ?";

	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, user_id);

	         rs = pstmt.executeQuery();

	         if (rs.next()) {
	            user_no = rs.getString(1);
	         }

	         sql = "insert into log values(default, ?, ?, ?)";

	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, user_no);
	         pstmt.setString(2, user_id);
	         pstmt.setString(3, log_type);

	         pstmt.executeUpdate();

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         closeConn(rs, pstmt, con);
	      }

		
		
	}

	public HotelUserDTO getHotelUserContent(HotelUserDTO dto) {
		 HotelUserDTO u_cont = new HotelUserDTO();

	      try {

	         openConn();

	         sql = "select * from hotel_user where hotel_user_id = ?";

	         pstmt = con.prepareStatement(sql);

	         pstmt.setString(1, dto.getHotel_user_id());

	         rs = pstmt.executeQuery();

	         if (rs.next()) {
	            u_cont.setHotel_user_no(rs.getString("hotel_user_no"));
	            u_cont.setHotel_user_id(rs.getString("hotel_user_id"));
	            u_cont.setHotel_user_pwd(rs.getString("hotel_user_password"));
	            u_cont.setHotel_user_name(rs.getString("hotel_user_name"));
	            u_cont.setHotel_user_phone(rs.getString("hotel_user_phone"));
	            u_cont.setHotel_user_email(rs.getString("hotel_user_email"));
	            u_cont.setHotel_user_rank(rs.getString("hotel_user_rank"));
	            u_cont.setHotel_user_payment_info(rs.getString("hotel_user_payment_info"));
	            u_cont.setHotel_user_regdate(rs.getString("hotel_user_regdate"));

	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         closeConn(rs, pstmt, con);
	      }

	      return u_cont;

	}

	public int CheckLogin(HotelUserDTO dto) {
		
		 int result = 0;   
	      
	      try {   
	         openConn();
	            sql = " select * from hotel_user where hotel_user_id = ?";   
	            
	            pstmt = con.prepareStatement(sql);
	            
	            pstmt.setString(1, dto.getHotel_user_id());
	            
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()){
	               if (dto.getHotel_user_pwd().equals(rs.getString("hotel_user_password"))) { // 아이디가 존재하고, 입력받은 pwd가 일치 할 경우
	                  result = 1;
	               } else { // 일치하는 아이디가 DB에 존재하지만 입력한 비밀번호가 틀린경우
	                  result = -1;
	               }
	            }else{ // 입력받은 아이디가 DB에 존재하지 않을 경우.
	                     result = 0;
	                  }   
	         } catch (SQLException e) {
	            e.printStackTrace();
	         }finally {      
	            closeConn(rs,pstmt,con);
	         }
	      
	      return result;

		
		
		
	}
	   public int CheckALogin(AdminDTO dto) {
		      int result = 0;
		      
		         try {   
		               openConn();
		                  sql = " select * from admin where admin_id = ?";   
		                  
		                  pstmt = con.prepareStatement(sql);
		                  
		                  pstmt.setString(1, dto.getAdmin_id());
		                  
		                  rs = pstmt.executeQuery();
		                  
		                  if(rs.next()){
		                     if (dto.getAdmin_password().equals(rs.getString("admin_password"))) { // 아이디가 존재하고, 입력받은 pwd가 일치 할 경우
		                        result = 1;
		                     } else { // 일치하는 아이디가 DB에 존재하지만 입력한 비밀번호가 틀린경우
		                        result = -1;
		                     }
		                  }else{ // 입력받은 아이디가 DB에 존재하지 않을 경우.
		                           result = 0;
		                        }   
		               } catch (SQLException e) {
		                  e.printStackTrace();
		               }finally {      
		                  closeConn(rs,pstmt,con);
		               }
		            
		            return result;

		   }

		   public AdminDTO getAdminContent(AdminDTO dto) {
		      
		      AdminDTO a_cont = new AdminDTO();
		      
		      try {
		         openConn();
		         
		         sql="select * from admin where admin_id = ?";
		         
		         pstmt = con.prepareStatement(sql);
		         
		         pstmt.setString(1, dto.getAdmin_id());
		         
		         rs = pstmt.executeQuery();
		         
		         if(rs.next()) {
		            
		            a_cont.setAdmin_id(rs.getString("admin_id"));
		            a_cont.setAdmin_password(rs.getString("admin_password"));
		            a_cont.setAdmin_no(rs.getString("admin_no"));
		            a_cont.setAdmin_name(rs.getString("admin_name"));
		            a_cont.setAdmin_major(rs.getString("admin_major"));
		            a_cont.setAdmin_phone(rs.getString("admin_phone"));
		      
		         }
		         
		      } catch (SQLException e) {
		         // TODO Auto-generated catch block
		         e.printStackTrace();
		      }finally {
		         closeConn(rs,pstmt,con);
		      }

		      return a_cont;
		   }

		   public void remainALogin(String admin_id) {
		        String admin_no = null;
		         String log_type = "login";

		         try {
		            openConn();

		            sql = "select admin_no from admin where admin_id like ?";

		            pstmt = con.prepareStatement(sql);
		            pstmt.setString(1, admin_id);

		            rs = pstmt.executeQuery();

		            if (rs.next()) {
		               admin_no = rs.getString(1);
		            }

		            sql = "insert into log values(default, ?, ?, ?)";

		            pstmt = con.prepareStatement(sql);
		            pstmt.setString(1, admin_no);
		            pstmt.setString(2, admin_id);
		            pstmt.setString(3, log_type);

		            pstmt.executeUpdate();

		         } catch (Exception e) {
		            e.printStackTrace();
		         } finally {
		            closeConn(rs, pstmt, con);
		         }

		   }

		   public void remainALogout(String user_no) {
		        String admin_id = null;
		         String log_type = "logout";

		         try {
		            openConn();

		            sql = "select admin_id from admin where admin_no like ?";

		            pstmt = con.prepareStatement(sql);
		            pstmt.setString(1, user_no);

		            rs = pstmt.executeQuery();

		            if (rs.next()) {
		               admin_id = rs.getString(1);
		            }

		            sql = "insert into log values(default, ?, ?, ?)";

		            pstmt = con.prepareStatement(sql);
		            pstmt.setString(1, user_no);
		            pstmt.setString(2, admin_id);
		            pstmt.setString(3, log_type);

		            pstmt.executeUpdate();

		         } catch (Exception e) {
		            e.printStackTrace();
		         } finally {
		            closeConn(rs, pstmt, con);
		         }// TODO Auto-generated method stub
		      
		   } // remainALogout(String user_no) end
		   
		   
		   public List<AmenitieDTO> AmeList() {
				
				List<AmenitieDTO> list = new ArrayList<AmenitieDTO>();
				
				
				try {
					openConn();
					
					sql = "SELECT * FROM hotel_amenities_info";
					
					pstmt=con.prepareStatement(sql);
					
					rs = pstmt.executeQuery();
					
					while(rs.next()) {
						AmenitieDTO dto = new AmenitieDTO();
						
						dto.setAme_type(rs.getString("amenities_type"));
						dto.setAme_price(rs.getInt("amenities_price"));
						dto.setAme_status(rs.getBoolean("amenities_status"));
						dto.setAme_open(rs.getString("amenities_opentime"));
						dto.setAme_close(rs.getString("amenities_closetime"));
						dto.setAme_file(rs.getString("amenities_file"));
						dto.setAme_title(rs.getString("amenities_title"));
						dto.setAme_cont(rs.getString("amenities_cont"));
						
						list.add(dto);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}finally {
					closeConn(rs, pstmt, con);
				}
				return list;
			}

		// 룸 등록하는 메서드
		/*
		 * public int insertHotelRoom(RoomInfoDTO dto) {
		 * 
		 * int result = 0, cnt = 0;
		 * 
		 * try { openConn();
		 * 
		 * sql = "select count(room_pk_no) from room_info where room_pk_no like ?";
		 * 
		 * pstmt = con.prepareStatement(sql);
		 * 
		 * pstmt.setString(1, dto.getRoom_pk_no() + "%");
		 * 
		 * rs = pstmt.executeQuery();
		 * 
		 * if(rs.next()) { cnt = rs.getInt(1) + 1; }
		 * 
		 * sql = "insert into room_info values(?,?,?,?,?,?,?,?,?)";
		 * 
		 * pstmt = con.prepareStatement(sql);
		 * 
		 * if (cnt < 10) { pstmt.setString(1, dto.getRoom_pk_no() + "000" + cnt); } else
		 * { pstmt.setString(1, dto.getRoom_pk_no() + "0" + cnt); }
		 * 
		 * pstmt.setString(2, dto.getRoom_type()); pstmt.setInt(3, dto.getRoom_total());
		 * pstmt.setInt(4, dto.getRoom_size()); pstmt.setInt(5, dto.getRoom_maximum());
		 * pstmt.setInt(6, dto.getRoom_price()); pstmt.setString(7, dto.getRoom_cont());
		 * pstmt.setString(8, dto.getRoom_file()); pstmt.setString(9,
		 * dto.getRoom_facilities());
		 * 
		 * result = pstmt.executeUpdate();
		 * 
		 * } catch (SQLException e) { e.printStackTrace(); } finally { closeConn(rs,
		 * pstmt, con); }
		 * 
		 * return result; } // insertRoom end
		 */
		// 관리자 페이지에서 부대시설 개수 
		public int getAdminAmeCount() {

			int count = 0;
			
			
			try {
				openConn();
				
				sql = "select count(*) from hotel_amenities_info" ;
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					count = rs.getInt(1);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
				
			return count;
			
		} // getAdminAmeCount() end

		// 부대시설 리스트
		public List<AmenitieDTO> adminAmeList(int page, int rowsize) {
			
			List<AmenitieDTO> list = new ArrayList<AmenitieDTO>();
			
			int startNo = (page * rowsize) - (rowsize - 1);
			
			int endNo = (page * rowsize);
			
			
			try {
				openConn();
				
				sql = "SELECT * FROM (SELECT @row_number:=@row_number+1 AS rnum, h.* " +
					      "FROM hotel_amenities_info h, (SELECT @row_number:=0) AS dummy " +
					      ") AS subquery " +
					      "WHERE rnum >= ? AND rnum <= ?";
				
				pstmt=con.prepareStatement(sql);
				
				pstmt.setInt(1, startNo);
				pstmt.setInt(2, endNo);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					AmenitieDTO dto = new AmenitieDTO();
					
					dto.setAme_type(rs.getString("amenities_type"));
					dto.setAme_price(rs.getInt("amenities_price"));
					dto.setAme_status(rs.getBoolean("amenities_status"));
					dto.setAme_open(rs.getString("amenities_opentime"));
					dto.setAme_close(rs.getString("amenities_closetime"));
					dto.setAme_file(rs.getString("amenities_file"));
					dto.setAme_title(rs.getString("amenities_title"));
					dto.setAme_cont(rs.getString("amenities_cont"));
					
					list.add(dto);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			return list;
			
		} // List<AmenitieDTO> adminAmeList end

		// 부대시설 삭제하는 메서드
		public int deleteAdminAme(String type) {
			int result = 0;
			
			try {
				openConn();
				
				sql = "delete from hotel_amenities_info where amenities_type = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, type);
				
				result = pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(pstmt, con);
			}
			return result;
			
			
		} // int deleteAdminAme end

		// 부대시설 상세내역
		public AmenitieDTO getAdminAmeContent(String type) {
			AmenitieDTO dto = null;
			
			
			try {
				openConn();
				
				sql = "select * from hotel_amenities_info where amenities_type = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, type);
				
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
	                dto = new AmenitieDTO();
	                dto.setAme_type(rs.getString("amenities_type"));
	                dto.setAme_price(rs.getInt("amenities_price"));
	                dto.setAme_status(rs.getBoolean("amenities_status"));
	                dto.setAme_open(rs.getString("amenities_opentime"));
	                dto.setAme_close(rs.getString("amenities_closetime"));
	                dto.setAme_file(rs.getString("amenities_file"));
	                dto.setAme_title(rs.getString("amenities_title"));
	                dto.setAme_cont(rs.getString("amenities_cont"));
	            }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			
			return dto;
		} // AmenitieDTO getAdminAmeContent

		// 부대시설 수정하는 메서드
		public int updateAdminAme(AmenitieDTO dto) {
			int result = 0;
			
			
			
			try {
				openConn();
				
				sql = "update  hotel_amenities_info set amenities_title = ?, "
						+ " amenities_status = ?, "
						+ " amenities_opentime = ?, "
						+ " amenities_closetime = ?, "
						+ " amenities_price = ?, "
						+ " amenities_cont = ?,"
						+ " amenities_file = ?"
						+ "where amenities_type = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, dto.getAme_title());
				pstmt.setBoolean(2, dto.isAme_status());
				pstmt.setString(3, dto.getAme_open());
				pstmt.setString(4, dto.getAme_close());
				pstmt.setInt(5, dto.getAme_price());
				pstmt.setString(6, dto.getAme_cont());
				pstmt.setString(7, dto.getAme_file());
				pstmt.setString(8, dto.getAme_type());
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				closeConn(pstmt, con);
			}
			return result;
		} // int updateAdminAme end

		
		// 관리자 페이지에서 공지사항 등록 하는 메서드
		public int insertAdminNotice(NoticeDTO dto) {
			
			int result = 0, cnt = 0;
			
			try {
				openConn();
				
				sql = "select max(notice_board_no) from notice";
				
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					cnt = rs.getInt(1) + 1;
				}
				
				sql = "insert into notice values(?,?,?, default, null, default, ?)";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, cnt);
				pstmt.setString(2, dto.getNotice_board_title());
				pstmt.setString(3, dto.getNotice_board_cont());
				pstmt.setString(4, dto.getNotice_board_file());
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return result;
		} // insertAdminNotice(NoticeDTO dto) end

		// 관리자 페이지에서 공지사항 갯수 세는 메서드
		public int getAdminNoticeCount() {
			
			int count = 0;
			
			try {
				openConn();
				
				sql = "select count(*) from notice";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					count = rs.getInt(1);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			
			return count;
		} // int getAdminNoticeCount() end

		// 공지사항 리스트
		public List<NoticeDTO> AdminNoticeList() {
			
			List<NoticeDTO> list = new ArrayList<NoticeDTO>();
			
			try {
				NoticeDTO dto = null;
				
				openConn();
				
				sql = "select * from notice order by notice_board_no asc";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					
					dto = new NoticeDTO();
					
					dto.setNotice_board_no(rs.getInt("notice_board_no"));
					dto.setNotice_board_title(rs.getString("notice_board_title"));
					dto.setNotice_board_cont(rs.getString("notice_board_cont"));
					dto.setNotice_board_date(rs.getString("notice_board_date"));
					dto.setNotice_board_update(rs.getString("notice_board_update"));
					dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
					dto.setNotice_board_file(rs.getString("notice_board_file"));
					
					
					list.add(dto);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			
			return list;
		}

		// 관리자 페이지에서 이벤트 갯수 세는 메서드
		public int getAdminEventCount() {
			
			int count = 0;
			
			try {
				openConn();
				
				sql = "select count(*) from event";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					count = rs.getInt(1);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return count;
		}

		// 관리자 페이지에서 이벤트 리스트
		public List<EventDTO> AdminEventList() {
			
			List<EventDTO> list = new ArrayList<EventDTO>();
			
			try {
				EventDTO dto = null;
				
				openConn();
				
				sql = "select * from event order by event_board_no desc";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					dto = new EventDTO();
					
					dto.setEvent_board_no(rs.getInt("event_board_no"));
					dto.setEvent_board_title(rs.getString("event_board_title"));
					dto.setEvent_board_cont(rs.getString("event_board_cont"));
					dto.setEvent_board_date(rs.getString("event_board_date"));
					dto.setEvent_board_update(rs.getString("event_board_update"));
					dto.setEvent_board_hit(rs.getInt("event_board_hit"));
					dto.setEvent_board_file(rs.getString("event_board_file"));
				
					list.add(dto);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			
			return list;
		}

		// 관리자 페이지에서 이벤트 등록하는 메서드
		public int insertAdminEvent(EventDTO dto) {
			int result = 0, cnt = 0;
			
			try {
				openConn();
				
				sql = "select max(event_board_no) from event";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					cnt = rs.getInt(1) + 1;
				}
				
				sql = "insert into event values(?,?,?,?,?, default, null, default,?)";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, cnt);
				pstmt.setString(2, dto.getEvent_board_title());
				pstmt.setString(3, dto.getEvent_board_cont());
				pstmt.setString(4, dto.getEvent_board_start_date());
				pstmt.setString(5, dto.getEvent_board_end_date());
				pstmt.setString(6, dto.getEvent_board_file());
				
				result = pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
			return result;
		} // int insertAdminEvent(EventDTO dto) end

		// 메인 페이지에서 공지사항 리스트 메서드
		public List<NoticeDTO> getNoticeList() {
			
			List<NoticeDTO> list = new ArrayList<NoticeDTO>();
			
			try {
				NoticeDTO dto = null;
				
				openConn();
				
				sql = "select * from notice order by notice_board_no desc";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					dto = new NoticeDTO();
					
					dto.setNotice_board_no(rs.getInt("notice_board_no"));
					dto.setNotice_board_title(rs.getString("notice_board_title"));
					dto.setNotice_board_cont(rs.getString("notice_board_cont"));
					dto.setNotice_board_date(rs.getString("notice_board_date"));
					dto.setNotice_board_update(rs.getString("notice_board_update"));
					dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
					dto.setNotice_board_file(rs.getString("notice_board_file"));
					
					list.add(dto);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			
			return list;
		}

		// 메인 페이지에서 공지사항 갯수 세는 메서드
		public int countNoticeList() {
			
			int cnt = 0;
			
			try {
				openConn();
				
				sql = "select count(*) from notice";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					cnt = rs.getInt(1);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			return cnt;
		}

		// 공지사항 상세내역 메서드
		public NoticeDTO getNoticeContent(int board_no) {

			NoticeDTO dto = null;
			
			try {
				openConn();
				
				sql = "select * from notice where notice_board_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, board_no);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					dto = new NoticeDTO();
					
					dto.setNotice_board_no(rs.getInt("notice_board_no"));
					dto.setNotice_board_title(rs.getString("notice_board_title"));
					dto.setNotice_board_cont(rs.getString("notice_board_cont"));
					dto.setNotice_board_date(rs.getString("notice_board_date"));
					dto.setNotice_board_update(rs.getString("notice_board_update"));
					dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
					dto.setNotice_board_file(rs.getString("notice_board_file"));
					
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			
			return dto;
		}

		// 공지사항 조회수 증가 메서드
		public void noticeBoardHit(int board_no) {

			try {
				openConn();
				
				sql = "update notice set notice_board_hit = notice_board_hit + 1 where notice_board_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, board_no);
				
				pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			
		}

		public int RegisterRoomInfo(RoomDTO dto) {
			int result = 0;

			try {
				openConn();
				sql = "insert into room_info values(?, ?, ?, ?, ?, ?, ?, ?)";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, dto.getRoom_type());
				pstmt.setInt(2, dto.getRoom_total());
				pstmt.setString(3, dto.getRoom_size());
				pstmt.setInt(4, dto.getRoom_maximum());
				pstmt.setInt(5, dto.getRoom_price());
				pstmt.setString(6, dto.getRoom_cont());
				pstmt.setString(7, dto.getRoom_file());
				pstmt.setString(8, dto.getRoom_facilities());
				result = pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			return result;
			
		} // int RegisterRoomInfo end

		public List<RoomDTO> getRoomInfoList() {
			List<RoomDTO> list = new ArrayList<RoomDTO>();

			try {
				openConn();
				sql = "select * from room_info order by room_type asc";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while(rs.next()) {
					RoomDTO dto = new RoomDTO();
					dto.setRoom_type(rs.getString("room_type"));
					dto.setRoom_total(rs.getInt("room_total"));
					dto.setRoom_size(rs.getString("room_size"));
					dto.setRoom_maximum(rs.getInt("room_maximum"));
					dto.setRoom_price(rs.getInt("room_price"));
					dto.setRoom_cont(rs.getString("room_cont"));
					dto.setRoom_file(rs.getString("room_file"));
					dto.setRoom_facilities(rs.getString("room_facilities"));
					list.add(dto);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			} return list;
		}

		
		public List<RoomDTO> getRoomList() {
			List<RoomDTO> list = new ArrayList<RoomDTO>();
			
			try {
				openConn();
				sql = "select * from room";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while(rs.next()) {
					RoomDTO dto = new RoomDTO();
					dto.setRoom_pk_no(rs.getString("room_pk_no"));
					dto.setRoom_number(rs.getInt("room_number"));
					dto.setRoom_type(rs.getString("room_type"));
					dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
					list.add(dto);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			} return list;
		}

		// 관리자 페이지에서 공지사항 수정하는 메서드
		public int updateAdminNotice(NoticeDTO dto) {
			int result = 0;

			try {

				openConn();

				sql = "update notice set notice_board_title = ?, "
						+ "notice_board_cont = ?, notice_board_file = ?, notice_board_update = now() "
						+ "where notice_board_no = ?";

				pstmt = con.prepareStatement(sql);

				
				pstmt.setString(1, dto.getNotice_board_title());
				pstmt.setString(2, dto.getNotice_board_cont());
				pstmt.setString(3, dto.getNotice_board_file());
				pstmt.setInt(4, dto.getNotice_board_no());

				result = pstmt.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			return result;
		}

		// 관리자 페이지에서 공지사항 삭제하는 메서드
		public int deleteAdminNotice(String no) {
			
			int result = 0;

			try {

				openConn();

				sql = "delete from notice where notice_board_no = ?";

				pstmt = con.prepareStatement(sql);

				pstmt.setString(1, no);

				result = pstmt.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}

			return result;
			
			
		}

		// 이벤트 상세내역 메서드
		public EventDTO getEventContent(int board_no) {
			
			EventDTO dto = null;
			
			try {
				openConn();
				
				sql = "select * from event where event_board_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, board_no);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					dto = new EventDTO();
					
					dto.setEvent_board_no(rs.getInt("event_board_no"));
					dto.setEvent_board_title(rs.getString("event_board_title"));
					dto.setEvent_board_cont(rs.getString("event_board_cont"));
					dto.setEvent_board_start_date(rs.getString("event_board_start_date"));
					dto.setEvent_board_end_date(rs.getString("event_board_end_date"));
					dto.setEvent_board_date(rs.getString("event_board_date"));
					dto.setEvent_board_update(rs.getString("event_board_update"));
					dto.setEvent_board_hit(rs.getInt("event_board_hit"));
					dto.setEvent_board_file(rs.getString("event_board_file"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return dto;
		}

		// 이벤트 조회수 증가 메서드
		public void eventBoardHit(int board_no) {
			
			try {
				openConn();
				
				sql = "update event set event_board_hit = event_board_hit + 1 where event_board_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, board_no);
				
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			
		}

		// 관리자 페이지에서 이벤트 수정하는 메서드
		public int upateAdminEvent(EventDTO dto) {
			
			int result = 0;
			
			try {
				openConn();
				
				sql = "update event set event_board_title = ?, "
						+ "event_board_cont = ?, event_board_start_date = ?, event_board_end_date = ?, event_board_file = ?, event_board_update = now()"
						+ "where event_board_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, dto.getEvent_board_title());
				pstmt.setString(2, dto.getEvent_board_cont());
				pstmt.setString(3, dto.getEvent_board_start_date());
				pstmt.setString(4, dto.getEvent_board_end_date());
				pstmt.setString(5, dto.getEvent_board_file());
				pstmt.setInt(6, dto.getEvent_board_no());
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			return result;
		}
		// 관리자 페이지에서 이벤트 삭제하는 메서드
		public int deleteAdminEvent(String board_no) {
			
			int result = 0;
			
			try {
				openConn();
				
				sql = "delete from event where event_board_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, board_no);
				
				result = pstmt.executeUpdate();
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			return result;
		}
		// 메인 페이지 이벤트 리스트
		public List<EventDTO> getEventList() {
			
			List<EventDTO> list = new ArrayList<EventDTO>();
			
			try {
				EventDTO dto = null;
				
				openConn();
				
				sql = "select * from event order by event_board_no desc";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					dto = new EventDTO();
					
					dto.setEvent_board_no(rs.getInt("event_board_no"));
					dto.setEvent_board_title(rs.getString("event_board_title"));
					dto.setEvent_board_cont(rs.getString("event_board_cont"));
					dto.setEvent_board_start_date(rs.getString("event_board_start_date"));
					dto.setEvent_board_end_date(rs.getString("event_board_end_date"));
					dto.setEvent_board_date(rs.getString("event_board_date"));
					dto.setEvent_board_update(rs.getString("event_board_update"));
					dto.setEvent_board_hit(rs.getInt("event_board_hit"));
					dto.setEvent_board_file(rs.getString("event_board_file"));
					
					list.add(dto);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return list;
		}
		public int insertPackage(PackageDTO dto) {
		      
		      int result = 0, count = 0;
		      
		      try {
		         openConn();
		         
		         sql = "select max(package_merchandise_no) from package";
		         
		         pstmt = con.prepareStatement(sql);
		         
		         rs = pstmt.executeQuery();
		         
		         if(rs.next()) {
		            count = rs.getInt(1) + 1;
		         }
		         
		         
		         sql = "insert into package values(?, ?, ?, ?, ?, ?, ?, ?, null, ?, null, default,?)";
		         
		         pstmt = con.prepareStatement(sql);
		         
		         pstmt.setInt(1, count);
		         pstmt.setString(2, dto.getPackage_title());
		         pstmt.setString(3, dto.getPackage_cont());
		         pstmt.setString(4, dto.getRoom_type());
		         pstmt.setString(5, dto.getOption_type());
		         pstmt.setString(6, dto.getPackage_start_date());
		         pstmt.setString(7, dto.getPackage_end_date());
		         pstmt.setString(8, dto.getPackage_date());
		         pstmt.setString(9, dto.getPackage_file());
		         pstmt.setString(10, dto.getPackage_price());
		         
		         result = pstmt.executeUpdate();
		         
		      } catch (SQLException e) {
		         // TODO Auto-generated catch block
		         e.printStackTrace();
		      } finally {
		         closeConn(pstmt, con);
		      }
		      
		      return result;
		      
		      
		   } // insertUpload(dto) end

		// 유저 회원 수 세는 메서드
		public int getAdminuserCount() {
			int count = 0;
			
			
			try {
				openConn();
				
				sql = "select count(*) from hotel_user";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					count = rs.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			return count;
		} // int getAdminuserCount() end

		// 유저리스트 메서드
		public List<HotelUserDTO> adminUserList(int page, int rowsize) {
			List<HotelUserDTO> list = new ArrayList<HotelUserDTO>();
			
			int startNo = (page * rowsize) - (rowsize - 1);
			
			int endNo = (page * rowsize);
			
			
			try {
				openConn();
				
				sql = "select * from (select @row_number:=@row_number+1 as rnum, u.* " +
						"from hotel_user u, (select @row_number:=0) as dummy " +
						"order by hotel_user_no asc) as subquery " +
						"where rnum >= ? and rnum <= ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, startNo);
				pstmt.setInt(2, endNo);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					HotelUserDTO dto = new HotelUserDTO();
					
					dto.setHotel_user_no(rs.getString("hotel_user_no"));
					dto.setHotel_user_name(rs.getString("hotel_user_name"));
					dto.setHotel_user_id(rs.getString("hotel_user_id"));
					dto.setHotel_user_pwd(rs.getString("hotel_user_password"));
					dto.setHotel_user_phone(rs.getString("hotel_user_phone"));
					dto.setHotel_user_email(rs.getString("hotel_user_email"));
					dto.setHotel_user_rank(rs.getString("hotel_user_rank"));
					dto.setHotel_user_regdate(rs.getString("hotel_user_regdate"));
					dto.setHotel_user_payment_info(rs.getString("hotel_user_payment_info"));
					
					list.add(dto);
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			return list;
		} // List<HotelUserDTO> adminUserList end

		// 유저리스트 상세내역 메서드
		public HotelUserDTO getAdminUserContent(String no) {
			HotelUserDTO dto = null;
			
			
			try {
				openConn();
				
				sql = "select * from hotel_user where hotel_user_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, no);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					
					dto = new HotelUserDTO();
					
					dto.setHotel_user_no(rs.getString("hotel_user_no"));
					dto.setHotel_user_name(rs.getString("hotel_user_name"));
					dto.setHotel_user_id(rs.getString("hotel_user_id"));
					dto.setHotel_user_pwd(rs.getString("hotel_user_password"));
					dto.setHotel_user_phone(rs.getString("hotel_user_phone"));
					dto.setHotel_user_email(rs.getString("hotel_user_email"));
					dto.setHotel_user_rank(rs.getString("hotel_user_rank"));
					dto.setHotel_user_regdate(rs.getString("hotel_user_regdate"));
					dto.setHotel_user_payment_info(rs.getString("hotel_user_payment_info"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			return dto;
		} // HotelUserDTO getAdminUserContent end

		// 유저 수정하는 메서드
		public int AdminUserUpdate(HotelUserDTO dto) {
			int result = 0;
			
			
			try {
				openConn();
				
				sql = "update hotel_user set hotel_user_name = ?, "
						+ " hotel_user_id = ?, "
						+ " hotel_user_password = ?, "
						+ " hotel_user_phone = ?, "
						+ " hotel_user_email = ?, "
						+ " hotel_user_rank = ?, "
						+ " hotel_user_payment_info = ? "
						+ " where hotel_user_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, dto.getHotel_user_name());
				pstmt.setString(2, dto.getHotel_user_id());
				pstmt.setString(3, dto.getHotel_user_pwd());
				pstmt.setString(4, dto.getHotel_user_phone());
				pstmt.setString(5, dto.getHotel_user_email());
				pstmt.setString(6, dto.getHotel_user_rank());
				pstmt.setString(7, dto.getHotel_user_payment_info());
				pstmt.setString(8, dto.getHotel_user_no());
				
				result =  pstmt.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				closeConn(pstmt, con);
			}
			return result;		
			
		} // int AdminUserUpdate end

		// 유저 삭제하는 메서드
		public int AdminUserDelete(String no) {
			int result = 0;
			
			
			try {
				openConn();
				
				sql = "delete from hotel_user where hotel_user_no = ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, no);
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(pstmt, con);
			}
			return result;
		} // int AdminUserDelete end
		
		public List<PackageDTO> getPackageList() {
			List<PackageDTO> list = new ArrayList<PackageDTO>();
			
			try {
				openConn();
				
				sql = "select * from package order by package_merchandise_no asc";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					
					PackageDTO dto = new PackageDTO();
					
					dto.setPackage_merchandise_no(rs.getString("Package_merchandise_no"));
					dto.setPackage_title(rs.getString("package_title"));
					dto.setPackage_cont(rs.getString("package_cont"));
					dto.setRoom_type(rs.getString("room_type"));
					dto.setOption_type(rs.getString("option_type"));
					dto.setPackage_start_date(rs.getString("package_start_date"));
					dto.setPackage_end_date(rs.getString("package_end_date"));
					dto.setPackage_date(rs.getString("package_date"));
					dto.setPackage_update(rs.getString("package_update"));
					dto.setPackage_file(rs.getString("package_file"));
					dto.setPackage_purchase_no(rs.getString("package_purchase_no"));
					dto.setPackage_purchase_status(rs.getBoolean("package_purchase_status"));
					dto.setPackage_price(rs.getString("package_price"));
					
					list.add(dto);
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			return list;
		}

		public List<NoticeDTO> AdminNoticeList(int page, int rowsize) {
			
			List<NoticeDTO> list = new ArrayList<NoticeDTO>();
			
			
			// 해당 페이지에서 시작 번호
			int startNo = (page * rowsize) - (rowsize - 1);

			// 해당 페이지에서 끝 번호
			int endNo = (page * rowsize);

			try {

				NoticeDTO dto = null;

				openConn();

				sql = "select * from (select @ROWN:=@ROWN+1 AS RN, nb.* " + "from notice nb, "
						+ "(select @ROWN:=0) as clear_RN " + "order by nb.notice_board_no asc) as subquery "
						+ "where RN >= ? and RN <= ?";

				pstmt = con.prepareStatement(sql);

				pstmt.setInt(1, startNo);
				pstmt.setInt(2, endNo);

				rs = pstmt.executeQuery();

				while (rs.next()) {

					dto = new NoticeDTO();

					dto.setNotice_board_no(rs.getInt("notice_board_no"));
					dto.setNotice_board_title(rs.getString("notice_board_title"));
					dto.setNotice_board_cont(rs.getString("notice_board_cont"));
					dto.setNotice_board_date(rs.getString("notice_board_date"));
					dto.setNotice_board_update(rs.getString("notice_board_update"));
					dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
					dto.setNotice_board_file(rs.getString("notice_board_file"));

					list.add(dto);

				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}

			return list;
			
		}

		public List<EventDTO> AdminEventList(int page, int rowsize) {
			List<EventDTO> list = new ArrayList<EventDTO>();
			EventDTO dto = null;

			// 해당 페이지에서 시작 번호
			int startNo = (page * rowsize) - (rowsize - 1);

			// 해당 페이지에서 끝 번호
			int endNo = (page * rowsize);

			try {

				openConn();

				sql = "select * from (select @ROWN:=@ROWN+1 AS RN, eb.* " + "from event eb, "
						+ "(select @ROWN:=0) as clear_RN " + "order by eb.event_board_no desc) as subquery "
						+ "where RN >= ? and RN <= ?";

				pstmt = con.prepareStatement(sql);

				pstmt.setInt(1, startNo);
				pstmt.setInt(2, endNo);

				rs = pstmt.executeQuery();

				while (rs.next()) {

					dto = new EventDTO();

					dto.setEvent_board_no(rs.getInt("event_board_no"));
					dto.setEvent_board_title(rs.getString("event_board_title"));
					dto.setEvent_board_cont(rs.getString("event_board_cont"));
					dto.setEvent_board_start_date(rs.getString("event_board_start_date"));
					dto.setEvent_board_end_date(rs.getString("event_board_end_date"));
					dto.setEvent_board_date(rs.getString("event_board_date"));
					dto.setEvent_board_update(rs.getString("event_board_update"));
					dto.setEvent_board_hit(rs.getInt("event_board_hit"));
					dto.setEvent_board_file(rs.getString("event_board_file"));

					list.add(dto);

				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}

			return list;
		}

		
		public int countNoticeSearchList(String field, String keyword) {
			int cnt = 0;

			openConn();

			if (field.equals("전체")) {

				try {

					sql = "select count(*) from notice where notice_board_title like ? or notice_board_cont like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setString(2, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("제목")) {

				try {

					sql = "select count(*) from notice where notice_board_title like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("내용")) {

				try {

					sql = "select count(*) from notice where notice_board_cont like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}

			return cnt;
		}

		public List<NoticeDTO> searchNoticeList(String field, String keyword, int page, int rowsize) {
			List<NoticeDTO> list = new ArrayList<NoticeDTO>();

			int startNo = (page * rowsize) - (rowsize - 1);

			int endNo = (page * rowsize);

			openConn();

			if (field.equals("전체")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "nb.* from notice nb, "
							+ "(select @ROWN:=0) as clear_RN where " + "notice_board_title like ? or "
							+ "notice_board_cont like ? " + "order by nb.notice_board_no desc) as subquery "
							+ "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setString(2, "%" + keyword + "%");
					pstmt.setInt(3, startNo);
					pstmt.setInt(4, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						NoticeDTO dto = new NoticeDTO();

						dto.setNotice_board_no(rs.getInt("notice_board_no"));
						dto.setNotice_board_title(rs.getString("notice_board_title"));
						dto.setNotice_board_cont(rs.getString("notice_board_cont"));
						dto.setNotice_board_date(rs.getString("notice_board_date"));
						dto.setNotice_board_update(rs.getString("notice_board_update"));
						dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
						dto.setNotice_board_file(rs.getString("notice_board_file"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("제목")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "nb.* from notice nb, "
							+ "(select @ROWN:=0) as clear_RN where " + "notice_board_title like ? "
							+ "order by nb.notice_board_no desc) as subquery " + "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						NoticeDTO dto = new NoticeDTO();

						dto.setNotice_board_no(rs.getInt("notice_board_no"));
						dto.setNotice_board_title(rs.getString("notice_board_title"));
						dto.setNotice_board_cont(rs.getString("notice_board_cont"));
						dto.setNotice_board_date(rs.getString("notice_board_date"));
						dto.setNotice_board_update(rs.getString("notice_board_update"));
						dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
						dto.setNotice_board_file(rs.getString("notice_board_file"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("내용")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "nb.* from notice nb, "
							+ "(select @ROWN:=0) as clear_RN where " + "notice_board_cont like ? "
							+ "order by nb.notice_board_no desc) as subquery " + "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						NoticeDTO dto = new NoticeDTO();

						dto.setNotice_board_no(rs.getInt("notice_board_no"));
						dto.setNotice_board_title(rs.getString("notice_board_title"));
						dto.setNotice_board_cont(rs.getString("notice_board_cont"));
						dto.setNotice_board_date(rs.getString("notice_board_date"));
						dto.setNotice_board_update(rs.getString("notice_board_update"));
						dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
						dto.setNotice_board_file(rs.getString("notice_board_file"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}

			return list;
		}

		public int countEventSearchList(String field, String keyword) {
			int cnt = 0;

			openConn();

			if (field.equals("전체")) {

				try {

					sql = "select count(*) from event where event_board_title like ? or event_board_cont like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setString(2, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("제목")) {

				try {

					sql = "select count(*) from event where event_board_title like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("내용")) {

				try {

					sql = "select count(*) from event where event_board_cont like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}

			return cnt;
		}

		public List<EventDTO> searchEventList(String field, String keyword, int page, int rowsize) {
			List<EventDTO> list = new ArrayList<EventDTO>();

			int startNo = (page * rowsize) - (rowsize - 1);

			int endNo = (page * rowsize);

			openConn();

			if (field.equals("전체")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "eb.* from event eb, "
							+ "(select @ROWN:=0) as clear_RN where " + "event_board_title like ? or "
							+ "event_board_cont like ? " + "order by eb.event_board_no desc) as subquery "
							+ "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setString(2, "%" + keyword + "%");
					pstmt.setInt(3, startNo);
					pstmt.setInt(4, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						EventDTO dto = new EventDTO();

						dto.setEvent_board_no(rs.getInt("event_board_no"));
						dto.setEvent_board_title(rs.getString("event_board_title"));
						dto.setEvent_board_cont(rs.getString("event_board_cont"));
						dto.setEvent_board_date(rs.getString("event_board_date"));
						dto.setEvent_board_update(rs.getString("event_board_update"));
						dto.setEvent_board_hit(rs.getInt("event_board_hit"));
						dto.setEvent_board_file(rs.getString("event_board_file"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("제목")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "eb.* from event eb, "
							+ "(select @ROWN:=0) as clear_RN where " + "event_board_title like ? "
							+ "order by eb.event_board_no desc) as subquery " + "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						EventDTO dto = new EventDTO();

						dto.setEvent_board_no(rs.getInt("event_board_no"));
						dto.setEvent_board_title(rs.getString("event_board_title"));
						dto.setEvent_board_cont(rs.getString("event_board_cont"));
						dto.setEvent_board_date(rs.getString("event_board_date"));
						dto.setEvent_board_update(rs.getString("event_board_update"));
						dto.setEvent_board_hit(rs.getInt("event_board_hit"));
						dto.setEvent_board_file(rs.getString("event_board_file"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("내용")) {

				try {

					sql = "select * from " + "(select @ROWN:=@ROWN+1 AS RN, " + "eb.* from event eb, "
							+ "(select @ROWN:=0) as clear_RN where " + "event_board_cont like ? "
							+ "order by eb.event_board_no desc) as subquery " + "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						EventDTO dto = new EventDTO();

						dto.setEvent_board_no(rs.getInt("event_board_no"));
						dto.setEvent_board_title(rs.getString("event_board_title"));
						dto.setEvent_board_cont(rs.getString("event_board_cont"));
						dto.setEvent_board_date(rs.getString("event_board_date"));
						dto.setEvent_board_update(rs.getString("event_board_update"));
						dto.setEvent_board_hit(rs.getInt("event_board_hit"));
						dto.setEvent_board_file(rs.getString("event_board_file"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}

			return list;
		}

		public int countAmeSearchList(String field, String keyword) {
			
			int totalRecord = 0;
			
			openConn();
			
			if(field.equals("시설이름")) {
				
				try {
					sql = "select count(*) from hotel_amenities_info where amenities_title like ?";
					
					pstmt = con.prepareStatement(sql);
					
					pstmt.setString(1,"%" + keyword + "%");
					
					rs = pstmt.executeQuery();
					
					if(rs.next()) {
						totalRecord = rs.getInt(1);
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			} else if(field.equals("종류")) {
				
				try {
					sql = "select count(*) from hotel_amenities_info where amenities_type like ?";
					
					pstmt = con.prepareStatement(sql);
					
					pstmt.setString(1, "%" + keyword + "%");
					
					rs = pstmt.executeQuery();
					
					if(rs.next()) {
						totalRecord = rs.getInt(1);
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}
			
	
			return totalRecord;
		}

		public List<AmenitieDTO> searchAmeList(String field, String keyword, int page, int rowsize) {
			List<AmenitieDTO> list = new ArrayList<AmenitieDTO>();
			
			int startNo = (page * rowsize) - (rowsize - 1);

			int endNo = (page * rowsize);

			openConn();
			
			if(field.equals("시설이름")) {
				try {
					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "eb.* from hotel_amenities_info eb, "
							+ "(select @ROWN:=0) as clear_RN where " + " amenities_title like ? "
							+ "order by eb.amenities_type desc) as subquery " + "where RN >= ? and RN <= ?";
					
					pstmt = con.prepareStatement(sql);
					
					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);
					
					rs = pstmt.executeQuery();
					
					while(rs.next()) {
						AmenitieDTO dto = new AmenitieDTO();
						
						dto.setAme_type(rs.getString("amenities_type"));
						dto.setAme_price(rs.getInt("amenities_price"));
						dto.setAme_status(rs.getBoolean("amenities_status"));
						dto.setAme_open(rs.getString("amenities_opentime"));
						dto.setAme_close(rs.getString("amenities_closetime"));
						dto.setAme_file(rs.getString("amenities_file"));
						dto.setAme_title(rs.getString("amenities_title"));
						dto.setAme_cont(rs.getString("amenities_cont"));
						
						list.add(dto);
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
				
				
				
			} else if(field.equals("종류")) {
				
				try {
					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "eb.* from hotel_amenities_info eb, "
							+ "(select @ROWN:=0) as clear_RN where " + " amenities_type like ? "
							+ "order by eb.amenities_type desc) as subquery " + "where RN >= ? and RN <= ?";
					
					pstmt = con.prepareStatement(sql);
					
					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);
					
					rs = pstmt.executeQuery();
					
					while(rs.next()) {
						AmenitieDTO dto = new AmenitieDTO();
						
						dto.setAme_type(rs.getString("amenities_type"));
						dto.setAme_price(rs.getInt("amenities_price"));
						dto.setAme_status(rs.getBoolean("amenities_status"));
						dto.setAme_open(rs.getString("amenities_opentime"));
						dto.setAme_close(rs.getString("amenities_closetime"));
						dto.setAme_file(rs.getString("amenities_file"));
						dto.setAme_title(rs.getString("amenities_title"));
						dto.setAme_cont(rs.getString("amenities_cont"));
						
						list.add(dto);
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}
			
			return list;
		}

		public int getRoomCount() {
			int count = 0;
			
			try {

				openConn();
				
				sql = "select count(*) from room_info";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					count = rs.getInt(1);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			
			return count;
			
		}

		

		public RoomDTO getRoomContent(String pk_no) {
			RoomDTO dto = null;
			
			try {
				openConn();
				sql = "select * from room_info ri join room r on ri.room_type = r.room_type where room_pk_no = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, pk_no);
				rs = pstmt.executeQuery();
				if(rs.next()) {
					dto = new RoomDTO();
					dto.setRoom_pk_no(rs.getString("room_pk_no"));
					dto.setRoom_type(rs.getString("room_type"));
					dto.setRoom_total(rs.getInt("room_total"));
					dto.setRoom_size(rs.getString("room_size"));
					dto.setRoom_number(rs.getInt("room_number"));
					dto.setRoom_maximum(rs.getInt("room_maximum"));
					dto.setRoom_price(rs.getInt("room_price"));
					dto.setRoom_cont(rs.getString("room_cont"));
					dto.setRoom_file(rs.getString("room_file"));
					dto.setRoom_facilities(rs.getString("room_facilities"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return dto;
		}

		public List<RoomDTO> getRoomList(String type) {
			
			List<RoomDTO> list = new ArrayList<RoomDTO>();
			
			try {
				openConn();
				if(type.equals("Delus Room_S")) {
					sql = "select * from room_info ri join room r on ri.room_type = r.room_type where room_number between 201 and 210 order by room_number";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while(rs.next()) {
						RoomDTO dto = new RoomDTO();
						dto.setRoom_pk_no(rs.getString("room_pk_no"));
						dto.setRoom_number(rs.getInt("room_number"));
						dto.setRoom_size(rs.getString("room_size"));
						dto.setRoom_maximum(rs.getInt("room_maximum"));
						dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
						list.add(dto);
						
					}
				} else if(type.equals("Delus Room_D")) {
					sql = "select * from room_info ri join room r on ri.room_type = r.room_type where room_number between 211 and 220 order by room_number";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while(rs.next()) {
						RoomDTO dto = new RoomDTO();
						dto.setRoom_pk_no(rs.getString("room_pk_no"));
						dto.setRoom_number(rs.getInt("room_number"));
						dto.setRoom_size(rs.getString("room_size"));
						dto.setRoom_maximum(rs.getInt("room_maximum"));
						dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
						list.add(dto);
					}
				} else if(type.equals("Spa Delus Room")) {
					sql = "select * from room_info ri join room r on ri.room_type = r.room_type where room_number between 300 and 400 order by room_number";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while(rs.next()) {
						RoomDTO dto = new RoomDTO();
						dto.setRoom_pk_no(rs.getString("room_pk_no"));
						dto.setRoom_number(rs.getInt("room_number"));
						dto.setRoom_size(rs.getString("room_size"));
						dto.setRoom_maximum(rs.getInt("room_maximum"));
						dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
						list.add(dto);
					}
				} else if(type.equals("Pool Delus Room")) {
					sql = "select * from room_info ri join room r on ri.room_type = r.room_type where room_number between 400 and 500 order by room_number";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while(rs.next()) {
						RoomDTO dto = new RoomDTO();
						dto.setRoom_pk_no(rs.getString("room_pk_no"));
						dto.setRoom_number(rs.getInt("room_number"));
						dto.setRoom_size(rs.getString("room_size"));
						dto.setRoom_maximum(rs.getInt("room_maximum"));
						dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
						list.add(dto);
					}
				} else if(type.equals("Pool Premier Room")) {
					sql = "select * from room_info ri join room r on ri.room_type = r.room_type where room_number between 500 and 600 order by room_number";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while(rs.next()) {
						RoomDTO dto = new RoomDTO();
						dto.setRoom_pk_no(rs.getString("room_pk_no"));
						dto.setRoom_number(rs.getInt("room_number"));
						dto.setRoom_size(rs.getString("room_size"));
						dto.setRoom_maximum(rs.getInt("room_maximum"));
						dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
						list.add(dto);
					}
				} else if(type.equals("Spa Premier Room")) {
					sql = "select * from room_info ri join room r on ri.room_type = r.room_type where room_number between 600 and 700 order by room_number";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while(rs.next()) {
						RoomDTO dto = new RoomDTO();
						dto.setRoom_pk_no(rs.getString("room_pk_no"));
						dto.setRoom_number(rs.getInt("room_number"));
						dto.setRoom_size(rs.getString("room_size"));
						dto.setRoom_maximum(rs.getInt("room_maximum"));
						dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
						list.add(dto);
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			} return list;
		}

		public RoomDTO getRoomInfoContent(String type) {
			RoomDTO dto = null;
			
			try {
				openConn();
				sql = "select * from room_info where room_type = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, type);
				rs = pstmt.executeQuery();
				if(rs.next()) {
					dto = new RoomDTO();
					dto.setRoom_type(rs.getString("room_type"));
					dto.setRoom_total(rs.getInt("room_total"));
					dto.setRoom_size(rs.getString("room_size"));
					dto.setRoom_maximum(rs.getInt("room_maximum"));
					dto.setRoom_price(rs.getInt("room_price"));
					dto.setRoom_cont(rs.getString("room_cont"));
					dto.setRoom_file(rs.getString("room_file"));
					dto.setRoom_facilities(rs.getString("room_facilities"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return dto;
		}

		public int RoomInfoModify(RoomDTO dto) {
			int result = 0;
			
			try {
				openConn();
				sql = "select * from room_info where room_type = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, dto.getRoom_type());
				rs = pstmt.executeQuery();
				if(rs.next()) {
					if(dto.getRoom_file() == null) {
						sql = "update room_info set room_total = ?, room_maximum = ?, room_price = ?, room_cont = ?, room_file = ?, room_facilities = ? where room_type = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setInt(1, dto.getRoom_total());
						pstmt.setInt(2, dto.getRoom_maximum());
						pstmt.setInt(3, dto.getRoom_price());
						pstmt.setString(4, dto.getRoom_cont());
						pstmt.setString(5, dto.getRoom_file());
						pstmt.setString(6, dto.getRoom_facilities());
						pstmt.setString(7, dto.getRoom_type());
					} else {
						sql = "update room_info set room_total = ?, room_maximum = ?, room_price = ?, room_cont = ?,  room_facilities = ? where room_type = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setInt(1, dto.getRoom_total());
						pstmt.setInt(2, dto.getRoom_maximum());
						pstmt.setInt(3, dto.getRoom_price());
						pstmt.setString(4, dto.getRoom_cont());
						pstmt.setString(5, dto.getRoom_facilities());
						pstmt.setString(6, dto.getRoom_type());
					}
					result = pstmt.executeUpdate();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return result;
		}

		public int RoomRegister(RoomDTO dto) {
			 int result = 0;
		      
		      try {
		         openConn();
		         sql = "insert into room_info values(?, ?, ?, default)";
		         pstmt = con.prepareStatement(sql);
		         pstmt.setString(1, dto.getRoom_pk_no());
		         pstmt.setInt(2, dto.getRoom_number());
		         pstmt.setString(3, dto.getRoom_type());
		         result = pstmt.executeUpdate();
		      } catch (Exception e) {
		         e.printStackTrace();
		      } finally {
		         closeConn(pstmt, con);
		      }
		      return result;
		}

		public int countUserSearchList(String field, String keyword) {
			int cnt = 0;

			openConn();

			if (field.equals("이름")) {

				try {

					sql = "select count(*) from hotel_user where hotel_user_name like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					
					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("연락처")) {

				try {

					sql = "select count(*) from hotel_user where hotel_user_phone like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("회원 등급")) {

				try {

					sql = "select count(*) from hotel_user where hotel_user_rank like ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");

					rs = pstmt.executeQuery();

					if (rs.next()) {
						cnt = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}

			return cnt;
			
		}

		public List<HotelUserDTO> searchUserList(String field, String keyword, int page, int rowsize) {

			List<HotelUserDTO> list = new ArrayList<HotelUserDTO>();

			int startNo = (page * rowsize) - (rowsize - 1);

			int endNo = (page * rowsize);

			openConn();

			if (field.equals("이름")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "nb.* from hotel_user nb, "
							+ "(select @ROWN:=0) as clear_RN where " + "hotel_user_name like ? "
							+ "order by nb.hotel_user_no desc) as subquery " + "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						HotelUserDTO dto = new HotelUserDTO();

						dto.setHotel_user_no(rs.getString("hotel_user_no"));
						dto.setHotel_user_name(rs.getString("hotel_user_name"));
						dto.setHotel_user_id(rs.getString("hotel_user_id"));
						dto.setHotel_user_pwd(rs.getString("hotel_user_password"));
						dto.setHotel_user_phone(rs.getString("hotel_user_phone"));
						dto.setHotel_user_email(rs.getString("hotel_user_email"));
						dto.setHotel_user_rank(rs.getString("hotel_user_rank"));
						dto.setHotel_user_regdate(rs.getString("hotel_user_rank"));
						dto.setHotel_user_payment_info(rs.getString("hotel_user_payment_info"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("연락처")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "nb.* from hotel_user nb, "
							+ "(select @ROWN:=0) as clear_RN where " + "hotel_user_phone like ? "
							+ "order by nb.hotel_user_no desc) as subquery " + "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						HotelUserDTO dto = new HotelUserDTO();

						dto.setHotel_user_no(rs.getString("hotel_user_no"));
						dto.setHotel_user_name(rs.getString("hotel_user_name"));
						dto.setHotel_user_id(rs.getString("hotel_user_id"));
						dto.setHotel_user_pwd(rs.getString("hotel_user_password"));
						dto.setHotel_user_phone(rs.getString("hotel_user_phone"));
						dto.setHotel_user_email(rs.getString("hotel_user_email"));
						dto.setHotel_user_rank(rs.getString("hotel_user_rank"));
						dto.setHotel_user_regdate(rs.getString("hotel_user_rank"));
						dto.setHotel_user_payment_info(rs.getString("hotel_user_payment_info"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}

			} else if (field.equals("회원 등급")) {

				try {

					sql = "select * from (select @ROWN:=@ROWN+1 AS RN, " + "nb.* from hotel_user nb, "
							+ "(select @ROWN:=0) as clear_RN where " + "hotel_user_rank like ? "
							+ "order by nb.hotel_user_no desc) as subquery " + "where RN >= ? and RN <= ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, "%" + keyword + "%");
					pstmt.setInt(2, startNo);
					pstmt.setInt(3, endNo);

					rs = pstmt.executeQuery();

					while (rs.next()) {

						HotelUserDTO dto = new HotelUserDTO();

						dto.setHotel_user_no(rs.getString("hotel_user_no"));
						dto.setHotel_user_name(rs.getString("hotel_user_name"));
						dto.setHotel_user_id(rs.getString("hotel_user_id"));
						dto.setHotel_user_pwd(rs.getString("hotel_user_password"));
						dto.setHotel_user_phone(rs.getString("hotel_user_phone"));
						dto.setHotel_user_email(rs.getString("hotel_user_email"));
						dto.setHotel_user_rank(rs.getString("hotel_user_rank"));
						dto.setHotel_user_regdate(rs.getString("hotel_user_rank"));
						dto.setHotel_user_payment_info(rs.getString("hotel_user_payment_info"));

						list.add(dto);

					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					closeConn(rs, pstmt, con);
				}
			}

			return list;
			
		}

		public int getUserReviewCount(String userId) {
			int count = 0;
			
			
			try {
				openConn();
				
				sql = "select count(*) from room_review WHERE room_review_writer_id = ?";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					count = rs.getInt(1);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
				
			return count;

		}

		public List<RoomReviewDTO> userReviewList(int page, int rowsize, String userId) {
			 List<RoomReviewDTO> list = new ArrayList<>();
		        int startNo = (page * rowsize) - (rowsize - 1);
		        int endNo = (page * rowsize);
		        try {
		            openConn();
		            sql = "SELECT * FROM (SELECT @rownum:=@rownum+1 AS rnum, r.* " +
		                  "FROM room_review r, (SELECT @rownum:=0) rnum " +
		                  "WHERE room_review_writer_id = ? " +
		                  "ORDER BY room_review_no ASC) AS subquery " +
		                  "WHERE rnum BETWEEN ? AND ?";
		            pstmt = con.prepareStatement(sql);
		            pstmt.setString(1, userId);
		            pstmt.setInt(2, startNo);
		            pstmt.setInt(3, endNo);
		            rs = pstmt.executeQuery();
		            while (rs.next()) {
		                RoomReviewDTO dto = new RoomReviewDTO();
		                dto.setRoom_review_no(rs.getString("room_review_no"));
		                dto.setRoom_review_writer_id(rs.getString("room_review_writer_id"));
		                dto.setRoom_review_title(rs.getString("room_review_title"));
		                dto.setRoom_review_cont(rs.getString("room_review_cont"));
		                dto.setRoom_review_date(rs.getString("room_review_date"));
		                dto.setRoom_review_update(rs.getString("room_review_update"));
		                dto.setRoom_review_file(rs.getString("room_review_file"));
		                dto.setRoom_review_hit(rs.getInt("room_review_hit"));
		                dto.setRoom_review_purchase_no(rs.getString("room_review_purchase_no"));
		                list.add(dto);
		            }
		        } catch (SQLException e) {
		            e.printStackTrace();
		        } finally {
		            closeConn(rs, pstmt, con);
		        }
		        return list;

		}

		public List<PurchaseHistoryDTO> getPurchaseHistoryUser(String userId) {
 List<PurchaseHistoryDTO> reservedRooms = new ArrayList<>();
			 
			 
			 try {
				 openConn(); 
				 
				 sql = "select * from purchase_no where user_id = ?";
				 
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, userId);
				
				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					
					PurchaseHistoryDTO room = new PurchaseHistoryDTO();
					
					room.setPurchase_no(rs.getString("purchase_no"));
					room.setPurchase_user_no(rs.getString("purchase_user_no"));
					room.setPurchase_room_no(rs.getString("purchase_room_no"));
					room.setPurchase_room_price(rs.getString("purchase_room_price"));
					room.setPurchase_reservate_no(rs.getString("purchase_reservate_no"));
					room.setPurchase_date(rs.getString("purchase_date"));
					room.setPurchase_room_reivew_status(rs.getBoolean("purchase_room_reivew_status"));
					
					reservedRooms.add(room);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				closeConn(rs, pstmt, con);
			}
			 
			 return reservedRooms;

		}

		public PackageDTO packageContent(String package_merchandise_no) {
			PackageDTO dto = null;

			try {
				openConn();

				sql = "select * from package where package_merchandise_no = ?";

				pstmt = con.prepareStatement(sql);

				pstmt.setString(1, package_merchandise_no);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					dto = new PackageDTO();

					dto.setPackage_merchandise_no(rs.getString("package_merchandise_no"));
					dto.setPackage_title(rs.getString("package_title"));
					dto.setPackage_cont(rs.getString("package_cont"));
					dto.setRoom_type(rs.getString("room_type"));
					dto.setOption_type(rs.getString("option_type"));
					dto.setPackage_start_date(rs.getString("package_start_date"));
					dto.setPackage_end_date(rs.getString("package_end_date"));
					dto.setPackage_date(rs.getString("package_date"));
					dto.setPackage_update(rs.getString("package_update"));
					dto.setPackage_file(rs.getString("package_file"));
					dto.setPackage_purchase_no(rs.getString("package_purchase_no"));
					dto.setPackage_purchase_status(rs.getBoolean("package_purchase_status"));
					dto.setPackage_price(rs.getString("package_price"));
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			return dto;
		}

		public int modifypackage(PackageDTO dto) {
			int result = 0;

			try {
				openConn();

				if (dto.getPackage_file() == null) {

					// 첨부파일이 없는 경우
					sql = " update package set " 
							+ "package_title = ?, package_cont = ?, " 
							+ "package_update = now() "
							+ "where package_merchandise_no = ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, dto.getPackage_title());
					pstmt.setString(2, dto.getPackage_cont());
					pstmt.setString(3, dto.getPackage_merchandise_no());
				} else {
					// 첨부파일이 있는경우
					sql = " update package set " + "package_title = ?, " + "package_cont = ?, " + "package_file = ?, "
							+ "package_update = now() " + "where package_merchandise_no = ?";

					pstmt = con.prepareStatement(sql);

					pstmt.setString(1, dto.getPackage_title());
					pstmt.setString(2, dto.getPackage_cont());
					pstmt.setString(3, dto.getPackage_file());
					pstmt.setString(4, dto.getPackage_merchandise_no());
				}

				result = pstmt.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			return result;
		}

		public int deletePackage(String no) {
			int result = 0;

			try {
				openConn();

				sql = "delete from package where package_merchandise_no = ?";

				pstmt = con.prepareStatement(sql);

				pstmt.setString(1, no);

				result = pstmt.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			return result;
		}

		

	
		

		
		

		

} // class end
