package com.hotel.board;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.*;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.NoticeDTO;

public class PrintNoticeMainAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		List<NoticeDTO> list = dao.printNoticeMain();
		
		PrintWriter out = response.getWriter();
		
		if(list != null) {
			JSONArray jsonArray = new JSONArray();
			for (NoticeDTO notice : list) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("no", notice.getNotice_board_no());
				jsonObject.put("title", notice.getNotice_board_title());
				String date = notice.getNotice_board_update();
				if(date == null || date.isEmpty()) {
					date = notice.getNotice_board_date();
				}
				jsonObject.put("date", date);
				jsonArray.add(jsonObject);
			}
			response.setContentType("application/json;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			out.print(jsonArray.toJSONString());
		} else {
			out.println("[]");
		}
		 out.close();
		
		return null;
	}

}
