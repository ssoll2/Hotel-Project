package com.hotel.mypage;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.PurchaseHistoryDTO;
import com.hotel.model.RoomReviewDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class MypageReviewWriteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		RoomReviewDTO dto = new RoomReviewDTO();
		PurchaseHistoryDTO p_dto = new PurchaseHistoryDTO();
		
		String saveFolder = "D:\\유니티\\자바교육\\hom_workspace\\Hotel_Delus\\src\\main\\webapp\\upload_images";
		
		int fileSize = 10 * 1024 * 1024;
		
		MultipartRequest multi = new MultipartRequest (
				request,
				saveFolder,
				fileSize,
				"UTF-8",
				new DefaultFileRenamePolicy()
				);
		
		HttpSession session = request.getSession();
		
		HotelUserDTO cont = (HotelUserDTO)session.getAttribute("dto");
		String History_id =  multi.getParameter("purchase_no");
		
		String user_id = cont.getHotel_user_id();		
		String review_title = multi.getParameter("review_title").trim();
		String review_cont  = multi.getParameter("review_cont").trim();
	   
		
		File review_file = multi.getFile("review_file");
		
		if(review_file != null) {
			String fileName = review_file.getName();
			System.out.println("fileName = " + fileName);
			
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DAY_OF_MONTH);
			
			String homedir = saveFolder + "/" + year + "-" + month + "-" + day;
			
			File path = new File(homedir);
			
			if(!path.exists()) {
				path.mkdir();
			}
			
			String reFileName = "review_" + fileName;
			
			review_file.renameTo(new File(homedir + "/" + reFileName));
			
			String fileDBName = year + "-" + month + "-" + day + "/" + reFileName;
			
			dto.setRoom_review_file(fileDBName);
		}
		
		dto.setRoom_review_writer_id(user_id);
		dto.setRoom_review_title(review_title);
		dto.setRoom_review_cont(review_cont);
		dto.setRoom_review_purchase_no(History_id);
		
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.insertMypageReview(dto);
		
		boolean overlap = dao.ReviewCheck(History_id);
		
		if(overlap) {
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('이미 등록된 리뷰가 있습니다.')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
			return null;
		}
		
		if (check > 0) {
			
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('리뷰가 등록되었습니다.')");
			out.println("location.href='my_review_list'");
			out.println("</script>");
			out.close();
		}else {		
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('공지사항 글 등록에 실패했습니다. 입력한 정보를 다시한번 확인하세요.')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}
		
		
		return null;
	}

}
