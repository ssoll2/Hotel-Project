package com.hotel.mypage.review;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelUserDTO;

public class MypageReviewWriteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 
		String user_id = request.getParameter("user_id").trim();		
		String purchase_no = request.getParameter("purchase_no").trim();
		
		request.setAttribute("user_id", user_id);	
		request.setAttribute("purchase_no", purchase_no);
		
		System.out.println(user_id);
		
		
		ActionForward forward = new ActionForward();
	        forward.setRedirect(false);
	        forward.setPath("/WEB-INF/views/mypage/review/mypage_review_write.jsp");

	        return forward;
	}

}
