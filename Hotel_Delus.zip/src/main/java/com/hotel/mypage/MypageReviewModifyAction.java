package com.hotel.mypage;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomReviewDTO;

public class MypageReviewModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String review_no = request.getParameter("no").trim();
		
		int page = Integer.parseInt(request.getParameter("page").trim());
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		RoomReviewDTO dto = dao.getReviewModify(review_no);
		
		request.setAttribute("cont", dto);
		request.setAttribute("page", page);
		
		ActionForward forward = new ActionForward();
		
		
		
		forward.setPath("/WEB-INF/views/mypage/review/mypage_review_modify.jsp");
		
		return forward;
	}

}
