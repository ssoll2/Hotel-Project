package com.hotel.mypage;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.PurchaseHistoryDTO;

public class MypageRevuewInquiryAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();

        HttpSession session = request.getSession(false);
        HotelUserDTO user = (HotelUserDTO) session.getAttribute("dto");

        if (user == null) {
            ActionForward forward = new ActionForward();
            forward.setRedirect(true);
            forward.setPath("/Hotel_Delus/user_login");
            return forward;
        }

        String userId = user.getHotel_user_id();
        List<PurchaseHistoryDTO> reservedRooms = dao.getPurchaseHistoryUser(userId);

        request.setAttribute("roomList", reservedRooms);

        ActionForward forward = new ActionForward();
        forward.setRedirect(false);
        forward.setPath("/WEB-INF/views/mypage/review/room_inquiry_list.jsp");

        return forward;
    }
}