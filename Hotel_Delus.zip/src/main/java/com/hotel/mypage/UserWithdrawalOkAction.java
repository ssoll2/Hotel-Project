package com.hotel.mypage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;

public class UserWithdrawalOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String check_pwd = request.getParameter("user_pwd_ok").trim();
		System.out.println(check_pwd);
		
		String user_no = request.getParameter("user_no").trim();
		HttpSession session = request.getSession();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		PrintWriter out = response.getWriter();
		
		HotelUserDTO user = dao.UserContect(user_no);
		
		if(check_pwd.equals(user.getHotel_user_pwd())) {
			int check = dao.withdrawalOk(user_no);
			
			if(check > 0) {
				dao.updateSequence(user_no);
				session.invalidate();
				out.println("<script>");
				out.println("alert('탈퇴하였습니다')");
				out.println("location.href='withdarawal_page'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('실패하였습니다')");
				out.println("history.back()");
				out.println("</script>");
			}	
		}else {
			out.println("<script>");
			out.println("alert('비밀번호가 일치하지 않습니다 다시 확인해 주세요')");
			out.println("history.back()");
			out.println("</script>");
		}

		
		
		return null;
	}

}
