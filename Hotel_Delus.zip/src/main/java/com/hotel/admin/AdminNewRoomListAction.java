package com.hotel.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RoomDAO;
import com.hotel.model.RoomDTO;

public class AdminNewRoomListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		RoomDAO dao = RoomDAO.getInstance();
		
		List<RoomDTO> list = dao.getRoomList();
		
		request.setAttribute("List", list);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/admin_roomList.jsp");

		return forward;
	}

}
// room 테이블 리스트 불러오는 액션