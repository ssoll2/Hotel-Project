package com.hotel.admin;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RegistDAO;
import com.hotel.model.RegistDTO;


public class AdminRegisterNewRegisterAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		RegistDTO dto = new RegistDTO();
		
		String room_type = request.getParameter("room_type").trim();
		int room_total = Integer.parseInt(request.getParameter("room_total").trim());
		float room_size = Float.parseFloat(request.getParameter("room_size").trim());
		int room_maximum = Integer.parseInt(request.getParameter("room_max").trim());
		int room_price = Integer.parseInt(request.getParameter("room_price").trim());
		String room_cont = request.getParameter("room_cont").trim();
		String room_file = request.getParameter("room_file").trim();
		String room_facilities = request.getParameter("room_fac").trim();
		
		dto.setRoom_type(room_type);
		dto.setRoom_total(room_total);
		dto.setRoom_size(room_size);
		dto.setRoom_maximum(room_maximum);
		dto.setRoom_price(room_price);
		dto.setRoom_cont(room_cont);
		dto.setRoom_file(room_file);
		dto.setRoom_facilities(room_facilities);
		
		RegistDAO dao = RegistDAO.getInstance();
		
		int check = dao.RegisterRoom(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('완료')");
			out.println("window.location.href='admin_room_register'");
			out.println("</script>");	
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}
}
// room info 테이블에 DB 등록 액션