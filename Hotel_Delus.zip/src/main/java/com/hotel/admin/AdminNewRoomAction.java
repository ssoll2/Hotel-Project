package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RoomDAO;
import com.hotel.model.RoomDTO;

public class AdminNewRoomAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		RoomDTO dto = new RoomDTO();
		
		String room_type = request.getParameter("room_type").trim();
		String room_number = request.getParameter("room_number").trim();

		SimpleDateFormat sdf = new SimpleDateFormat("MMddhhmmss");
		Calendar c1 = Calendar.getInstance();
		String date = sdf.format(c1.getTime());
		
		String type = null;
		String number = room_number;
		
		if(room_type.equals("Delus Room_S")) {
			type = "DR_S";
		} else if(room_type.equals("Delus Room_D")) {
			type = "DR_D";
		} else if(room_type.equals("Spa Delus Room")) {
			type = "SDR";
		} else if(room_type.equals("Pool Delus Room")) {
			type = "PDR";
		} else if(room_type.equals("Pool Premier Room")) {
			type = "PPR";
		} else if(room_type.equals("Spa Premier Room")) {
			type = "SPR";
		} else if(room_type.equals("Pool Suite Room")) {
			type = "PSR";
		}

		dto.setRoom_pk_no(type + "_" + date + "_" + number);
		dto.setRoom_number(room_number);
		dto.setRoom_type(room_type);
		
		RoomDAO dao = RoomDAO.getInstance();
		
		int check = dao.RoomRegister(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('완료')");
			out.println("window.location.href='admin_newroom_roomRegist'");
			out.println("</script>");	
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
// room 테이블 DB 등록 액션
