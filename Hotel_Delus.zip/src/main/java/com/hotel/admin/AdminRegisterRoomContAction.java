package com.hotel.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RegistDAO;
import com.hotel.model.RegistDTO;

public class AdminRegisterRoomContAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String room_pk_no = request.getParameter("no").trim();
		
		RegistDAO dao = RegistDAO.getInstance();
		
		RegistDTO cont = dao.getRegistContent(room_pk_no);
		
		request.setAttribute("Cont", cont);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/admin_room_cont.jsp");

		return forward;

	}

}
// room info 테이블 상세정보 가져오는 액션