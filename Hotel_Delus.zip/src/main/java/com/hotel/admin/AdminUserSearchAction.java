package com.hotel.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;

public class AdminUserSearchAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String user_field = request.getParameter("search_field").trim();
		String user_keyword = request.getParameter("keyword").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		List<HotelUserDTO> searchList = dao.searchUserList(user_field, user_keyword);
		
		request.setAttribute("Search", searchList);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("/WEB-INF/views/admin/user/admin_user_Searchlist.jsp");
		
		return forward;
	}

}
