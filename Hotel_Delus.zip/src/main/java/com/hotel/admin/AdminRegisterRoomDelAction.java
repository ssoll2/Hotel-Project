package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RegistDAO;
import com.hotel.model.RegistDTO;

public class AdminRegisterRoomDelAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String room_pk_no = request.getParameter("no").trim();
		
		RegistDAO dao = RegistDAO.getInstance();
		
		RegistDTO dto = dao.getRegistContent(room_pk_no);
		
		int check = dao.DeleteRoom(room_pk_no);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			ActionForward forward = new ActionForward();
			forward.setPath("/WEB-INF/views/admin/admin_room_list.jsp");
			return forward;
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
// room info DB 삭제 액션