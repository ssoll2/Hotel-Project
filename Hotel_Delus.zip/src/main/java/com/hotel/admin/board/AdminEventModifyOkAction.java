package com.hotel.admin.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.EventDTO;
import com.hotel.model.HotelTotalDAO;

public class AdminEventModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String board_no = request.getParameter("board_no").trim();
		String board_title = request.getParameter("board_title").trim();
		String board_cont = request.getParameter("board_cont").trim();
		String board_start_date = request.getParameter("board_start_date").trim();
		String board_end_date = request.getParameter("board_end_date").trim();
		String board_file = request.getParameter("board_file").trim();
		
		EventDTO dto = new EventDTO();
		
		dto.setEvent_board_no(board_no);
		dto.setEvent_board_title(board_title);
		dto.setEvent_board_cont(board_cont);
		dto.setEvent_board_start_date(board_start_date);
		dto.setEvent_board_end_date(board_end_date);
		dto.setEvent_board_file(board_file);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.upateAdminEvent(dto);
				
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('이벤트 수정 성공')");
			out.println("location.href='admin_event_list'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('이벤트 수정 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;
	}

}
