package com.hotel.admin.board;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.NoticeDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class AdminNoticeRegisterOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		NoticeDTO dto = new NoticeDTO();
		
		String saveFolder = "D:\\jsp_work\\Hotel_Delus\\src\\main\\webapp\\upload_images";
		
		int fileSize = 10 * 1024 * 1024;
		
		 MultipartRequest multi = new MultipartRequest(
		            request,       // 일반적인 request 객체
		            saveFolder,    // 첨부파일이 저장될 경로
		            fileSize,      // 업로드할 첨부파일의 최대 크기
		            "UTF-8",      // 문자 인코딩 방식
		            new DefaultFileRenamePolicy());   // 첨부파일의 이름이 같은 경우 중복이 안되게 설정
		
		String notice_board_title = multi.getParameter("notice_board_title").trim();
		String notice_board_cont = multi.getParameter("notice_board_cont").trim();
		
		File notice_file = multi.getFile("notice_file");
		
		if(notice_file != null) {
			String fileName = notice_file.getName();
			System.out.println("fileName = " + fileName);
			
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DAY_OF_MONTH);
			
			String homedir = saveFolder + "/" + year + "-" + month + "-" + day;
			
			File path = new File(homedir);
			
			if(!path.exists()) {
				path.mkdir();
			}
			String reFileName = "notice_" + fileName;
			
			notice_file.renameTo(new File(homedir + "/" + reFileName));
			
			String fileDBName = year + "-" + month + "-" + day + "/" + reFileName;
			
			dto.setNotice_board_file(fileDBName);
					
		}
		
		
		dto.setNotice_board_title(notice_board_title);
		dto.setNotice_board_cont(notice_board_cont);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.insertAdminNotice(dto);
		
		PrintWriter out = response.getWriter();
		
		if (check > 0) {
			
			
			out.println("<script>");
			out.println("alert('공지사항에 등록되었습니다.')");
			out.println("location.href='my_review_list'");
			out.println("</script>");
			out.close();
		} else {
			
			out.println("<script>");
			out.println("alert('리뷰 등록에 실패했습니다. 입력한 정보를 다시한번 확인해주세요.')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}
		
		
		return null;
	}

}
