package com.hotel.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RegistDAO;
import com.hotel.model.RegistDTO;

public class AdminRegisterRoomUpdateAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String room_pk_no = request.getParameter("no").trim();
		
		RegistDAO dao = RegistDAO.getInstance();
		
		RegistDTO dto = dao.getRegistContent(room_pk_no);
		
		request.setAttribute("Update", dto);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/admin_room_update.jsp");

		return forward;
	}

}
// room info 수정 페이지로 넘어가는 액션