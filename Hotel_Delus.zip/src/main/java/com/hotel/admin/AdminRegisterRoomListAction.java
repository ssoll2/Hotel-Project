package com.hotel.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RegistDAO;
import com.hotel.model.RegistDTO;

public class AdminRegisterRoomListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RegistDAO dao = RegistDAO.getInstance();

		List<RegistDTO> list = dao.getRoomList();

		request.setAttribute("List", list);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/admin_room_list.jsp");

		return forward;

	}

}
// room info 테이블 리스트 불러오는 액션