package com.hotel.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RegistDAO;
import com.hotel.model.RegistDTO;

public class AdminRegisterRoomSearchAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String field = request.getParameter("field").trim();
		String keyword = request.getParameter("keyword").trim();
		
		RegistDAO dao = RegistDAO.getInstance();
		
		List<RegistDTO> list = dao.SearchRoom(field, keyword);
		
		request.setAttribute("keyword", keyword);
		request.setAttribute("field", field);
		request.setAttribute("List", list);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/admin_room_search.jsp");

		return forward;
	}

}
// room info 테이블 검색 액션