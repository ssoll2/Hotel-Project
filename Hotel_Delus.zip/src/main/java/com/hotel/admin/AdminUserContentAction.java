package com.hotel.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;

public class AdminUserContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String user_no = request.getParameter("no").trim();
		int nowPage = Integer.parseInt(request.getParameter("page").trim());
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		HotelUserDTO cont = dao.getAdminUserContent(user_no);
		
		request.setAttribute("dto" , cont);
		request.setAttribute("page", nowPage);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("/WEB-INF/views/admin/user/admin_user_content.jsp");
				
		return forward;
	}

}
