package com.hotel.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;

public class AdminNewRoomGoRegistAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/admin_roomRegist.jsp");

		return forward;
		
	}

}
// room info 등록 페이지에서 room 등록 페이지로 넘어가는 액션