package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.RegistDAO;
import com.hotel.model.RegistDTO;

public class AdminRegisterRoomUpdateOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String room_pk_no = request.getParameter("no").trim();
		String room_type = request.getParameter("type");
		String room_number = request.getParameter("number");
		int room_total = Integer.parseInt(request.getParameter("total"));
		float room_size = Float.parseFloat(request.getParameter("size"));
		int room_maximum = Integer.parseInt(request.getParameter("max"));
		int room_price = Integer.parseInt(request.getParameter("price"));
		String room_cont = request.getParameter("cont");
		String room_file = request.getParameter("file");
		String room_facilities = request.getParameter("fac");
		
		RegistDTO dto = new RegistDTO();
		

		dto.setRoom_type(room_type);

		dto.setRoom_total(room_total);
		dto.setRoom_size(room_size);
		dto.setRoom_maximum(room_maximum);
		dto.setRoom_price(room_price);
		dto.setRoom_cont(room_cont);
		dto.setRoom_file(room_file);
		dto.setRoom_facilities(room_facilities);
		
		RegistDAO dao = RegistDAO.getInstance();
		
		int check = dao.UpdateRoom(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("location.href='admin_room_cont?no="+room_pk_no+"'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		return null;
	}

}
// room info DB 수정하는 액션