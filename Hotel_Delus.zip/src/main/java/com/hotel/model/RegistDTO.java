package com.hotel.model;

public class RegistDTO {

	private String room_type;
	private int room_total;
	private float room_size;
	private int room_maximum;
	private int room_price;
	private String room_cont;
	private String room_file;
	private String room_facilities;
	
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public int getRoom_total() {
		return room_total;
	}
	public void setRoom_total(int room_total) {
		this.room_total = room_total;
	}
	public float getRoom_size() {
		return room_size;
	}
	public void setRoom_size(float room_size) {
		this.room_size = room_size;
	}
	public int getRoom_maximum() {
		return room_maximum;
	}
	public void setRoom_maximum(int room_maximum) {
		this.room_maximum = room_maximum;
	}
	public int getRoom_price() {
		return room_price;
	}
	public void setRoom_price(int room_price) {
		this.room_price = room_price;
	}
	public String getRoom_cont() {
		return room_cont;
	}
	public void setRoom_cont(String room_cont) {
		this.room_cont = room_cont;
	}
	public String getRoom_file() {
		return room_file;
	}
	public void setRoom_file(String room_file) {
		this.room_file = room_file;
	}
	public String getRoom_facilities() {
		return room_facilities;
	}
	public void setRoom_facilities(String room_facilities) {
		this.room_facilities = room_facilities;
	}
	
}
