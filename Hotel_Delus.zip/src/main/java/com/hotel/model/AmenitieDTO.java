package com.hotel.model;

public class AmenitieDTO {
	private String amenities_type;	// 종류
	private int amenities_price;		// 가격
	private boolean amenities_status;	// 운영상태
	private String amenities_open;	// 입장시간
	private String amenities_close;	// 퇴장
	private String amenities_title;	// 제목	
	private String amenities_cont;	// 내용
	private String amenities_file;
	public String getAmenities_type() {
		return amenities_type;
	}
	public void setAmenities_type(String amenities_type) {
		this.amenities_type = amenities_type;
	}
	public int getAmenities_price() {
		return amenities_price;
	}
	public void setAmenities_price(int amenities_price) {
		this.amenities_price = amenities_price;
	}
	public boolean isAmenities_status() {
		return amenities_status;
	}
	public void setAmenities_status(boolean amenities_status) {
		this.amenities_status = amenities_status;
	}
	public String getAmenities_open() {
		return amenities_open;
	}
	public void setAmenities_open(String amenities_open) {
		this.amenities_open = amenities_open;
	}
	public String getAmenities_close() {
		return amenities_close;
	}
	public void setAmenities_close(String amenities_close) {
		this.amenities_close = amenities_close;
	}
	public String getAmenities_title() {
		return amenities_title;
	}
	public void setAmenities_title(String amenities_title) {
		this.amenities_title = amenities_title;
	}
	public String getAmenities_cont() {
		return amenities_cont;
	}
	public void setAmenities_cont(String amenities_cont) {
		this.amenities_cont = amenities_cont;
	}
	public String getAmenities_file() {
		return amenities_file;
	}
	public void setAmenities_file(String amenities_file) {
		this.amenities_file = amenities_file;
	}	
	
}
