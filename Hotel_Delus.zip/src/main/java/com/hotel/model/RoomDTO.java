package com.hotel.model;

public class RoomDTO {
	private String room_pk_no;
	private int room_number;
	private String room_type;
	private boolean room_reservate_status;
	private int room_total;
	private String room_size;
	private int room_maximum;
	private int room_price;
	private String room_cont;
	private String room_file;
	private String room_facilities;
	private String adult;
	private String child;
	
	public String getAdult() {
		return adult;
	}
	public void setAdult(String adult) {
		this.adult = adult;
	}
	public String getChild() {
		return child;
	}
	public void setChild(String child) {
		this.child = child;
	}
	public String getRoom_pk_no() {
		return room_pk_no;
	}
	public void setRoom_pk_no(String room_pk_no) {
		this.room_pk_no = room_pk_no;
	}
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public boolean isRoom_reservate_status() {
		return room_reservate_status;
	}
	public void setRoom_reservate_status(boolean room_reservate_status) {
		this.room_reservate_status = room_reservate_status;
	}
	public int getRoom_total() {
		return room_total;
	}
	public void setRoom_total(int room_total) {
		this.room_total = room_total;
	}
	public String getRoom_size() {
		return room_size;
	}
	public void setRoom_size(String room_size) {
		this.room_size = room_size;
	}
	public int getRoom_maximum() {
		return room_maximum;
	}
	public void setRoom_maximum(int room_maximum) {
		this.room_maximum = room_maximum;
	}
	public int getRoom_price() {
		return room_price;
	}
	public void setRoom_price(int room_price) {
		this.room_price = room_price;
	}
	public String getRoom_cont() {
		return room_cont;
	}
	public void setRoom_cont(String room_cont) {
		this.room_cont = room_cont;
	}
	public String getRoom_file() {
		return room_file;
	}
	public void setRoom_file(String room_file) {
		this.room_file = room_file;
	}
	public String getRoom_facilities() {
		return room_facilities;
	}
	public void setRoom_facilities(String room_facilities) {
		this.room_facilities = room_facilities;
	}
	
	
	
	
}
