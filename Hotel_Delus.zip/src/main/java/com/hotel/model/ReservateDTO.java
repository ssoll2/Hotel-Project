package com.hotel.model;

public class ReservateDTO {

}
