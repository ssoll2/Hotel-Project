package com.hotel.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class RegistDAO {

	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	String sql = null;
	
	private static RegistDAO instance = null;
	
	private RegistDAO() {}
	
	public static RegistDAO getInstance() {
		if(instance == null) {
			instance = new RegistDAO();
		}
		return instance;
	} // end
	
	public void openConn() {
		
		try {
			
			Context initCtx = new InitialContext();
			
			Context ctx = (Context)initCtx.lookup("java:comp/env");
			
			DataSource ds = (DataSource)ctx.lookup("jdbc/mysql");
			
			con = ds.getConnection();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // end
	
	public void closeConn(ResultSet rs, PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			
			if(pstmt != null) pstmt.close();
			
			if(con != null) con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // end

	public void closeConn(PreparedStatement pstmt, Connection con) {
		
		try {
			
			if(pstmt != null) pstmt.close();
			
			if(con != null) con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // end
	
	
	
	
	
	
	public int RegisterRoom(RegistDTO dto) {
		
		int result = 0;

		try {
			openConn();
			sql = "insert into room_info values(?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getRoom_type());
			pstmt.setInt(2, dto.getRoom_total());
			pstmt.setFloat(3, dto.getRoom_size());
			pstmt.setInt(4, dto.getRoom_maximum());
			pstmt.setInt(5, dto.getRoom_price());
			pstmt.setString(6, dto.getRoom_cont());
			pstmt.setString(7, dto.getRoom_file());
			pstmt.setString(8, dto.getRoom_facilities());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(pstmt, con);
		}
		return result;
	} // end

	
	public List<RegistDTO> getRoomList() {
		
		List<RegistDTO> list = new ArrayList<RegistDTO>();

		try {
			openConn();
			sql = "select * from room_info";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RegistDTO dto = new RegistDTO();
				dto.setRoom_type(rs.getString("room_type"));
				dto.setRoom_total(rs.getInt("room_total"));
				dto.setRoom_size(rs.getFloat("room_size"));
				dto.setRoom_maximum(rs.getInt("room_maximum"));
				dto.setRoom_price(rs.getInt("room_price"));
				dto.setRoom_cont(rs.getString("room_cont"));
				dto.setRoom_file(rs.getString("room_file"));
				dto.setRoom_facilities(rs.getString("room_facilities"));
				list.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		} return list;
	} // end
	
	public RegistDTO getRegistContent(String no) {
		
		 RegistDTO dto = null;
		 
		 try {
			openConn();
			sql = "select * from room_info where room_pk_no = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, no);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				dto = new RegistDTO();
				dto.setRoom_type(rs.getString("room_type"));
				dto.setRoom_total(rs.getInt("room_total"));
				dto.setRoom_size(rs.getFloat("room_size"));
				dto.setRoom_maximum(rs.getInt("room_maximum"));
				dto.setRoom_price(rs.getInt("room_price"));
				dto.setRoom_cont(rs.getString("room_cont"));
				dto.setRoom_file(rs.getString("room_file"));
				dto.setRoom_facilities(rs.getString("room_facilities"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		 return dto;
	} // end
	
	public int DeleteRoom(String no) {
		
		int result = 0;
		
		try {
			openConn();			
			sql = "delete from room_info where room_pk_no = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, no);
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		return result;
	} // end
	
	public int UpdateRoom(RegistDTO dto) {
		
		int result = 0;

		try {
			openConn();
			sql = "update room_info set room_type = ?, room_number = ?, room_total = ?, room_size = ?, room_maximum = ?, room_price = ?, room_cont = ?, room_file = ?, room_facilities = ? where room_pk_no = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(2, dto.getRoom_type());
			pstmt.setInt(4, dto.getRoom_total());
			pstmt.setFloat(5, dto.getRoom_size());
			pstmt.setInt(6, dto.getRoom_maximum());
			pstmt.setInt(7, dto.getRoom_price());
			pstmt.setString(8, dto.getRoom_cont());
			pstmt.setString(9, dto.getRoom_file());
			pstmt.setString(10, dto.getRoom_facilities());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(pstmt, con);
		}
		return result;
	} // end
	
	public List<RegistDTO> SearchRoom(String field, String keyword) {
		
		List<RegistDTO> searchList = new ArrayList<RegistDTO>();
		
		try {
			openConn();
			sql = "select * from room_info";
			if(field.equals("roomnum")) {
				sql += " where room_pk_no like ?";
			} else if(field.equals("roomtype")) {
				sql += " where room_type like ?";
			}
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+keyword+"%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RegistDTO dto = new RegistDTO();
				dto.setRoom_type(rs.getString("room_type"));
				dto.setRoom_total(rs.getInt("room_total"));
				dto.setRoom_size(rs.getFloat("room_size"));
				dto.setRoom_maximum(rs.getInt("room_maximum"));
				dto.setRoom_price(rs.getInt("room_price"));
				dto.setRoom_cont(rs.getString("room_cont"));
				dto.setRoom_file(rs.getString("room_file"));
				dto.setRoom_facilities(rs.getString("room_facilities"));
				searchList.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		return searchList;
	} // end
}
