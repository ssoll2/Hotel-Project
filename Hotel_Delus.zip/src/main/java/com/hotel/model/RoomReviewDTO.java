package com.hotel.model;

public class RoomReviewDTO {
	
	private String room_review_no;
	private String room_review_writer_id;
	private String room_review_title;
	private String room_review_cont;
	private String room_review_date;
	private String room_review_update;
	private String room_review_file;
	private int room_review_hit;
	private String room_review_purchase_no;
	public String getRoom_review_no() {
		return room_review_no;
	}
	public void setRoom_review_no(String room_review_no) {
		this.room_review_no = room_review_no;
	}
	public String getRoom_review_writer_id() {
		return room_review_writer_id;
	}
	public void setRoom_review_writer_id(String room_review_writer_id) {
		this.room_review_writer_id = room_review_writer_id;
	}
	public String getRoom_review_title() {
		return room_review_title;
	}
	public void setRoom_review_title(String room_review_title) {
		this.room_review_title = room_review_title;
	}
	public String getRoom_review_cont() {
		return room_review_cont;
	}
	public void setRoom_review_cont(String room_review_cont) {
		this.room_review_cont = room_review_cont;
	}
	public String getRoom_review_date() {
		return room_review_date;
	}
	public void setRoom_review_date(String room_review_date) {
		this.room_review_date = room_review_date;
	}
	public String getRoom_review_update() {
		return room_review_update;
	}
	public void setRoom_review_update(String room_review_update) {
		this.room_review_update = room_review_update;
	}
	public String getRoom_review_file() {
		return room_review_file;
	}
	public void setRoom_review_file(String room_review_file) {
		this.room_review_file = room_review_file;
	}
	public int getRoom_review_hit() {
		return room_review_hit;
	}
	public void setRoom_review_hit(int room_review_hit) {
		this.room_review_hit = room_review_hit;
	}
	public String getRoom_review_purchase_no() {
		return room_review_purchase_no;
	}
	public void setRoom_review_purchase_no(String room_review_purchase_no) {
		this.room_review_purchase_no = room_review_purchase_no;
	}
	
	
	
	
	
}
