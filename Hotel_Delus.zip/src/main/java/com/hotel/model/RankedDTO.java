package com.hotel.model;

public class RankedDTO {

}
