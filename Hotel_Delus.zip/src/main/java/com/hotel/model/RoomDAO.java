package com.hotel.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class RoomDAO {

	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	String sql = null;
	
	private static RoomDAO instance = null;
	
	private RoomDAO() {}
	
	public static RoomDAO getInstance() {
		if(instance == null) {
			instance = new RoomDAO();
		}
		return instance;
	} // end
	
	public void openConn() {
		
		try {
			
			Context initCtx = new InitialContext();
			
			Context ctx = (Context)initCtx.lookup("java:comp/env");
			
			DataSource ds = (DataSource)ctx.lookup("jdbc/mysql");
			
			con = ds.getConnection();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // end
	
	public void closeConn(ResultSet rs, PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			
			if(pstmt != null) pstmt.close();
			
			if(con != null) con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // end

	public void closeConn(PreparedStatement pstmt, Connection con) {
		
		try {
			
			if(pstmt != null) pstmt.close();
			
			if(con != null) con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // end
	
	public int RoomRegister(RoomDTO dto) {
		
		int result = 0;
		
		try {
			openConn();
			sql = "insert into room values(?, ?, ?, default)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getRoom_pk_no());
			pstmt.setString(2, dto.getRoom_number());
			pstmt.setString(3, dto.getRoom_type());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(pstmt, con);
		}
		return result;
	} // end
	
	public List<RoomDTO> getRoomList() {
		
		List<RoomDTO> list = new ArrayList<RoomDTO>();
		
		try {
			openConn();
			sql = "select * from room";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RoomDTO dto = new RoomDTO();
				dto.setRoom_pk_no(rs.getString("room_pk_no"));
				dto.setRoom_number(rs.getString("room_number"));
				dto.setRoom_type(rs.getString("room_type"));
				dto.setRoom_reservate_status(rs.getBoolean("room_reservate_status"));
				list.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		} return list;
	} // end
}
