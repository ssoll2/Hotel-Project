package com.hotel.model;

public class EventDTO {

}
