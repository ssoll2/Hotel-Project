
$(function(){

    $.ajax({
        type: "POST",
        url: "check_login_status",
        success: function(response) {
            if (response.loggedIn == 1) {
    
                // 유저 로그인 상태일 경우
                $('.header_menu_top #user_login').hide(); // 로그인 버튼 숨기기
                $('.header_menu_top #admin_btn').hide(); // 관리자 로그인 버튼 숨기기
                $('.header_menu_top #user_logout').show();
                $('.header_menu_top #user_name').html('<a href="#">' + response.username + '</a> 님');
                $('.header_menu_top #user_name').show();
                
                // 사용자 번호도 함께 받아오기
                var userno = response.userno;
                
            } else if(response.loggedIn == 0){
            
               // 관리자 로그인 상태일 경우
                $('.header_menu_top #user_login').hide();    // 로그인 버튼 숨기기
                $('.footer_admin_login').hide();     // 관리자 로그인 버튼 숨기기
                $('.footer_admin_page').show(); // 관리자 페이지 버튼 보이기
                $('.header_menu_top #logout').show();
                $('.header_menu_top #user_name').html('<a href="admin_main">' + response.adminname + '</a> 님');
                $('.header_menu_top #user_name').show();
                
                //사용자 번호도 함께 받아오기
                var adminno = response.adminno;
                
               $('#user_mypage').removeAttr("onclick");
               $('#user_mypage').click(function() {
                  alert("관리자로 로그인했습니다!!");
               })
               
               $('.lnb-item #login_first').removeAttr("href");
               $('.lnb-item #login_first').mouseover(function() {
                  $('.lnb-item #login_first').css("cursor", "pointer");
               })
               $('.lnb-item #login_first').click(function() {
                  alert("관리자로 로그인했습니다!!");
               })
             }
              else {
               
               $('#admin_page_btn').hide();
                $('.header_menu_top #user_logout').hide();
                $('.header_menu_top #user_name').hide();
                $('.header_menu_top #user_login').show();
                $('#admin_btn').show();
               
               $('#user_mypage').removeAttr("onclick");
               $('#user_mypage').click(function() {
                  alert("로그인 후 이용하실 수 있습니다.");
                  location.href='user_login';
               });
               $('.lnb-item #login_first').removeAttr("href");
               $('.lnb-item #login_first').mouseover(function() {
                  $('.lnb-item #login_first').css("cursor", "pointer");
               })
               $('.lnb-item #login_first').click(function() {
                  alert("로그인 후 이용하실 수 있습니다.");
                  location.href='user_login';
               });
               
               
               return false;
            }
        }
    });

    $(" .mainpage_header").stop().mouseover(function(){
       
        $(".mainpage_header").stop().animate({height:"300px"});
        $(".gnb").stop().animate({ height:"250px"});
    });

    $(".mainpage_header").stop().mouseleave(function(){
        $(".mainpage_header").stop().animate({height:"104px"});
        $(".gnb").stop().animate({ height:"25px"});
});


$(".special_offers_button > li:nth-of-type(1)").click(function(){
    $(".special_offers_button > li:nth-of-type(1)").css({backgroundColor:"#c1b39391"});
    $(".special_offers_button > li:nth-of-type(2)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(3)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(4)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".offers_img_box1").css({zIndex:"5"});
    $(".offers_img_box2").css({zIndex:"2"});
    $(".offers_img_box3").css({zIndex:"2"});
    $(".offers_img_box4").css({zIndex:"2"});
})
$(".special_offers_button > li:nth-of-type(2)").click(function(){
    $(".special_offers_button > li:nth-of-type(2)").css({backgroundColor:"#c1b39391"});
    $(".special_offers_button > li:nth-of-type(1)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(3)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(4)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".offers_img_box2").css({zIndex:"5"});
    $(".offers_img_box1").css({zIndex:"2"});
    $(".offers_img_box3").css({zIndex:"2"});
    $(".offers_img_box4").css({zIndex:"2"});
})
$(".special_offers_button > li:nth-of-type(3)").click(function(){
    $(".special_offers_button > li:nth-of-type(3)").css({backgroundColor:"#c1b39391"});
    $(".special_offers_button > li:nth-of-type(2)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(1)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(4)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".offers_img_box3").css({zIndex:"5"});
    $(".offers_img_box2").css({zIndex:"2"});
    $(".offers_img_box1").css({zIndex:"2"});
    $(".offers_img_box4").css({zIndex:"2"});
})
$(".special_offers_button > li:nth-of-type(4)").click(function(){
    $(".special_offers_button > li:nth-of-type(4)").css({backgroundColor:"#c1b39391"});
    $(".special_offers_button > li:nth-of-type(2)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(3)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".special_offers_button > li:nth-of-type(1)").css({backgroundColor:"rgb(255 255 255 / 0%)"});
    $(".offers_img_box4").css({zIndex:"5"});
    $(".offers_img_box2").css({zIndex:"2"});
    $(".offers_img_box3").css({zIndex:"2"});
    $(".offers_img_box1").css({zIndex:"2"});
})


$(".membership_cont2").click(function(){

   if ($(this).width() == 830) {
        // 현재 너비가 800px이면 100px로 변경
        $(this).animate({width: "100px"});
        $(".membership_cont_ul_2").hide();
        $(".membership_cont2 p").fadeIn(500);
        $(".membership_cont1 p").hide();
    } else {
        // 현재 너비가 800px이 아니면 800px로 변경
        $(this).animate({width: "830px"});
        $(".membership_cont_ul_2").fadeIn();
        $(".membership_cont2 p").hide();
        $(".membership_cont1 p").fadeIn(200);
    }

})
$(".membership_cont3").click(function(){

   if ($(this).width() == 862) {
        // 현재 너비가 800px이면 100px로 변경
        $(this).animate({width: "100px"});
         $(".membership_cont_ul_3").hide();
         $(".membership_cont3 p").fadeIn(500);
         $(".membership_cont2 p").hide();
   
    } else {
        // 현재 너비가 800px이 아니면 800px로 변경
        $(this).animate({width: "862px"});
         $(".membership_cont_ul_3").show();
         $(".membership_cont3 p").hide();
         $(".membership_cont1 p").fadeIn(500);
         $(".membership_cont2 p").fadeIn(500);
        
    }

})

});

    
    // 로그아웃 버튼 클릭 시
$(document).on('click', '#user_logoutbtn', function(e) {
    e.preventDefault(); // 기본 동작 중단
    $.ajax({
        type: "GET",
        url: "user_logout", // 로그아웃 요청을 보낼 URL
        success: function(response) {
           alert('로그아웃 했습니다.');
           location.href='main';
        }
   });
});

