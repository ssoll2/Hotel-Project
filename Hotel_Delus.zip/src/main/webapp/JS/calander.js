$(function() {
    $('input[name="datetimes"]').daterangepicker({
      timePicker: true,
      startDate: moment().startOf('hour'),
      endDate: moment().startOf('hour').add(32, 'hour'),
      locale: {
        format: 'M/DD hh:mm A'
      }
    });

    $('input[name="datetimes"]').on('apply.daterangepicker', function(ev, picker) {
        let startDate = picker.startDate.format('YYYY-MM-DD');
        let endDate = picker.endDate.format('YYYY-MM-DD');
      });

      
  });
  
/*                            */
  
  
 document.addEventListener("DOMContentLoaded", function() {
            // 성인 + 버튼 클릭 시
            document.querySelector('.adult_plus').addEventListener('click', function(event) {
                event.preventDefault();
                var adultSelect = document.querySelector('.adult_select');
                var currentAdultCount = parseInt(adultSelect.textContent);
                adultSelect.textContent = currentAdultCount + 1;
                // Adult 아래의 숫자 업데이트
                document.querySelector('.adult_input').textContent = adultSelect.textContent + "명";
            });

            // 성인 - 버튼 클릭 시
            document.querySelector('.adult_minus').addEventListener('click', function(event) {
                event.preventDefault();
                var adultSelect = document.querySelector('.adult_select');
                var currentAdultCount = parseInt(adultSelect.textContent);
                if (currentAdultCount > 1) {
                    adultSelect.textContent = currentAdultCount - 1;
                    // Adult 아래의 숫자 업데이트
                    document.querySelector('.adult_input').textContent = adultSelect.textContent + "명";
                }
            });

            // 어린이 + 버튼 클릭 시
            document.querySelector('.children_plus').addEventListener('click', function(event) {
                event.preventDefault();
                var childrenSelect = document.querySelector('.children_select');
                var currentChildrenCount = parseInt(childrenSelect.textContent);
                childrenSelect.textContent = currentChildrenCount + 1;
                // Children 아래의 숫자 업데이트
                document.querySelector('.children_input').textContent = childrenSelect.textContent + "명";
            });

            // 어린이 - 버튼 클릭 시
            document.querySelector('.children_minus').addEventListener('click', function(event) {
                event.preventDefault();
                var childrenSelect = document.querySelector('.children_select');
                var currentChildrenCount = parseInt(childrenSelect.textContent);
                if (currentChildrenCount > 0) {
                    childrenSelect.textContent = currentChildrenCount - 1;
                    // Children 아래의 숫자 업데이트
                    document.querySelector('.children_input').textContent = childrenSelect.textContent + "명";
                }
            });
        });

         function cancelSelection() {
            // 어른과 아이의 선택된 숫자를 0으로 설정
            document.querySelector('.adult_select').textContent = '0';
            document.querySelector('.children_select').textContent = '0';
            // 선택된 숫자를 HTML 요소에 반영
            document.querySelector('.adult_input').textContent = '0명';
            document.querySelector('.children_input').textContent = '0명';
        }

        function closeNumberSelect() {
            // number_select 창 닫기
            var numberSelect = document.getElementById('numberSelect');
            numberSelect.style.display = 'none';
        }