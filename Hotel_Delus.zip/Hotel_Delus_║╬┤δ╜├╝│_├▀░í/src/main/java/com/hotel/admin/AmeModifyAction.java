package com.hotel.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.AmenitieDTO;
import com.hotel.model.HotelTotalDAO;

public class AmeModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String ame_type = request.getParameter("type").trim();
		int nowPage = Integer.parseInt(request.getParameter("page").trim());
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		AmenitieDTO dto = dao.getAmeContent(ame_type);
		
		request.setAttribute("Modify", dto);
		request.setAttribute("page", nowPage);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("/WEB-INF/views/admin/admin_ame_modify.jsp");
		
		return forward;
	}
	
}
