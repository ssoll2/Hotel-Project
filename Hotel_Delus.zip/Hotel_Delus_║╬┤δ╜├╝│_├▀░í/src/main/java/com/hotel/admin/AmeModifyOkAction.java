package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.AmenitieDTO;
import com.hotel.model.HotelTotalDAO;

public class AmeModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String ame_title = request.getParameter("ame_title").trim();
		boolean ame_status = Boolean.parseBoolean(request.getParameter("ame_status").trim());
		String ame_open = request.getParameter("ame_open").trim();
		String ame_close = request.getParameter("ame_close").trim();		
		int ame_price = Integer.parseInt(request.getParameter("ame_price").trim());
		String ame_type = request.getParameter("ame_type").trim();
		String ame_cont = request.getParameter("ame_cont").trim();
		String ame_file = request.getParameter("ame_file").trim();
		
		int nowPage = Integer.parseInt(request.getParameter("page").trim());
		
		AmenitieDTO dto = new AmenitieDTO();
		
		dto.setAme_title(ame_title);
		dto.setAme_status(ame_status);
		dto.setAme_open(ame_open);
		dto.setAme_close(ame_close);
		dto.setAme_price(ame_price);
		dto.setAme_type(ame_type);
		dto.setAme_cont(ame_cont);
		dto.setAme_file(ame_file);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.updateAme(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('수정 성공')");
			out.println("location.href='ame_content?type="+ame_type+"&page="+nowPage+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('수정 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
