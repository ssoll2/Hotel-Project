package com.hotel.model;

public class AdminDTO {

}
