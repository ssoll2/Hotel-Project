package com.hotel.admin.room;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomDTO;
import com.hotel.model.RoomInfoDTO;

public class AdminRoomInfoModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String room_type = request.getParameter("type").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		RoomInfoDTO cont = dao.getRoomInfoContent(room_type);
		
		request.setAttribute("Cont", cont);
		
		ActionForward forward = new ActionForward();
			
		forward.setPath("/WEB-INF/views/admin/room/admin_room_info_modify.jsp");
			
		return forward;
	}

}
