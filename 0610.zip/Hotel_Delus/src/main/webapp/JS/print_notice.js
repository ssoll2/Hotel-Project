/*메인 공지사항*/

function fetchNoticeList() {
    $.ajax({
        type: "GET",
        url: "print_notice",
        dataType: "json",
        success: function(response) {
            if (response.length === 0) {
                console.log("공지사항이 없습니다.");
            } else {
                printNotices(response);
            }
        },
        error: function(xhr, status, error) {
            console.error("에러:", error);
            console.error("상태:", status);
            console.error("응답:", xhr.responseText);
        }
    });
}

function printNotices(notices) {
    var noticesHtml = "<img src='IMG/room2.jpg'><div class='notice_container'>"; // 이미지 태그 안에 notice_container div 추가
    
    // 제목과 등록 날짜 표시
    noticesHtml += "<div class='notice_item'>";
    noticesHtml += "<div class='notice_title notice_title_custom' style='text-decoration: none;'>제목</div>"; // 제목 표시
    noticesHtml += "<div class='notice_date notice_date_custom' style='text-decoration: none;'>등록 날짜</div>"; // 등록 날짜 표시
    noticesHtml += "</div>";
    noticesHtml += "<hr>";

    // 각 공지사항 항목을 출력
    $.each(notices, function(index, notice) {
        noticesHtml += "<div class='notice_item'>";
        noticesHtml += "<a href='main_notice_content?no=" + notice.no + "'>"+ "<div class='notice_title' style='text-decoration: none;'>" + notice.title + "</div>" + "</a>";
        noticesHtml += "<div class='notice_date' style='text-decoration: none;'>" + notice.date.substring(0, 10) + "</div>";
        noticesHtml += "</div>";
        noticesHtml += "<hr>";
    });
    
    noticesHtml += "</div>"; // notice_container div 닫기
    $(".section5 .notice_content").empty().append(noticesHtml);

    $('.section5 .notice_content a').hover(function() {
    $(this).find('.notice_title, .notice_date').css("text-decoration", "underline");
}, function() {
    $(this).find('.notice_title, .notice_date').css('text-decoration', 'none');
});
    
}





// 문서가 준비되면 함수를 호출하여 공지사항을 가져옵니다
$(document).ready(function() {
    fetchEventList();
});


/*이벤트*/
function fetchEventList() {
    $.ajax({
        type: "GET",
        url: "print_event",
        dataType: "json",
        success: function(response) {
            if (response.length === 0) {
                console.log("이벤트가 없습니다.");
            } else {
                printEvents(response);
            }
            setTimeout(fetchNoticeList, 500);
        },
        error: function(xhr, status, error) {
            console.error("에러:", error);
            console.error("상태:", status);
            console.error("응답:", xhr.responseText);
        }
    });
}

function printEvents(events) {
    var eventsHtml = "";
    
    $.each(events, function(index, event) {
    var backgroundColor;
        switch(index) {
            case 0: backgroundColor = "#ffffff8a"; break;
            case 1: backgroundColor = "#ffffff8a"; break;
            case 2: backgroundColor = "#ffffff8a"; break;
            case 3: backgroundColor = "#ffffff8a"; break;
            default: backgroundColor = "#ffffff8a"; // Default background color
        }
        eventsHtml += "<div class='event_item' style='background-color: " + backgroundColor + ";'>";
        eventsHtml += "<img src='upload_images/" + event.file + "'>";
        eventsHtml += "<a href='main_event_content?no=" + event.no + "'><div class='main_event_title'>" + event.title + "</div></a>";
        eventsHtml += "<div class='main_event_date'>" + event.date.substring(0, 10) + "</div>";
        eventsHtml += "</div>";
    });
    $(".section4 .event_img_bg").empty().append(eventsHtml);

// 마우스 호버 효과가 올바른 요소에 적용되도록 확인합니다
    $('.section4 .event_content div').hover(function() {
        $(this).css("text-decoration", "underline");
    }, function() {
        $(this).css('text-decoration', 'none');
		
    });
   
}




