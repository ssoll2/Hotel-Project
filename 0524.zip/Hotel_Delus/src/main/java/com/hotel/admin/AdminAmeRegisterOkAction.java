package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.AmenitieDTO;
import com.hotel.model.HotelTotalDAO;

public class AdminAmeRegisterOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String ame_name = request.getParameter("ame_name").trim();
		String ame_check_str = request.getParameter("ame_check").trim();
		boolean ame_check = Boolean.parseBoolean(ame_check_str);
		String ame_open = request.getParameter("ame_open").trim();
		String ame_close = request.getParameter("ame_close").trim();
		int ame_price = Integer.parseInt(request.getParameter("ame_price").trim());
		String ame_option = request.getParameter("ame_option").trim();
		String ame_textarea = request.getParameter("ame_cont").trim();
		String ame_file = request.getParameter("ame_file").trim();
		
		
		AmenitieDTO dto = new AmenitieDTO();
		
		dto.setAme_title(ame_name);
		dto.setAme_status(ame_check);
		dto.setAme_open(ame_open);
		dto.setAme_close(ame_close);
		dto.setAme_price(ame_price);
		dto.setAme_type(ame_option);
		dto.setAme_cont(ame_textarea);
		dto.setAme_file(ame_file);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.insertAme(dto);
		
		PrintWriter out = response.getWriter();
		
		ActionForward forward = new ActionForward();
		
		if(check > 0) {
			forward.setPath("admin_ame_list"); // 성공 시에만 이동할 경로 설정
	        forward.setRedirect(true);
		}else {
			out.println("<script>");
			out.println("alert('작성실패')");
			out.println("history.back()");
			out.println("</script>");
			forward.setRedirect(false);
		}
		
	   
	    
	    // 생성한 ActionForward 객체 반환
	    return forward;
		
		
		
		
	}

}
