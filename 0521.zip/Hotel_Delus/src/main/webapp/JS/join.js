
$(function (){
	$(".account #id_check").click(function() {
		$(".account #id_Error").hide();
		
		let userId = $(".account #id").val();
		
		// 아이디 입력길이 체크
		if($.trim($(".account #id").val()).length < 4) {
			
			let warningTxt = '<font style="color : red;">아이디는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".account #id_Error").text("");
			$(".account #id_Error").show();
			$(".account #id_Error").append(warningTxt);
			return false;
			
		}
		// 아이디 입력길이 체크
		if($.trim($(".account #id").val()).length > 16) {
			let warningTxt = '<font style="color : red;">아이디는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".account #id_Error").text("");
			$(".account #id_Error").show();
			$(".account #id_Error").append(warningTxt);
			return false;
		
		}
		
		   $.ajax({
                type: "POST",
                url: "id_check", // 이 URL이 올바른지 확인하세요.
                data: { paramId: userId },
                dataType: "json",
                success: function(data) {
                    console.log("AJAX 성공:", data); // 디버깅 로그
                    if (data == -1) {
                        let warningTxt = '<font style="color: red">중복된 아이디입니다.</font>';
                        $("#id_Error").html(warningTxt).show();
                    } else {
                        let warningTxt = '<font style="color: green;">사용가능한 아이디입니다.</font>';
                        $("#id_Error").html(warningTxt).show();
                    }
                },
                error: function(xhr, status, error) {
                    console.log("AJAX 에러:", xhr, status, error); // 디버깅 로그
                    alert("데이터 통신 오류입니다.");
                }
		})
	})
	
});

/*비밀번호 유효성 검사 */
$(function() {
	$(".password #password").keyup(function() {
		$(".password #password_Error").hide();
		
		let userPwd = $(".password #password").val();
		
		if($.trim($(".password #password").val()).length < 4) {
			
			let warningTxt = '<font style="color : red;">비밀번호는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".password #password_Error").text("");
			$(".password #password_Error").show();
			$(".password #password_Error").append(warningTxt);
		
			return false;
		}
		if($.trim($(".password #password").val()).length > 16) {
			
			let warningTxt = '<font style="color : red;">비밀번호는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".password #password_Error").text("");
			$(".password #password_Error").show();
			$(".password #password_Error").append(warningTxt);
		
			return false;
		}
	
	
	})


})

/*비밀번호 더블 체크*/
$(function() {

	$(".password #passwordcheck").keyup(function () {
		$(".password #pwdcheck_Error").hide();
		
		let userPwd = $(".password #password").val();
		let checkPwd = $(".password #passwordcheck").val();
		
		if($.trim(userPwd) !== $.trim(checkPwd)) {
			
			let warningTxt = '<font style="color : red;">비밀번호가 일치하지 않습니다.</font>';
			
			$(".password #pwdcheck_Error").text("");
			$(".password #pwdcheck_Error").show();
			$(".password #pwdcheck_Error").append(warningTxt);
			
			return false;
		}
		if($.trim(userPwd) == $.trim(checkPwd)) {
			
			let warningTxt = '<font style="color : green;">비밀번호 일치</font>';
			
			$(".password #pwdcheck_Error").text("");
			$(".password #pwdcheck_Error").show();
			$(".password #pwdcheck_Error").append(warningTxt);
			
			return true;
		}
	})

})

/*전화번호 focus효과*/
function changePhone1(){
    let phone1 = document.getElementById("phone1").value
    if(phone1.length === 3){
        document.getElementById("phone2").focus();
    }  
}
function changePhone2(){
    let phone2 = document.getElementById("phone2").value
    if(phone2.length === 4){
        document.getElementById("phone3").focus();
    }
}
function changePhone3(){
    let phone3 = document.getElementById("phone3").value
    if(phone3.length === 4){
        document.getElementById("sendMessage").focus();
        document.getElementById("sendMessage").setAttribute("style","background-color:red;, color:white;")
        document.getElementById("sendMessage").disabled = false;
    }
}

/**/
// 다음 버튼
var nextButton = document.getElementById('next_box');

// 각 입력 필드를 검증하는 함수
function check() {
    var id = document.getElementById('id').value;
    var password = document.getElementById('password').value;
    var passwordcheck = document.getElementById('passwordcheck').value;
    var name = document.getElementById('box').value;
    var phone1 = document.getElementById('phone1').value;
    var phone2 = document.getElementById('phone2').value;
    var phone3 = document.getElementById('phone3').value;

    // 모든 필드가 비어있지 않으면 다음 버튼을 활성화시킵니다.
    if (id !== '' && password !== '' && passwordcheck !== '' && name !== '' && phone1 !== '' && phone2 !== '' && phone3 !== '') {
        nextButton.disabled = false;
    } else {
        nextButton.disabled = true;
    }
}

// 각 입력 필드의 변경 이벤트에 대한 리스너를 추가합니다.
document.getElementById('id').addEventListener('input', check);
document.getElementById('password').addEventListener('input', check);
document.getElementById('passwordcheck').addEventListener('input', check);
document.getElementById('box').addEventListener('input', check);
document.getElementById('phone1').addEventListener('input', check);
document.getElementById('phone2').addEventListener('input', check);
document.getElementById('phone3').addEventListener('input', check);

// 페이지 로딩 시에도 체크합니다.
check();



/**/
// JavaScript 파일인 join.js
// 필수 입력란이 모두 채워졌는지 확인하는 함수
function check() {
    var id = document.getElementById("id").value.trim();
    var password = document.getElementById("password").value.trim();
    var passwordCheck = document.getElementById("passwordcheck").value.trim();
    var name = document.getElementById("box").value.trim();
    var phone1 = document.getElementById("phone1").value.trim();
    var phone2 = document.getElementById("phone2").value.trim();
    var phone3 = document.getElementById("phone3").value.trim();
    var email = document.getElementById("join_email").value.trim();

  

    // 필수 입력란이 비어있는지 확인
    if (id === "" || password === "" || passwordCheck === "" || name === "" || phone1 === "" || phone2 === "" || phone3 === "") {
        // alert("모든 필수 입력란을 작성해주세요."); // 필요 없는 알림
        document.getElementById("next_box").disabled = true; // 다음 버튼 비활성화
        return false; // 폼 제출 방지
    }

    // 이메일 입력란이 비어있는지 확인
    if (email === "") {
        alert("이메일을 입력해주세요.");
        document.getElementById("next_box").disabled = true; // 다음 버튼 비활성화
        return false; // 폼 제출 방지
    }

    // 모든 필수 입력란이 채워져 있으면 다음 버튼 활성화
    document.getElementById("next_box").disabled = false;
    return true; // 폼 제출 허용
}
