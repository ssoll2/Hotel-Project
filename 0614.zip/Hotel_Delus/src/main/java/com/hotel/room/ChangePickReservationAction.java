package com.hotel.room;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;


public class ChangePickReservationAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      /*
       * BufferedReader reader = new BufferedReader(new
       * InputStreamReader(request.getInputStream())); StringBuilder jsonStr = new
       * StringBuilder(); String line; while ((line = reader.readLine()) != null) {
       * jsonStr.append(line); } reader.close();
       * 
       * JSONParser parser = new JSONParser();
       * 
       * JSONObject jsonData = null; try { jsonData = (JSONObject)
       * parser.parse(jsonStr.toString()); } catch (ParseException e) {
       * e.printStackTrace(); }
       */
      // AdultCount: adultCount, ChildrenCount: childrenCount, StartDate: start_date,
      // EndDate: end_date, Total: total

      int adult = Integer.parseInt(request.getParameter("adult"));
      int child = Integer.parseInt(request.getParameter("children"));
      int total = Integer.parseInt(request.getParameter("total"));
      
      total = adult + child;
      
      String check_in_date = request.getParameter("check_in_date");
      String check_out_date = request.getParameter("check_out_date");
      
      
      HotelTotalDAO dao = HotelTotalDAO.getInstance();

      
       
      List<RoomInfoDTO> list = dao.getRoomInfo_res_change_List(check_in_date, check_out_date, total);
       
          
      request.setAttribute("List", list);
      request.setAttribute("adult", adult); 
      request.setAttribute("children", child);
      request.setAttribute("start_date", check_in_date);
      request.setAttribute("end_date", check_out_date);
      request.setAttribute("total", total);

       System.out.println(check_in_date);
       System.out.println(check_out_date);
       ActionForward forward = new ActionForward();
       
       forward.setPath("/WEB-INF/views/public/room/reservation_list.jsp");
       
       return forward;

   }

}
