package com.hotel.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;

public class AdminMainAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      
      HotelTotalDAO dao = HotelTotalDAO.getInstance();
      
      List<HotelUserDTO> list = dao.getHotelUserList();
      
      request.setAttribute("List", list);
      
      ActionForward forward = new ActionForward();

      forward.setPath("/WEB-INF/views/admin/admin_main.jsp");

      return forward;
      
      
   }

}
