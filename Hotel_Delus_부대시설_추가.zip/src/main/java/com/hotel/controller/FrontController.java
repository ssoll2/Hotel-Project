package com.hotel.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;


public class FrontController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	// 서비스 메소드: GET 또는 POST 요청을 처리하는 메인 메소드
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// 요청과 응답의 인코딩 설정
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		// 요청 URI를 가져옴
		String uri = request.getRequestURI();
		// System.out.println("uri = " + uri);
		
		// 컨텍스트 패스를 가져옴
		String path = request.getContextPath();
		// System.out.println("path = " + path);
		
		// 실제 명령을 추출 (컨텍스트 패스 이후의 URI)
		String command = uri.substring(path.length() + 1);
		System.out.println("command = " + command);

		Action action = null;
		ActionForward forward = null;
		Properties prop = new Properties();
		
		// mapping.properties 파일을 읽음
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\User\\Desktop\\jsp_work\\Hotel_Delus\\src\\main\\java\\com\\hotel\\controller\\mapping.properties");
		
		// properties 파일을 로드
		prop.load(fis);
		
		// 명령어에 해당하는 value를 가져옴
		String value = prop.getProperty(command);
		System.out.println("value = " + value);
		
		// value가 "execute"로 시작하면 특정 액션 클래스를 실행
		if (value.substring(0, 7).equals("execute")) {
			
			// value를 '|'로 분리
			StringTokenizer st = new StringTokenizer(value, "|");

			// 첫 번째 토큰은 무시
			String url_1 = st.nextToken();
			// 두 번째 토큰은 클래스 이름
			String url_2 = st.nextToken();

			try {
				
				// 클래스 이름으로 Class 객체를 얻음
				Class<?> url = Class.forName(url_2);

				// 기본 생성자를 얻음
				Constructor<?> constructor = url.getConstructor();

				// 액션 객체를 생성
				action = (Action) constructor.newInstance();

				// 액션을 실행하여 forward 객체를 얻음
				forward = action.execute(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			// value가 "execute"가 아니면 단순한 포워딩 처리
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath(value);

		}
		
		// forward 객체가 null이 아니면 요청을 처리
		if (forward != null) {

			if (forward.isRedirect()) {
				// 리다이렉트 처리
				response.sendRedirect(forward.getPath());
			} else {
				// 포워드 처리 
				RequestDispatcher rd = request.getRequestDispatcher(forward.getPath());
				rd.forward(request, response);
			}

		}
		
		
	}
}
