package com.hotel.review;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.PackageDTO;
import com.hotel.model.RoomReviewDTO;

public class ReviewRoomListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String room_type = request.getParameter("type").trim();

		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		List<RoomReviewDTO> list = dao.getRoomReviewList(room_type);

		request.setAttribute("list", list);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/review/room_review_list.jsp");

		return forward;
	}

}
