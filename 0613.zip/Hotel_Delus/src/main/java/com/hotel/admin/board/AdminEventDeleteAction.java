package com.hotel.admin.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;

public class AdminEventDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String board_no = request.getParameter("no").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.deleteAdminEvent(board_no);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('이벤트 삭제 성공')");
			out.println("location.href='admin_event_list'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('이벤트 삭제 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		
		return null;
	}

}
