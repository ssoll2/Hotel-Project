package com.hotel.model;

public class EventDTO {
	
	private String event_board_no;
	private String event_board_title;
	private String event_board_cont;
	private String event_board_start_date;
	private String event_board_end_date;
	private String event_board_date;
	private String event_board_update;
	private int event_board_hit;
	
	public String getEvent_board_no() {
		return event_board_no;
	}
	public void setEvent_board_no(String event_board_no) {
		this.event_board_no = event_board_no;
	}
	public String getEvent_board_title() {
		return event_board_title;
	}
	public void setEvent_board_title(String event_board_title) {
		this.event_board_title = event_board_title;
	}
	public String getEvent_board_cont() {
		return event_board_cont;
	}
	public void setEvent_board_cont(String event_board_cont) {
		this.event_board_cont = event_board_cont;
	}
	public String getEvent_board_start_date() {
		return event_board_start_date;
	}
	public void setEvent_board_start_date(String event_board_start_date) {
		this.event_board_start_date = event_board_start_date;
	}
	public String getEvent_board_end_date() {
		return event_board_end_date;
	}
	public void setEvent_board_end_date(String event_board_end_date) {
		this.event_board_end_date = event_board_end_date;
	}
	public String getEvent_board_date() {
		return event_board_date;
	}
	public void setEvent_board_date(String event_board_date) {
		this.event_board_date = event_board_date;
	}
	public String getEvent_board_update() {
		return event_board_update;
	}
	public void setEvent_board_update(String event_board_update) {
		this.event_board_update = event_board_update;
	}
	public int getEvent_board_hit() {
		return event_board_hit;
	}
	public void setEvent_board_hit(int event_board_hit) {
		this.event_board_hit = event_board_hit;
	}
	public String getEvent_board_file() {
		return event_board_file;
	}
	public void setEvent_board_file(String event_board_file) {
		this.event_board_file = event_board_file;
	}
	private String event_board_file;
	
	
	

}
