package com.hotel.admin.qna;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.QnaBoardDTO;

public class AdminQnaContAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int qna_no = Integer.parseInt(request.getParameter("no").trim());
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		QnaBoardDTO cont = dao.userQnaCont(qna_no);
		
		request.setAttribute("cont", cont);

		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/admin/qna/admin_qna_cont.jsp");
			
		return forward;
	}

}
