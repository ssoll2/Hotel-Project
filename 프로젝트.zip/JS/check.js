
// HTML 파일에서 버튼을 누르면 호출되는 함수
function calculateStay() {
    var checkinDate = document.getElementById('checkin').value;
    var checkoutDate = document.getElementById('checkout').value;

    // 선택된 날짜의 input 요소를 찾아서 클래스를 추가합니다.
    highlightSelectedDate(checkinDate, 'checkin');
    highlightSelectedDate(checkoutDate, 'checkout');

    // 기존의 잔류 기간 계산 함수를 호출합니다.
    calculateStay();
}

// 선택된 날짜를 감지하고 해당 날짜에 클래스를 추가하는 함수
function highlightSelectedDate(date, elementId) {
    // 선택된 날짜의 input 요소를 찾습니다.
    var inputElement = document.getElementById(elementId);

    // 입력된 날짜가 없으면 함수를 종료합니다.
    if (!date) return;

    // 입력된 날짜가 있다면 해당 input 요소에 클래스를 추가합니다.
    inputElement.classList.add('selected-date');
}
