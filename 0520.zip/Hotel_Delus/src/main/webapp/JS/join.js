
$(function (){
	$(".account #id_check").click(function() {
		$(".account #id_Error").hide();
		
		let userId = $(".account #id").val();
		
		// 아이디 입력길이 체크
		if($.trim($(".account #id").val()).length < 4) {
			
			let warningTxt = '<font style="color : red;">아이디는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".account #id_Error").text("");
			$(".account #id_Error").show();
			$(".account #id_Error").append(warningTxt);
			return false;
			
		}
		// 아이디 입력길이 체크
		if($.trim($(".account #id").val()).length > 16) {
			let warningTxt = '<font style="color : red;">아이디는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".account #id_Error").text("");
			$(".account #id_Error").show();
			$(".account #id_Error").append(warningTxt);
			return false;
		
		}
		
		   $.ajax({
                type: "POST",
                url: "id_check", // 이 URL이 올바른지 확인하세요.
                data: { paramId: userId },
                dataType: "json",
                success: function(data) {
                    console.log("AJAX 성공:", data); // 디버깅 로그
                    if (data == -1) {
                        let warningTxt = '<font style="color: red">중복된 아이디입니다.</font>';
                        $("#id_Error").html(warningTxt).show();
                    } else {
                        let warningTxt = '<font style="color: green;">사용가능한 아이디입니다.</font>';
                        $("#id_Error").html(warningTxt).show();
                    }
                },
                error: function(xhr, status, error) {
                    console.log("AJAX 에러:", xhr, status, error); // 디버깅 로그
                    alert("데이터 통신 오류입니다.");
                }
		})
	})
	
});

/*비밀번호 유효성 검사 */
$(function() {
	$(".password #password").keyup(function() {
		$(".password #password_Error").hide();
		
		let userPwd = $(".password #password").val();
		
		if($.trim($(".password #password").val()).length < 4) {
			
			let warningTxt = '<font style="color : red;">비밀번호는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".password #password_Error").text("");
			$(".password #password_Error").show();
			$(".password #password_Error").append(warningTxt);
		
			return false;
		}
		if($.trim($(".password #password").val()).length > 16) {
			
			let warningTxt = '<font style="color : red;">비밀번호는 4자리 이상 16자리 미만이어야 합니다.</font>';
			
			$(".password #password_Error").text("");
			$(".password #password_Error").show();
			$(".password #password_Error").append(warningTxt);
		
			return false;
		}
	
	
	})


})

/*비밀번호 더블 체크*/
$(function() {

	$(".password #passwordcheck").keyup(function () {
		$(".password #pwdcheck_Error").hide();
		
		let userPwd = $(".password #password").val();
		let checkPwd = $(".password #passwordcheck").val();
		
		if($.trim(userPwd) !== $.trim(checkPwd)) {
			
			let warningTxt = '<font style="color : red;">비밀번호가 일치하지 않습니다.</font>';
			
			$(".password #pwdcheck_Error").text("");
			$(".password #pwdcheck_Error").show();
			$(".password #pwdcheck_Error").append(warningTxt);
			
			return false;
		}
		if($.trim(userPwd) == $.trim(checkPwd)) {
			
			let warningTxt = '<font style="color : green;">비밀번호 일치</font>';
			
			$(".password #pwdcheck_Error").text("");
			$(".password #pwdcheck_Error").show();
			$(".password #pwdcheck_Error").append(warningTxt);
			
			return true;
		}
	})

})

