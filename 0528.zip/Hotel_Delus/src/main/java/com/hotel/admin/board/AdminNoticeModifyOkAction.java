package com.hotel.admin.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.NoticeDTO;

public class AdminNoticeModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String notice_board_no = request.getParameter("notice_board_no").trim();
		String notice_board_title = request.getParameter("notice_board_title").trim();
		String notice_board_cont = request.getParameter("notice_board_cont").trim();
		String notice_board_file = request.getParameter("notice_board_file").trim();
		
		
		NoticeDTO dto = new NoticeDTO();
		
		dto.setNotice_board_no(notice_board_no);
		dto.setNotice_board_title(notice_board_title);
		dto.setNotice_board_cont(notice_board_cont);
		dto.setNotice_board_file(notice_board_file);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.updateAdminNotice(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('공지사항 수정 성공')");
			out.println("location.href='admin_notice_list'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('공지사항 수정 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		
		
		return null;
	}

}
