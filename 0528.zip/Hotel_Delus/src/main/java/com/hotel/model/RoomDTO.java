package com.hotel.model;

public class RoomDTO {
	private String room_pk_no;
	private String room_number;
	private String room_type;
	private boolean room_reservate_status;
	
	public String getRoom_pk_no() {
		return room_pk_no;
	}
	public void setRoom_pk_no(String room_pk_no) {
		this.room_pk_no = room_pk_no;
	}
	public String getRoom_number() {
		return room_number;
	}
	public void setRoom_number(String room_number) {
		this.room_number = room_number;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public boolean isRoom_reservate_status() {
		return room_reservate_status;
	}
	public void setRoom_reservate_status(boolean room_reservate_status) {
		this.room_reservate_status = room_reservate_status;
	}
}
