   document.addEventListener("DOMContentLoaded", function() {
    const checkinBtn = document.getElementById('checkin_btn');
    const checkoutBtn = document.getElementById('checkout_btn');
    const checkinCalendar = document.getElementById('checkin_calendar');
    const checkinDateDisplay = document.getElementById('checkin_date');
    const hiddenCheckinDate = document.getElementById('hidden_checkin_date');
    const checkoutDateDisplay = document.getElementById('checkout_date');
    const hiddenCheckoutDate = document.getElementById('hidden_checkout_date');
    const checkinLabelText = document.createElement('span');

    const dateOptions = {
    dateFormat: "Y년 m월 d일", // 요일 없이 날짜만 표시
    mode: "range",
    minDate: "today", // 현재 날짜 이전의 날짜는 선택할 수 없음
    onChange: function(selectedDates, dateStr, instance) {
        const [checkinDate, checkoutDate] = selectedDates;
        if (checkinDate && checkoutDate) {
            checkinDateDisplay.innerHTML = ''; // 날짜 표시 초기화
            checkinDateDisplay.appendChild(checkinLabelText); // "체크인" 텍스트 추가
            // '-'로 날짜 구분하여 표시
            checkinDateDisplay.insertAdjacentHTML('beforeend', ' ' + dateStr.replace(' to ', ' - ')); // 선택한 날짜 추가
            hiddenCheckinDate.value = dateStr.split(" to ")[0]; // hidden input에 체크인 날짜 저장
            hiddenCheckoutDate.value = dateStr.split(" to ")[1]; // hidden input에 체크아웃 날짜 저장
            // checkinCalendar.style.display = 'none'; // 달력 숨기기 (이 부분을 주석 처리합니다.)
            checkinBtn.style.display = 'inline-block'; // 체크인 버튼 표시
            checkoutBtn.style.display = 'inline-block'; // 체크아웃 버튼 표시
        }
    }
};
    

    flatpickr(checkinCalendar, dateOptions);

    // 체크인-체크아웃 버튼을 클릭하면 달력이 나타나도록 합니다.
	document.getElementById('checkin_btn').addEventListener('click', function(event) {
	    event.preventDefault(); // 기본 동작을 막습니다.
	    document.getElementById('checkin_calendar').style.display = 'block'; // 달력을 표시합니다.
	});
});
   

    // 투숙객 버튼을 클릭하면 투숙객 선택 모달을 표시합니다.
    const guestBtn = document.querySelector('.guest_btn');
    guestBtn.addEventListener('click', function() {
        $('#guestModal').modal('show');
    });

    // 투숙객 선택 모달에서 저장 버튼을 클릭하면 선택된 인원을 표시합니다.
    const guestModalSaveBtn = document.getElementById('guestModalSave');
    guestModalSaveBtn.addEventListener('click', function() {
        const adultCount = document.getElementById('adultCount').value;
        const childCount = document.getElementById('childCount').value;
        const resPeo = document.querySelector('.res_peo');
        resPeo.innerHTML = `<span>${adultCount} 명</span>, <span>${childCount} 명</span>`;
        $('#guestModal').modal('hide');
    });

