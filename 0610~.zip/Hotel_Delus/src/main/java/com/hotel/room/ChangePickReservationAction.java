package com.hotel.room;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;

public class ChangePickReservationAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
		StringBuilder jsonStr = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			jsonStr.append(line);
		}
		reader.close();

		JSONParser parser = new JSONParser();

		JSONObject jsonData = null;
		try {
			jsonData = (JSONObject) parser.parse(jsonStr.toString());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		// AdultCount: adultCount, ChildrenCount: childrenCount, StartDate: start_date,
		// EndDate: end_date, Total: total

		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		String adult = (String) jsonData.get("AdultCount");
		String child = (String) jsonData.get("ChildrenCount");
		String startDate = (String) jsonData.get("StartDate");
		String endDate = (String) jsonData.get("EndDate");
		String total_int = (String) jsonData.get("Total");


		int total = Integer.parseInt(total_int);


		List<RoomInfoDTO> list = dao.getRoomInfo_res_change_List(startDate, endDate, total);

		/*
		 * for(RoomInfoDTO temp : list) { System.out.println(temp.getRoom_maximum()); }
		 */		
		request.setAttribute("List", list);
		request.setAttribute("adult", adult); 
		request.setAttribute("children", child);
		request.setAttribute("start_date", startDate);
		request.setAttribute("end_date", endDate);
		request.setAttribute("total", total_int);

		
		 ActionForward forward = new ActionForward();
		 
		 forward.setPath("/WEB-INF/views/public/room/change_pick_reservation_list.jsp");
		 
		 return forward;
	
		 
	}

}
