package com.hotel.room;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;

public class MainPickReservationAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String adult = request.getParameter("adult").trim();
		String children = request.getParameter("children").trim();
		String start_date = request.getParameter("start_date").trim();
		String end_date = request.getParameter("end_date").trim();

		int total = 0;
		int adult_int = Integer.parseInt(adult.substring(0, 1));
		int children_int = Integer.parseInt(children.substring(0, 1));

		total = adult_int + children_int;

		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		List<RoomInfoDTO> list = dao.getRoomInfo_res_List(start_date, end_date, total);
		
		/*
		 * if(request.getAttribute("list") != null) { list = (List<RoomInfoDTO>)
		 * request.getAttribute("list"); } else { list =
		 * dao.getRoomInfo_res_List(start_date, end_date, total); }
		 */

		request.setAttribute("List", list);
		request.setAttribute("adult", adult_int);
		request.setAttribute("children", children_int);
		request.setAttribute("start_date", start_date);
		request.setAttribute("end_date", end_date);
		request.setAttribute("total", total);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/room/reservation_list.jsp");

		return forward;
	}

}
