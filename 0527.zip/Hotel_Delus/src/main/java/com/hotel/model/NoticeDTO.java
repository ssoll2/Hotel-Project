package com.hotel.model;

public class NoticeDTO {

}
