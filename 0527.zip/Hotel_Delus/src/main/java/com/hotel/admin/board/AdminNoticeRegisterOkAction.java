package com.hotel.admin.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.NoticeDTO;

public class AdminNoticeRegisterOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		String notice_board_title = request.getParameter("notice_board_title").trim();
		String notice_board_cont = request.getParameter("notice_board_cont").trim();
		String notice_board_file = request.getParameter("notice_board_file").trim();
		
		
		NoticeDTO dto = new NoticeDTO();
		
		dto.setNotice_board_title(notice_board_title);
		dto.setNotice_board_cont(notice_board_cont);
		dto.setNotice_board_file(notice_board_file);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.insertAdminNotice(dto);
		
		if (check > 0) {
			
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('공지사항에 등록되었습니다.')");
			out.println("location.href='admin_notice_list'");
			out.println("</script>");
			out.close();
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('공지사항 글 등록에 실패했습니다. 입력한 정보를 다시한번 확인하세요.')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}
		
				
		
		
		
		
		return null;
	}

}
