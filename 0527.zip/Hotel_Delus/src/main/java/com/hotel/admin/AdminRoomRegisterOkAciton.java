package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;

public class AdminRoomRegisterOkAciton implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		/*
		 * String room_pk_no = request.getParameter("room_pk_no").trim(); String
		 * room_type = request.getParameter("room_type").trim(); int room_total =
		 * Integer.parseInt(request.getParameter("room_total").trim()); String room_size
		 * = request.getParameter("room_size").trim(); int room_maximum =
		 * Integer.parseInt(request.getParameter("room_maximum").trim()); int room_price
		 * = Integer.parseInt(request.getParameter("room_price").trim()); String
		 * room_cont = request.getParameter("room_cont").trim(); String room_file =
		 * request.getParameter("room_file").trim(); String room_fac =
		 * request.getParameter("room_fac").trim();
		 * 
		 * RoomInfoDTO dto = new RoomInfoDTO();
		 * 
		 * 
		 * dto.setRoom_type(room_type); dto.setRoom_total(room_total);
		 * dto.setRoom_size(room_size); dto.setRoom_maximum(room_maximum);
		 * dto.setRoom_price(room_price); dto.setRoom_cont(room_cont);
		 * dto.setRoom_file(room_file); dto.setRoom_facilities(room_fac);
		 * 
		 * HotelTotalDAO dao = HotelTotalDAO.getInstance();
		 * 
		 * int check = dao.insertHotelRoom(dto);
		 * 
		 * 
		 * if(check > 0) { ActionForward forward = new ActionForward();
		 * 
		 * forward.setPath("/WEB-INF/views/admin/admin_room_list.jsp");
		 * 
		 * return forward; } else { PrintWriter out = response.getWriter();
		 * out.println("<script>");
		 * out.println("alert('룸 등록에 실패했습니다. 입력한 정보를 다시한번 확인하세요.')");
		 * out.println("history.back()"); out.println("</script>"); out.close(); }
		 */
		
		
		
		
		return null;
	}

}
