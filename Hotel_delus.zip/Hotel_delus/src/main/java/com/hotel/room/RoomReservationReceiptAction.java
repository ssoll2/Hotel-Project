package com.hotel.room;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.CountRoomDTO;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;

public class RoomReservationReceiptAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      
      String type = request.getParameter("type").trim();
      int price = Integer.parseInt(request.getParameter("price").trim());
      
      double total_amount = 0;
      
      double surtax = 0;
      
      double service_price = 0;
      
      double gong = (price / 1.1);

      double total_price = 0;  // 투숙요금 + 봉사료
      
      double finally_price = 0;
      
      service_price = (price * 0.1);
      
      total_price = price + service_price;
       
      
      int adult = Integer.parseInt(request.getParameter("adult").trim());
      int children = Integer.parseInt(request.getParameter("children").trim());
      int total = Integer.parseInt(request.getParameter("total").trim());
      
      
      
      
      String startdate = request.getParameter("check_in").trim();
      String enddate = request.getParameter("check_out").trim();
      String strFormat = "yyyy-MM-dd";
      SimpleDateFormat sdf = new SimpleDateFormat(strFormat);
      
      try {
         Date startDate  = sdf.parse(startdate);
         Date endDate  = sdf.parse(enddate);
         
         long diffDay = (endDate.getTime() - startDate.getTime()) / (24*60*60*1000);
         
         request.setAttribute("diffDay", diffDay);
         
         int amount = price * (int)diffDay;
         
         
         request.setAttribute("amount", amount);
         
         surtax = (diffDay * total_price) * 0.1;
         
         total_amount = (diffDay * total_price) + surtax;

         finally_price = (diffDay * total_price);

      } catch (Exception e) {
         e.printStackTrace();
      }
      
       HotelTotalDAO dao = HotelTotalDAO.getInstance();

          
         int total_amount_end = (int)total_amount;
         
         int finally_price_end = (int)finally_price;
      
         int surtax_end = (int)surtax;
         
			/*
			 * int DRScount = dao.DRScount(startdate, enddate); int DRDcount =
			 * dao.DRDcount(startdate, enddate); int SDRcount = dao.SDRcount(startdate,
			 * enddate); int PDRcount = dao.PDRcount(startdate, enddate); int PPRcount =
			 * dao.PPRcount(startdate, enddate); int SPRcount = dao.SPRcount(startdate,
			 * enddate); int PSRcount = dao.PSRcount(startdate, enddate);
			 * 
			 * 
			 * 
			 * 
			 * List<RoomInfoDTO> list = dao.getRoomInfo_res_change_List(startdate, enddate,
			 * total, DRScount, DRDcount, SDRcount, PDRcount, PPRcount, SPRcount, PSRcount);
			 */
         List<CountRoomDTO> cnt_list = dao.RoomTotalCount(startdate, enddate);
         
         List<RoomInfoDTO> list = dao.getRoomInfo_res_List(startdate, enddate, total);
             
       request.setAttribute("List", list);
      request.setAttribute("type", type);
      request.setAttribute("price", price);
      request.setAttribute("start_date", startdate);
      request.setAttribute("end_date", enddate);
      request.setAttribute("adult", adult);
      request.setAttribute("children", children);
      request.setAttribute("total", total);
      request.setAttribute("total_amount", total_amount_end);
      request.setAttribute("surtax", surtax_end);
      request.setAttribute("finally_price", finally_price_end);
      request.setAttribute("cnt_list", cnt_list);
      
      ActionForward forward = new ActionForward();
          
      forward.setPath("/WEB-INF/views/public/room/reservation_list.jsp");
          
       return forward;
   }

}
