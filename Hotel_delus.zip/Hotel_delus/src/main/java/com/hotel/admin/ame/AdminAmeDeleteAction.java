package com.hotel.admin.ame;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;

public class AdminAmeDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);

		String ame_type = request.getParameter("ame_type").trim();
		int nowPage = Integer.parseInt(request.getParameter("page").trim());
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.deleteAdminAme(ame_type);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('삭제 성공')");
			out.println("location.href='admin_ame_list?page=" + nowPage + "';");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('삭제 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
