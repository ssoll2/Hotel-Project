package com.hotel.admin.qna;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.QnaBoardDTO;

public class AdminQnaReplyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		String qna_reply = request.getParameter("qna_reply").trim();
		int qna_no = Integer.parseInt(request.getParameter("no").trim());
		
		QnaBoardDTO dto = new QnaBoardDTO();
		
		dto.setQna_board_no(qna_no);
		dto.setQna_board_reply(qna_reply);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.replyQna(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('답변완료')");
			out.println("location.href='admin_qna_content?no="+qna_no+"'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		return null;
	}

}
