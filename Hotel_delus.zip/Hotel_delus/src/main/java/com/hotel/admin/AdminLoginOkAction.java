package com.hotel.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.AdminDTO;
import com.hotel.model.HotelTotalDAO;

public class AdminLoginOkAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
	   
	 
      
      String admin_id = request.getParameter("admin_id").trim();
      String admin_password = request.getParameter("admin_password").trim();
      
      AdminDTO dto = new AdminDTO();
      
      dto.setAdmin_id(admin_id);
      dto.setAdmin_password(admin_password);
      
      HotelTotalDAO dao = HotelTotalDAO.getInstance();
      
      int a_login_check = dao.CheckALogin(dto);
      
      PrintWriter out = response.getWriter();
      
      if(a_login_check == 1) {
         
         HttpSession session = request.getSession();
         session.setMaxInactiveInterval(1800); // 세션 유지시간 설정 (초 단위)
         AdminDTO a_cont = dao.getAdminContent(dto);
         
         dao.remainALogin(admin_id); // 로그 남기는 매서드
         
         session.setAttribute("no", a_cont.getAdmin_no() );
         session.setAttribute("name", a_cont.getAdmin_name() );
         session.setAttribute("id", a_cont.getAdmin_id() );
         session.setAttribute("a_cont", a_cont );
         
          out.println("<script>");
            out.println("alert('관리자로 로그인했습니다.')");
            out.println("location.href='main'");
            out.println("</script>");
         
         
      }else if(a_login_check == -1) {
         
          out.println("<script>");
            out.println("alert('비밀번호를 다시 확인해주세요')");
            out.println("location.href='main'");
            out.println("</script>");
         
         
      }else{
         
          out.println("<script>");
            out.println("alert('아이디와 비밀번호를 다시 확인해주세요')");
            out.println("location.href='main'");
            out.println("</script>");
               
      }   
      out.close();
      
      return null;
   }

}