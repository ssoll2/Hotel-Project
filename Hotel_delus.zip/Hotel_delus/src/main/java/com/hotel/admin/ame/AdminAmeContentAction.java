package com.hotel.admin.ame;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.AmenitieDTO;
import com.hotel.model.HotelTotalDAO;

public class AdminAmeContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		String ame_type = request.getParameter("type").trim();
		int page = Integer.parseInt(request.getParameter("page").trim());
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		AmenitieDTO cont = dao.getAdminAmeContent(ame_type);
		
		request.setAttribute("dto", cont);
		request.setAttribute("page", page);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("/WEB-INF/views/admin/ame/admin_ame_content.jsp");
				
		return forward;
		
		
		
	}

}
