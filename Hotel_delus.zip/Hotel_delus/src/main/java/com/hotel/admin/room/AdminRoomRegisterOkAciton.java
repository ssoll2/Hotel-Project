
package com.hotel.admin.room;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomDTO;

public class AdminRoomRegisterOkAciton implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RoomDTO dto = new RoomDTO();

		String room_type = request.getParameter("room_type").trim();
		int room_number = Integer.parseInt(request.getParameter("room_number"));

		SimpleDateFormat sdf = new SimpleDateFormat("MMddhhmmss");
		Calendar c1 = Calendar.getInstance();
		String date = sdf.format(c1.getTime());

		String type = null;

		dto.setRoom_number(room_number);
		dto.setRoom_type(room_type);

		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		int check = dao.RoomRegister(dto);

		PrintWriter out = response.getWriter();

		if (check > 0) {
			out.println("<script>");
			out.println("alert('완료')");
			out.println("location.href='admin_room_info_list'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}

		return null;

	}

}
