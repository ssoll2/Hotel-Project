package com.hotel.admin.room;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomDTO;
import com.hotel.model.RoomInfoDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class AdminRoomInfoRegisterOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		
		RoomInfoDTO dto = new RoomInfoDTO();
		
		String saveFolder = "D:\\jsp_work\\Hotel_Delus\\src\\main\\webapp\\upload_images";
		
		int fileSize = 50 * 1024 * 1024;
		
		MultipartRequest multi = new MultipartRequest(request, saveFolder, fileSize, "UTF-8", new DefaultFileRenamePolicy());
		
		String room_type = multi.getParameter("room_type").trim();
		String room_name = multi.getParameter("room_name").trim();
		int room_total = Integer.parseInt(multi.getParameter("room_total").trim());
		float room_size = Float.parseFloat(multi.getParameter("room_size").trim());
		int room_maximum = Integer.parseInt(multi.getParameter("room_max").trim());
		int room_price = Integer.parseInt(multi.getParameter("room_price").trim());
		String room_cont = multi.getParameter("room_cont").trim();
		String room_facilities = multi.getParameter("room_fac").trim();
		
		File room_file = multi.getFile("room_file");
		
		if(room_file != null) {
			
			String fileName = room_file.getName();
			System.out.println("fileName = " + fileName);
			
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DAY_OF_MONTH);
			String homedir = saveFolder + "/" + year + "-" + month + "-" + day;
			
			File path1 = new File(homedir);
			
			if(!path1.exists()) {
				path1.mkdir();
			}
			String reFileName = room_type + "_" + fileName;
			
			room_file.renameTo(new File(homedir+"/"+reFileName));
			
			String fileDBName = year + "-" + month + "-" + day + "/" + reFileName;
			
			dto.setRoom_file(fileDBName);
		}
		
		dto.setRoom_type(room_type);
		dto.setRoom_name(room_name);
		dto.setRoom_total(room_total);
		dto.setRoom_size(room_size);
		dto.setRoom_maximum(room_maximum);
		dto.setRoom_price(room_price);
		dto.setRoom_cont(room_cont);
		dto.setRoom_facilities(room_facilities);

		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
	    int check = dao.RegisterRoomInfo(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('완료')");
			out.println("location.href='admin_room_info_list'");
			out.println("</script>");	
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
		
		
	}

}
