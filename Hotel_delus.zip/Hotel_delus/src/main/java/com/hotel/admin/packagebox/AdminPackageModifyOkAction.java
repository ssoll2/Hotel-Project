package com.hotel.admin.packagebox;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.PackageDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class AdminPackageModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		PackageDTO dto = new PackageDTO();
		
		String saveFolder = "D:\\jsp_work\\Hotel_Delus\\src\\main\\webapp\\upload_images";
		
		int fileSize = 10 * 1024 * 1024;
		
		MultipartRequest multi = new MultipartRequest(request,
				saveFolder,
				fileSize,
				"UTF-8",
				new DefaultFileRenamePolicy());
		
		  String package_no = multi.getParameter("package_no").trim();
		  String package_title = multi.getParameter("package_title").trim();
	      String package_age = multi.getParameter("package_age").trim();
	      String package_start = multi.getParameter("package_start").trim();
	      String package_end = multi.getParameter("package_end").trim();
	      String package_type = multi.getParameter("package_type").trim();
	      String package_option = multi.getParameter("package_option").trim();
	      String package_details = multi.getParameter("package_details").trim();
	      int package_price = Integer.parseInt(multi.getParameter("package_price"));
	      
	      System.out.println(package_no);
	      System.out.println(package_title);
	      System.out.println(package_age);
	      System.out.println(package_start);
	      System.out.println(package_end);
	      System.out.println(package_type);
	      System.out.println(package_option);
	      System.out.println(package_details);
	      System.out.println(package_price);
	      
	      File package_file = multi.getFile("package_files");
	      
	      
	      if(package_file != null) {  // 첨부파일이 존재하는 경우
				
				// 우선은 첨부파일의 이름을 알아야 함.
				// getName() 메서드를 이용하면 이름을 알 수 있음.
				String fileName = package_file.getName();
				
				//◐ 테스트코드
				System.out.println("첨부파일 이름 >>>" + fileName);
				
				// 날짜 객체를 생성
				Calendar cal = Calendar.getInstance();
				
				int year = cal.get(Calendar.YEAR);
				int month = cal.get(Calendar.MONTH) + 1;
				int day = cal.get(Calendar.DAY_OF_MONTH);
				
				// 날짜로 된 폴더명을 string 으로 받는다
				String homedir = saveFolder +"/"+ year + "_" + month + "_" + day;
				
				// 날짜 폴더를 만들어 본다
				File path1 = new File(homedir);
				
				if(!path1.exists()) { // 폴더가 존자하지 않는경우
					path1.mkdir();	  // 실제 폴더를 만들어 주는 메서드
				}
				
				// 파일을 만들어 보자 ==> 예)홍실동_파일명
				String reFileName = package_no = "_" + fileName;
				
				package_file.renameTo(new File(homedir + "/" + reFileName));
				
				// 실제로 DB에 저장되는 파일 이름.
				// "/2024-05-28/홍길동_파일명" 으로 저장 예정
				String fileDBName = "/" + year + "_" + month + "_" + day + "/" + reFileName;
				
				dto.setPackage_file(fileDBName);
				
				
			}
	      
	       	  dto.setPackage_merchandise_no(package_no);
		      dto.setPackage_title(package_title);
		      dto.setPackage_date(package_age);
		      dto.setPackage_start_date(package_start);
		      dto.setPackage_end_date(package_end);
		      dto.setRoom_type(package_type);
		      dto.setOption_type(package_option);
		      dto.setPackage_cont(package_details);
		      dto.setPackage_price(package_price);
		      
		      HotelTotalDAO dao = HotelTotalDAO.getInstance();
		      
		     int check = dao.modifypackage(dto);
		      
		      PrintWriter out = response.getWriter();
		      
		      if(check > 0) {
					out.println("<script>");
					out.println("alert('자료실 업로드 게시글 수정 성공!!')");
					out.println("location.href='admin_package_list'"); // 페이지 새로 고침
					out.println("</script>");
				} else {
					out.println("<script>");
					out.println("alert('자료실 업로드 게시글 수정 실패~~~')");
					out.println("history.back()");
					out.println("</script>");
				}
	      
	    
		return null;
	}

}
