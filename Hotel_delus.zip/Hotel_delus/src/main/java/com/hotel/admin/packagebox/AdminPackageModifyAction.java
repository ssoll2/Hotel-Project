package com.hotel.admin.packagebox;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelDTO;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.PackageDTO;

public class AdminPackageModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		String package_no = request.getParameter("no").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		PackageDTO cont = dao.packageContent(package_no);
		
		request.setAttribute("cont", cont);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("/WEB-INF/views/admin/package/admin_package_modify.jsp");
				
		return forward;
	}

}
