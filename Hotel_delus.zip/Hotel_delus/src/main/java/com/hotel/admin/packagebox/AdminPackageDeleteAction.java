package com.hotel.admin.packagebox;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.PackageDTO;

public class AdminPackageDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		String package_merchandise_no = request.getParameter("no").trim();
		
		PackageDTO cont = dao.packageContent(package_merchandise_no);
		
		String upload = "D:\\jsp_work\\Hotel_Delus\\src\\main\\webapp\\upload_images";
		
		String fileName = cont.getPackage_file();
		
		PrintWriter out = response.getWriter();
		
		int check = dao.deletePackage(package_merchandise_no);
		
		if(fileName !=null) {
			// 첨부파일이 존재하는 경우
			File file = new File(upload + fileName);
			
			file.delete(); // 파일을 제거하는 메서드
		}
		
		if(check > 0) {
			
			
			if(check > 0) {
				out.println("<script>");
				out.println("alert('자료실 게시판 게시글 삭제 성공!!')");
				out.println("location.href='admin_package_list'"); // 페이지 새로 고침
				out.println("</script>");
			} else {
				out.println("<script>");
				out.println("alert('자료실 업로드 게시글 석제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		
		}
		
		return null;
	}

}
