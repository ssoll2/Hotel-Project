package com.hotel.packagebox;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.PackageReservateDTO;

public class PackageReservateOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();

	    HotelUserDTO cont = (HotelUserDTO) session.getAttribute("dto");
	    
	    String package_reservate_user_no = cont.getHotel_user_no();
	    
	    String package_title = request.getParameter("package_title").trim();
		int package_price = Integer.parseInt(request.getParameter("package_price"));
		int package_headcount = Integer.parseInt(request.getParameter("package_headcount"));
		String package_check_in = request.getParameter("package_check_in").trim();
		String package_check_in_time = request.getParameter("package_check_in_time").trim();
		String package_check_out = request.getParameter("package_check_out").trim();
		String package_check_out_time = request.getParameter("package_check_out_time").trim();

		
		SimpleDateFormat sdft = new SimpleDateFormat("yyMMdd-HHmmss-");
		Calendar c1 = Calendar.getInstance();
		String date = sdft.format(c1.getTime());
		
		String reservate_no = date + package_title;

		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		PackageReservateDTO dto = new PackageReservateDTO();
		
		dto.setPackage_reservate_no(reservate_no);
		dto.setPackage_reservate_room_price(package_price);
		dto.setPackage_reservate_user_no(package_reservate_user_no);
		dto.setPackage_reservate_headcount(package_headcount);
		dto.setPackage_check_in_date(package_check_in);
		dto.setPackage_check_in_hour(package_check_in_time);
		dto.setPackage_check_out_date(package_check_out);
		dto.setPackage_check_out_hour(package_check_out_time);
		
		int check = dao.PackageReservateInsert(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0 ) {
			out.println("<script>");
			out.println("alert('예약 완료')");
			out.println("location.href='main'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('오류')");
			out.println("history.back()");
			out.println("</script>");
		}
		return null;
	}

}
