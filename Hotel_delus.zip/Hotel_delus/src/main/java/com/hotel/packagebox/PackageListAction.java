package com.hotel.packagebox;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.PackageDTO;

public class PackageListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		List<PackageDTO> list = dao.getPackageList();
		
		request.setAttribute("List", list);

		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		forward.setPath("/WEB-INF/views/public/package/package_list.jsp");

		return forward;
	}

}
