package com.hotel.model;

public class PackageReservateDTO {

	private String package_reservate_no;        
	private int package_reservate_room_price ;    
	private String package_reservate_user_no;   
	private int package_reservate_headcount;                  
	private String package_reservate_date;                    
	private String package_check_in_date;                
	private String package_check_in_hour;            
	private String package_check_out_date;        
	private String package_check_out_hour ;
	
	public String getPackage_reservate_no() {
		return package_reservate_no;
	}
	public void setPackage_reservate_no(String package_reservate_no) {
		this.package_reservate_no = package_reservate_no;
	}
	public int getPackage_reservate_room_price() {
		return package_reservate_room_price;
	}
	public void setPackage_reservate_room_price(int package_reservate_room_price) {
		this.package_reservate_room_price = package_reservate_room_price;
	}
	public String getPackage_reservate_user_no() {
		return package_reservate_user_no;
	}
	public void setPackage_reservate_user_no(String package_reservate_user_no) {
		this.package_reservate_user_no = package_reservate_user_no;
	}
	public int getPackage_reservate_headcount() {
		return package_reservate_headcount;
	}
	public void setPackage_reservate_headcount(int package_reservate_headcount) {
		this.package_reservate_headcount = package_reservate_headcount;
	}
	public String getPackage_reservate_date() {
		return package_reservate_date;
	}
	public void setPackage_reservate_date(String package_reservate_date) {
		this.package_reservate_date = package_reservate_date;
	}
	public String getPackage_check_in_date() {
		return package_check_in_date;
	}
	public void setPackage_check_in_date(String package_check_in_date) {
		this.package_check_in_date = package_check_in_date;
	}
	public String getPackage_check_in_hour() {
		return package_check_in_hour;
	}
	public void setPackage_check_in_hour(String package_check_in_hour) {
		this.package_check_in_hour = package_check_in_hour;
	}
	public String getPackage_check_out_date() {
		return package_check_out_date;
	}
	public void setPackage_check_out_date(String package_check_out_date) {
		this.package_check_out_date = package_check_out_date;
	}
	public String getPackage_check_out_hour() {
		return package_check_out_hour;
	}
	public void setPackage_check_out_hour(String package_check_out_hour) {
		this.package_check_out_hour = package_check_out_hour;
	}
	
	
	
	
}
