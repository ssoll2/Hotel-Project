package com.hotel.mypage.qna;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelUserDTO;

public class UserQnaRegistAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkUserDTO(request, response);
		
		HttpSession session = request.getSession();

	    HotelUserDTO cont = (HotelUserDTO) session.getAttribute("dto");
	    
	    String user_id = cont.getHotel_user_id();

	    request.setAttribute("user_id", user_id);
	    request.setAttribute("cont", cont);
		
	    ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/mypage/qna/user_qna_register.jsp");
			
		return forward;
	}

}
