package com.hotel.mypage.qna;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.QnaBoardDTO;

public class UserQnaRegistOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkUserDTO(request, response);
		
		QnaBoardDTO dto = new QnaBoardDTO();
		
		String qna_type = request.getParameter("qna_type").trim();

		String qna_id = request.getParameter("user_id").trim();
		String qna_title = request.getParameter("qna_title").trim();
		String qna_cont = request.getParameter("qna_cont").trim();
		
		dto.setQna_board_type(qna_type);

		dto.setQna_board_write_id(qna_id);
		dto.setQna_board_title(qna_title);
		dto.setQna_board_cont(qna_cont);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.QnaRegister(dto);
	      
		PrintWriter out = response.getWriter();
  
		if(check > 0) {
			out.println("<script>");
			out.println("alert('완료')");
			out.println("location.href='user_qna_list'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
