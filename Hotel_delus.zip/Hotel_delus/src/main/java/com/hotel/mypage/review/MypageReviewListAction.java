package com.hotel.mypage.review;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.RoomReviewDTO;

public class MypageReviewListAction implements Action {

    @Override
    public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

       StaticArea.checkUserDTO(request, response);
       
       HttpSession session = request.getSession(); // 기존 세션 가져오기 (없으면 null 반환)
        HotelUserDTO user = (HotelUserDTO) session.getAttribute("dto");
        
        int rowsize = 10; // 한 페이지에 보여줄 리뷰 개수
        int block = 3;   // 페이지 블록 단위
        int totalRecord = 0; // 총 리뷰 개수
        int allPage = 0;     // 전체 페이지 수
        int page = 0;        // 현재 페이지 번호

        // 요청에서 현재 페이지 번호를 가져옴, 없으면 기본값 1로 설정
        if (request.getParameter("page") != null) {
         page = Integer.parseInt(request.getParameter("page").trim());
      } else {
         page = 1; // 처음으로 "내 예약 방 리스트" 페이지에 접속한 경우
      }


        int startNo = (page * rowsize) - (rowsize - 1); // 시작 번호 계산
        int endNo = (page * rowsize);                   // 끝 번호 계산
        
        int startBlock = (((page - 1) / block) * block) + 1; // 시작 블록 번호 계산
        int endBlock = (((page - 1) / block) * block) + block; // 끝 블록 번호 계산

        HotelTotalDAO dao = HotelTotalDAO.getInstance(); // DAO 인스턴스 가져오기

       
        String userId = user.getHotel_user_id();
        totalRecord = dao.getUserReviewCount(userId); // 사용자의 리뷰 총 개수 가져오기
        allPage = (int) Math.ceil(totalRecord / (double) rowsize); // 전체 페이지 수 계산
        
        System.out.println(userId);
        

        if (endBlock > allPage) {
            endBlock = allPage;
        }

        boolean is_Search = false; // 검색 여부 (기본값: false)
        List<RoomReviewDTO> list = dao.userReviewList(userId, page, rowsize); // 사용자의 리뷰 리스트 가져오기

        // 요청 속성에 값 설정
        request.setAttribute("page", page);
        request.setAttribute("rowsize", rowsize);
        request.setAttribute("block", block);
        request.setAttribute("totalRecord", totalRecord);
        request.setAttribute("allPage", allPage);
        request.setAttribute("startNo", startNo);
        request.setAttribute("endNo", endNo);
        request.setAttribute("startBlock", startBlock);
        request.setAttribute("endBlock", endBlock);
        request.setAttribute("List", list);
        request.setAttribute("is_Search", is_Search);
        
        System.out.println("userId: " + userId);
        System.out.println("page: " + page);
        System.out.println("rowsize: " + rowsize);
        System.out.println("totalRecord: " + totalRecord);
        System.out.println("list: " + list);

        ActionForward forward = new ActionForward();
        forward.setRedirect(false);
        forward.setPath("/WEB-INF/views/mypage/review/mypage_review_list.jsp");
        
        return forward;
    }
}
