package com.hotel.mypage;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelUserDTO;

public class MypageMainAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
	   
	   StaticArea.checkUserDTO(request, response);
      
       HttpSession session = request.getSession();

       HotelUserDTO cont = (HotelUserDTO) session.getAttribute("dto");
       System.out.println("cont = " + cont);
       
       String user_id = cont.getHotel_user_id();
       System.out.println("user_id = " + user_id);
       
       String user_name = cont.getHotel_user_name();
       String user_email = cont.getHotel_user_email();
       String user_rank = cont.getHotel_user_rank();
      
       request.setAttribute("cont", cont);
       request.setAttribute("user_name", user_name);
       request.setAttribute("user_email", user_email);
       request.setAttribute("user_rank", user_rank);
       
      ActionForward forward = new ActionForward();

      forward.setPath("/WEB-INF/views/mypage/mypage_main.jsp");

      return forward;
   }

}
