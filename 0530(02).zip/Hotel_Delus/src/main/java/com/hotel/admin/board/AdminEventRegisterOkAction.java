package com.hotel.admin.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.EventDTO;
import com.hotel.model.HotelTotalDAO;


public class AdminEventRegisterOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String event_board_title = request.getParameter("event_board_title").trim();
		String event_board_cont = request.getParameter("event_board_cont").trim();
		String event_board_start_date = request.getParameter("event_board_start_date").trim();
		String event_board_end_date = request.getParameter("event_board_end_date").trim();
		String event_board_file = request.getParameter("event_board_file").trim();
		
		
		EventDTO dto = new EventDTO();
		
		dto.setEvent_board_title(event_board_title);
		dto.setEvent_board_cont(event_board_cont);
		dto.setEvent_board_start_date(event_board_start_date);
		dto.setEvent_board_end_date(event_board_end_date);
		dto.setEvent_board_file(event_board_file);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.insertAdminEvent(dto);
		
		if (check > 0) {
			PrintWriter out = response.getWriter();
			
			out.println("<script>");
			out.println("alert('이벤트에 등록되었습니다.')");
			out.println("location.href='admin_event_list'");
			out.println("</script>");
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('이벤트 글 등록에 실패했습니다. 입력한 정보를 다시한번 확인하세요.')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}
		
		return null;
	}

}
