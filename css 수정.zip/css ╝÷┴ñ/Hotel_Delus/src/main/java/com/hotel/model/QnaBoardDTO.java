package com.hotel.model;

public class QnaBoardDTO {

	private int qna_board_no;
	private String qna_board_type;
	private String qna_board_write_id;
	private String qna_board_title;
	private String qna_board_cont;
	private String qna_board_reply;
	private String qna_request_date;
	private boolean qna_board_status;
	
	public int getQna_board_no() {
		return qna_board_no;
	}
	public void setQna_board_no(int qna_board_no) {
		this.qna_board_no = qna_board_no;
	}
	public String getQna_board_type() {
		return qna_board_type;
	}
	public void setQna_board_type(String qna_board_type) {
		this.qna_board_type = qna_board_type;
	}
	public String getQna_board_write_id() {
		return qna_board_write_id;
	}
	public void setQna_board_write_id(String qna_board_write_id) {
		this.qna_board_write_id = qna_board_write_id;
	}
	public String getQna_board_title() {
		return qna_board_title;
	}
	public void setQna_board_title(String qna_board_title) {
		this.qna_board_title = qna_board_title;
	}
	public String getQna_board_cont() {
		return qna_board_cont;
	}
	public void setQna_board_cont(String qna_board_cont) {
		this.qna_board_cont = qna_board_cont;
	}
	public String getQna_board_reply() {
		return qna_board_reply;
	}
	public void setQna_board_reply(String qna_board_reply) {
		this.qna_board_reply = qna_board_reply;
	}
	public String getQna_request_date() {
		return qna_request_date;
	}
	public void setQna_request_date(String qna_request_date) {
		this.qna_request_date = qna_request_date;
	}
	public boolean isQna_board_status() {
		return qna_board_status;
	}
	public void setQna_board_status(boolean qna_board_status) {
		this.qna_board_status = qna_board_status;
	}
	
	
	
}
