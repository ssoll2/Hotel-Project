package com.hotel.admin.ame;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.AmenitieDTO;
import com.hotel.model.HotelTotalDAO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class AdminAmeModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
			AmenitieDTO dto = new AmenitieDTO();
			
			String saveFolder = "D:\\jsp_work\\Hotel_Delus\\src\\main\\webapp\\upload_images";
			
			int fileSize = 10 * 1024 * 1024;
			
			 MultipartRequest multi = new MultipartRequest(
			            request,       // 일반적인 request 객체
			            saveFolder,    // 첨부파일이 저장될 경로
			            fileSize,      // 업로드할 첨부파일의 최대 크기
			            "UTF-8",      // 문자 인코딩 방식
			            new DefaultFileRenamePolicy());   // 첨부파일의 이름이 같은 경우 중복이 안되게 설정
			 	int nowPage = Integer.parseInt(multi.getParameter("page").trim());
			 	
			    String ame_title = multi.getParameter("ame_title").trim();
				boolean ame_status = Boolean.parseBoolean(multi.getParameter("ame_status").trim());
				String ame_open = multi.getParameter("ame_open").trim();
				String ame_close = multi.getParameter("ame_close").trim();		
				int ame_price = Integer.parseInt(multi.getParameter("ame_price").trim());
				String ame_type = multi.getParameter("ame_type").trim();
				String ame_cont = multi.getParameter("ame_cont").trim();
				
				File ame_file = multi.getFile("ame_file");
				
				
				if(ame_file != null) {
					String fileName = ame_file.getName();
					System.out.println("fileName = " + fileName);
					
					Calendar cal = Calendar.getInstance();
					int year = cal.get(Calendar.YEAR);
					int month = cal.get(Calendar.MONTH) + 1;
					int day = cal.get(Calendar.DAY_OF_MONTH);
					
					String homedir = saveFolder + "/" + year + "-" + month + "-" + day;
					
					File path = new File(homedir);
					
					if(!path.exists()) {
						path.mkdir();
					}
					String reFileName = "event_" + fileName;
					
					ame_file.renameTo(new File(homedir + "/" + reFileName));
					
					String fileDBName = year + "-" + month + "-" + day + "/" + reFileName;
					
					dto.setAmenities_file(fileDBName);
							
				}
			
			dto.setAmenities_title(ame_title);
			dto.setAmenities_status(ame_status);
			dto.setAmenities_open(ame_open);
			dto.setAmenities_close(ame_close);
			dto.setAmenities_price(ame_price);
			dto.setAmenities_type(ame_type);
			dto.setAmenities_cont(ame_cont);
			
			
			HotelTotalDAO dao = HotelTotalDAO.getInstance();
			
			int check = dao.updateAdminAme(dto);
			
			PrintWriter out = response.getWriter();
			
			if(check > 0) {
				out.println("<script>");
				out.println("alert('수정 성공')");
				out.println("location.href='admin_ame_content?type="+ame_type+"&page="+nowPage+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('수정 실패')");
				out.println("history.back()");
				out.println("</script>");
			}
			
			return null;
	}

}
