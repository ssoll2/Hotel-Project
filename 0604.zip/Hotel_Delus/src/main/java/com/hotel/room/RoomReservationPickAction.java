package com.hotel.room;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.ReservateDTO;
import com.hotel.model.RoomDTO;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/*import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;*/


public class RoomReservationPickAction implements Action {

    @Override
    public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Map<LocalDate, RoomDTO> reservedRooms = new HashMap<>();
        
        String adult = request.getParameter("adult").trim();
        String child = request.getParameter("child").trim();
        
        String check_in_date = request.getParameter("checkin_date").trim();
        String check_out_date = request.getParameter("checkout_date").trim();
        
        LocalDate checkstartDate = LocalDate.parse(check_in_date);
        LocalDate checkendDate = LocalDate.parse(check_out_date);
        
        // ReservateDTO 객체 생성 및 설정
        ReservateDTO cont = new ReservateDTO();
        cont.setCheck_in_date(checkstartDate);
        cont.setCheck_out_date(checkendDate);
        
        // 각 날짜에 대한 예약된 객실 정보를 Map에 추가
        for (LocalDate date = checkstartDate; date.isBefore(checkendDate); date = date.plusDays(1)) {
            RoomDTO dto = new RoomDTO();
            dto.setAdult(adult);
            dto.setChild(child);
            // 예약된 객실 정보를 Map에 추가
            reservedRooms.put(date, dto);
        }
        
        // ReservateDTO 객체에 예약된 객실 정보 설정
		/* cont.setReservedRooms(reservedRooms); */
        
        // 필요한 작업을 수행하고 다음 액션으로 전달하는 코드를 추가할 수 있습니다.

        return null;
    }

}