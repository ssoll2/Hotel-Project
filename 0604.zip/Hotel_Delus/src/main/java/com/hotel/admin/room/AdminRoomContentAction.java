package com.hotel.admin.room;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomDTO;

public class AdminRoomContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String room_pk_no = request.getParameter("no").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		RoomDTO cont = dao.getRoomContent(room_pk_no);
		
		request.setAttribute("Cont", cont);
		
		ActionForward forward = new ActionForward();

	    forward.setPath("/WEB-INF/views/admin/room/admin_room_content.jsp");

	    return forward;
	}

}
