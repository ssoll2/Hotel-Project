/*메인 공지사항*/

function fetchNoticeList() {
    $.ajax({
        type: "GET",
        url: "print_notice",
        dataType: "json",
        success: function(response) {
            if (response.length === 0) {
                console.log("공지사항이 없습니다.");
            } else {
                printNotices(response);
            }
        },
        error: function(xhr, status, error) {
            console.error("에러:", error);
            console.error("상태:", status);
            console.error("응답:", xhr.responseText);
        }
    });
}

function printNotices(notices) {
    var noticesHtml = "";
	noticesHtml += "<img src='IMG/room2.jpg'>";
    $.each(notices, function(index, notice) {
        noticesHtml += "<div class='notice_item'>";
        noticesHtml += "<a href='main_notice_content?no=" + notice.no + "'>"+ "<div class='notice_title'>" + notice.title + "</div>" + "</a>";
        noticesHtml += "<div class='notice_date'>" + notice.date.substring(0, 10) + "</div>";
        noticesHtml += "</div>";
    });
    $(".section5 .notice_content").empty().append(noticesHtml);

// 마우스 호버 효과가 올바른 요소에 적용되도록 확인합니다
    $('.section5 .notice_content div').hover(function() {
        $(this).css("text-decoration", "underline");
    }, function() {
        $(this).css('text-decoration', 'none');
		
    });
}




// 문서가 준비되면 함수를 호출하여 공지사항을 가져옵니다
$(document).ready(function() {
    fetchNoticeList();
});


/*이벤트*/
function fetchEventList() {
    $.ajax({
        type: "GET",
        url: "print_event",
        dataType: "json",
        success: function(response) {
            if (response.length === 0) {
                console.log("이벤트가 없습니다.");
            } else {
                printEvents(response);
            }
        },
        error: function(xhr, status, error) {
            console.error("에러:", error);
            console.error("상태:", status);
            console.error("응답:", xhr.responseText);
        }
    });
}

function printEvents(events) {
    var eventsHtml = "";
    $.each(events, function(index, event) {
        eventsHtml += "<div class='event_item'>";
        eventsHtml += "<img src='file'>";
        eventsHtml += "<a href='main_event_content?no=" + event.no + "'>"+ "<div class='event_title'>" + event.title + "</div>" + "</a>";
        eventsHtml += "<div class='event_date'>" + event.date.substring(0, 10) + "</div>";
        eventsHtml += "</div>";
    });
    $(".section4 .event_img_bg").empty().append(eventsHtml);

// 마우스 호버 효과가 올바른 요소에 적용되도록 확인합니다
    $('.section4 .event_content div').hover(function() {
        $(this).css("text-decoration", "underline");
    }, function() {
        $(this).css('text-decoration', 'none');
		
    });
}

$(document).ready(function() {
    fetchEventList();
});


