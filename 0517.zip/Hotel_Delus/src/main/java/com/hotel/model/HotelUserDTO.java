package com.hotel.model;

public class HotelUserDTO {

}
