-- 호텔 테이블
create table hotel(
hotel_business_no varchar(50) primary key,       -- 사업자 번호
hotel_name varchar(50) not null,                 -- 호텔 이름
hotel_ceo_name varchar(30) not null,              -- 호텚 대표 이름
hotel_location varchar(100),                    -- 호텔 위치
hotel_phone varchar(50),                          -- 호텔 전화번호
hotel_acount varchar(100) unique not null      -- 호텔 계좌번호
);
-- 호텔 유저 테이블
create table hotel_user(
hotel_user_no varchar(100) primary key,         -- 회원 번호
hotel_user_name varchar(100) not null,         -- 회원 이름
hotel_user_id varchar(50) Unique not null,            -- 회원 id
hotel_user_password varchar(50) not null,      -- 회원 password
hotel_user_phone varchar(50) not null,         -- 회원 연락처
hotel_user_email varchar(80) Unique,               -- 회원 이메일
hotel_user_rank varchar(100),               -- 회원 등급
hotel_user_regdate date,                  -- 회원 가입일
hotel_user_payment_info varchar(100) not null   -- 회원 결제정보
);
-- 객실 정보 테이블
create table room_info(
   room_type varchar(50) primary key,                -- PK) 객실 타입 (Delus Room , Spa Delus Room, Pool Delus Room, Pool Premier Room, Spa Premier Room, Pool Suite Room) 
   room_total int not null,                          -- 객실 총수 (20, 25,25, 50, 70, 100) total 240
   room_size float not null,                         -- 객실 면적
   room_maximun int not null,                        -- 객실 정원
   room_price int not null,                          -- 객실 가격
   room_cont varchar(500),                          -- 객실 상세정보
   room_file varchar(2000),                          -- 객실 사진
   room_facilities varchar(300)                      -- 객실 편의 시설
);

insert into room_info values("Delus Room",50,"16.94",2,350000, default , default ,"전기포트,스타일러,미니바,금고,욕실");
insert into room_info values("Spa Delus Room",30,"19.17",3,500000, default, default , "전기포트, 스타일러, 미니바, 금고, 욕실, 개별스파");
insert into room_info values("Pool Delus Room",30,"20.18",3,500000, default, default , "전기포트, 스타일러, 미니바, 금고, 욕실, 개별수영장, 캡슐커피머신");
insert into room_info values("Pool Premier Room",26,"25.18",7,890000, default, default , "전기포트, 스타일러, 미니바, 금고, 욕실, 개별수영장, 캡슐커피머신, 안마의자");
insert into room_info values("Spa Premier Room",26,"25.18",7,950000, default, default , "전기포트, 스타일러, 미니바, 금고, 욕실, 개별스파, 캡슐커피머신, 안마의자");
insert into room_info values("Pool Suite Room",24,"30.18",5,1590000, default, default , "전기포트, 스타일러, 미니바, 금고, 욕실, 개별수영장, 웰컴드링크, 캡슐커피머신, 공기청정기, 안마의자, 블루투스 스피커");

select * from room_info;

create table room(
room_pk_no varchar(100) primary key,         -- 객실 고유번호
room_number varchar(100) not null,          -- 객실 호수
room_type varchar(50) not null,               -- 객실 타입         
room_reservate_status boolean default false,      -- 객실 예상 상태

 foreign key (room_type) references room_info (room_type) on delete cascade on update cascade
);
-- 객실 통합정보 테이블
create table hotel_amenities_info(
amenities_type varchar(100) primary key,      -- 부대시설 유형(스파시스, 갤러리)
amenities_price int not null,               -- 부대시설 가격
amenities_status boolean not null,            -- 부대시설 운영상태
amenities_opentime time,                  -- 부대시설 입장시간
amenities_closetime time,                  -- 부대시설 퇴장시장
amenities_file varchar(2000),               -- 부대시설 사진
amenities_title varchar(500),               -- 부대시설 제목
amenities_cont varchar(500)                  -- 부대시설 상세내용
);

 -- 부대시설 예약 테이블
create table hotel_amenities_reservate(        
 res_amenities_no varchar(200) primary key,              -- 부대시설 고유번호
 amenities_type varchar(100),                     -- 부대시설 유형
 res_amenities_date datetime,                     -- 부대시설 예약날짜
 res_amenities_user_no varchar(100),               -- 부대시설 에약자

foreign key (amenities_type) references hotel_amenities_info(amenities_type) on update cascade,
foreign key (res_amenities_user_no) references hotel_user (hotel_user_no) on update cascade
);

 -- 예약 테이블
create table reservate(
reservate_no varchar(150) primary key,         -- 예약 번호
reservate_room_no varchar(100) not null,      -- 예약한 객실 번호
reservate_room_price varchar(80),            -- 예약한 객실 가격
reservate_user_no varchar(100) not null,      -- 예약한 고객 번호
reservate_headcount int,                  -- 예약한 인원 수
reservate_date date,                     -- 예약한 날짜
check_in_date varchar(100),                  -- 체크인 날짜
check_in_hour varchar(50),                  -- 체크인 시간
check_out_date varchar(100),               -- 체크아웃 날짜
check_out_hour varchar(50),                  -- 체크아웃 시간
payment_status boolean default false,         -- 결제 상태

foreign key (reservate_room_no) references room (room_pk_no) on update cascade,
foreign key (reservate_user_no) references hotel_user (hotel_user_no) on update cascade
);
 -- 객실 구매내역 테이블
create table purchase_history(
purchase_no varchar(150) primary key,               -- 구매내역 번호
purchase_user_no varchar(100),                     -- 구매회원 번호(FK)
purchase_room_no varchar(100),                     -- 구매완료 객실 번호(FK)
purchase_room_price varchar(80),                  -- 예약 번호(FK)
pur_reservate_no varchar(150),                     -- 객실가격(FK)
purchase_date datetime,                           -- 구매일자
purchase_room_reivew_status boolean default false,      -- 객실 리뷰글 등록 상태

foreign key (pur_reservate_no) references reservate (reservate_no) on update cascade,
foreign key (purchase_room_no) references reservate (reservate_room_no) on update cascade,
foreign key (purchase_user_no) references reservate (reservate_user_no) on update cascade
);
  -- 관리자 패키지 생성 테이블
create table package(
package_merchandise_no varchar(100) primary key,      -- 패키지 상품 고유번호
package_title varchar(100),                     -- 패키지 상품 제목
package_cont varchar(500),                     -- 패키지 상품 상세내용
room_type varchar(200),                           -- 객실 유형
option_type varchar(200),                        -- 옵션 유형(조식, 디너)
package_start_date date,                        -- 패키지 시작기간
package_end_date date,                           -- 패키지 종료기간
package_date date,                              -- 게시일자
package_update date,                           -- 수정일자
package_file varchar(2000),                        -- 업로드 파일(사진)
package_purchase_no varchar(150),                  -- 구매내역 번호(FK)
package_purchase_status boolean default false,         -- 패키지 구매 상태
foreign key (package_purchase_no) references Purchase_history (purchase_no) on update cascade
);
 create table reservate_cancel_room(
   reservate_cancel_no varchar(150) primary key,         -- 취소 번호
    reservate_cancel_date datetime,                         -- 취소 날짜
    reservate_cancel_status boolean default false,         -- 취소 상태
    reservate_room varchar(100),                        -- 취소 처리된 방
    reservate_cancel_package_merchandise_no varchar(100),   -- 취소 처리된 패키지 번호
    
    foreign key (reservate_cancel_no) references reservate (reservate_room_no) on update cascade,
   foreign key (reservate_cancel_package_merchandise_no) references package (package_merchandise_no) on update cascade
 );
 -- 결제 테이블
create table hotel_payment(
payment_no varchar(100) primary key,            -- 결제 번호
payment_date date,                               -- 결제 일자
payment_amount varchar(100) not null,            -- 결제 금액
payment_method varchar(100) not null,            -- 결제 방법
pay_reservate_no varchar(150) not null,          -- 예약 번호(FK)
pay_status boolean default null,             -- 결제 상태

foreign key (pay_reservate_no) references reservate (reservate_no) on update cascade
);
 -- 호텔 관리자 테이블
create table admin(
admin_no varchar(100) primary key,                  -- 관리자 번호
admin_name varchar(100) not null,                  -- 관리자 이름
admin_major varchar(100) not null,                  -- 관리자 직책
admin_id varchar(50) not null,                     -- 관리자 아이디
admin_password varchar(50) not null,               -- 관리자 비밀번호
admin_phone varchar(50) not null                  -- 관리자 연락처
);
 -- 등급 테이블
create table ranked(
mileage_user_no varchar(50) not null,                 -- 적립 회원번호
mileage_date datetime default now(),                  -- 적립 일시
mileage_cont varchar(50) not null,                     -- 적립 내용
mileage_type varchar(50) not null,                     -- 적립(+), 차감(-) 구분
mileage_amount int not null,                           -- 적립 마일리지
mileage_status int not null,                           -- 현재 마일리지
mileage_grade varchar(50) not null                     -- 현재 등급
);
 -- 구매 객실 리뷰 테이블
create table room_review(
room_review_no varchar(50) primary key,               -- 리뷰 글 번호      
room_review_writer_id varchar(50),                  -- 리뷰 작성자 아이디
room_review_title varchar(100),                     -- 리뷰 글 제목
room_review_cont varchar(1000),                     -- 리뷰 글 내용
room_review_date date,                           -- 리뷰 글 등록날짜
room_review_update date,                        -- 리뷰 글 수정날짜
room_review_file varchar(500),                     -- 업로드 파일
room_review_hit int,                           -- 리뷰 글 조회수
room_review_purchase_no varchar(150),               -- 구매내역 번호(FK)

foreign key (room_review_purchase_no) references Purchase_history(purchase_no) on update cascade
);
 -- 문의하기 테이블
create table qna_board(                           
qna_board_no varchar(50) primary key,               -- 문의 글 번호
qna_board_type varchar(100),                     -- 문의 유형
qna_board_write_id varchar(50),                     -- 문의 작성자 아이디
qna_board_title varchar(100),                     -- 문의 제목
qna_board_cont varchar(1000),                     -- 문의 내용
qna_request_date datetime,                        -- 문의 요청 날짜
qna_board_status boolean default false               -- 문의 상태
);
 -- 공지사항 테이블
create table notice(
notice_board_no varchar(50) primary key,            -- 공지사항 글 번호
notice_board_title varchar(100),                  -- 공지사항 글 제목
notice_board_cont varchar(1000),                  -- 공지사항 글 내용
notice_board_date date,                           -- 공지사항 등록일시
notice_board_update date,                        -- 공지사항 수정일시
notice_board_hit int,                           -- 공지사항 조회수
notice_board_file varchar(500)                     -- 업로드 파일
);
 -- 이벤트 테이블
create table event(
event_board_no varchar(50) primary key,               -- 이벤트 글 번호
event_board_title varchar(100),                     -- 이벤트 글 제목
event_board_cont varchar(1000),                     -- 이벤트 글 내용
event_board_date date,                           -- 이벤트 등록일시
event_board_update date,                        -- 이벤트 수정일시
event_board_hit int,                           -- 이벤트 조회수
event_board_file varchar(500)                     -- 업로드 파일
);
 -- 관심 객실 테이블
create table favorite_room(
favorite_no int primary key,                     -- 관심 글 번호
favorite_room_no varchar(100),                     -- 관심 객실 등록한 회원번호
favorite_user_no varchar(100),                     -- 관심 객실 번호

foreign key (favorite_user_no) references hotel_user (hotel_user_no) on update cascade,
foreign key (favorite_room_no) references room (room_pk_no) on update cascade
);

-- 로그인 정보 테이블
create table log(
    log_date datetime not null default now(), -- 로그인 날짜
    log_user_no varchar(50) not null, -- 로그인 한 유저 번호
    log_user_id varchar(50) not null, -- 로그인 한 유저 아이디
    log_type varchar(50) not null -- 로그인 유형 (관리자, 유저)
);

commit;

