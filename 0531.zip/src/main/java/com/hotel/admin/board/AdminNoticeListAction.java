package com.hotel.admin.board;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.NoticeDTO;

public class AdminNoticeListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int totalRecord = 0;
		
		totalRecord = dao.getAdminNoticeCount();
		List<NoticeDTO> list = dao.AdminNoticeList();
		
		request.setAttribute("totalRecord", totalRecord);
		request.setAttribute("list", list);
		
		
		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/admin/board/admin_notice_list.jsp");
		
		
		
		return forward;
		
		
		
		
	}

}
