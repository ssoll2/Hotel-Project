package com.hotel.model;

public class AmenitieDTO {
	private String ame_type;	// 종류
	private int ame_price;		// 가격
	private boolean ame_status;	// 운영상태
	private String ame_open;	// 입장시간
	private String ame_close;	// 퇴장
	private String ame_title;	// 제목	
	private String ame_cont;	// 내용
	private String ame_file;	// 사진 파일(아직 구현 못해용)
	
	public String getAme_type() {
		return ame_type;
	}
	public void setAme_type(String ame_type) {
		this.ame_type = ame_type;
	}
	public int getAme_price() {
		return ame_price;
	}
	public void setAme_price(int ame_price) {
		this.ame_price = ame_price;
	}
	public boolean isAme_status() {
		return ame_status;
	}
	public void setAme_status(boolean ame_status) {
		this.ame_status = ame_status;
	}
	public String getAme_open() {
		return ame_open;
	}
	public void setAme_open(String ame_open) {
		this.ame_open = ame_open;
	}
	public String getAme_close() {
		return ame_close;
	}
	public void setAme_close(String ame_close) {
		this.ame_close = ame_close;
	}
	public String getAme_title() {
		return ame_title;
	}
	public void setAme_title(String ame_title) {
		this.ame_title = ame_title;
	}
	public String getAme_cont() {
		return ame_cont;
	}
	public void setAme_cont(String ame_cont) {
		this.ame_cont = ame_cont;
	}
	public String getAme_file() {
		return ame_file;
	}
	public void setAme_file(String ame_file) {
		this.ame_file = ame_file;
	}

}
