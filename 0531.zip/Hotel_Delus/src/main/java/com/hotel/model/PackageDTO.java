package com.hotel.model;

public class PackageDTO {
   private String package_merchandise_no;
   private String package_title;
   private String package_cont;
   private String room_type;
   private String option_type;
   private String package_start_date;
   private String package_end_date;
   private String package_date;
   private String package_update;
   private String package_file;
   private String package_purchase_no;
   private boolean package_purchase_status;
   private String package_price;
   
   
public String getPackage_merchandise_no() {
	return package_merchandise_no;
}
   
public void setPackage_merchandise_no(String package_merchandise_no) {
	this.package_merchandise_no = package_merchandise_no;
}
public String getPackage_title() {
	return package_title;
}
public void setPackage_title(String package_title) {
	this.package_title = package_title;
}
public String getPackage_cont() {
	return package_cont;
}
public void setPackage_cont(String package_cont) {
	this.package_cont = package_cont;
}
public String getRoom_type() {
	return room_type;
}
public void setRoom_type(String room_type) {
	this.room_type = room_type;
}
public String getOption_type() {
	return option_type;
}
public void setOption_type(String option_type) {
	this.option_type = option_type;
}
public String getPackage_start_date() {
	return package_start_date;
}
public void setPackage_start_date(String package_start_date) {
	this.package_start_date = package_start_date;
}
public String getPackage_end_date() {
	return package_end_date;
}
public void setPackage_end_date(String package_end_date) {
	this.package_end_date = package_end_date;
}
public String getPackage_date() {
	return package_date;
}
public void setPackage_date(String package_date) {
	this.package_date = package_date;
}
public String getPackage_update() {
	return package_update;
}
public void setPackage_update(String package_update) {
	this.package_update = package_update;
}
public String getPackage_file() {
	return package_file;
}
public void setPackage_file(String package_file) {
	this.package_file = package_file;
}
public String getPackage_purchase_no() {
	return package_purchase_no;
}
public void setPackage_purchase_no(String package_purchase_no) {
	this.package_purchase_no = package_purchase_no;
}
public boolean isPackage_purchase_status() {
	return package_purchase_status;
}
public void setPackage_purchase_status(boolean package_purchase_status) {
	this.package_purchase_status = package_purchase_status;
}
public String getPackage_price() {
	return package_price;
}
public void setPackage_price(String package_price) {
	this.package_price = package_price;
}
   
   
} 