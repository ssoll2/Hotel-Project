package com.hotel.admin.ame;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.AmenitieDTO;
import com.hotel.model.HotelTotalDAO;

public class AdminAmeSearchContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String ame_type = request.getParameter("type").trim();
		int page = Integer.parseInt(request.getParameter("page").trim());
		String field = request.getParameter("field").trim();
		String keyword = request.getParameter("keyword").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		AmenitieDTO dto = dao.getAdminAmeContent(ame_type);
		
		request.setAttribute("dto", dto);
		request.setAttribute("page", page);
		request.setAttribute("field", field);
		request.setAttribute("keyword", keyword);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/board/admin_ame_content.jsp");

		return forward;
		
	}

}
