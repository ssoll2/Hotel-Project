package com.hotel.admin.room;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;

public class AdminRoomRegisterAjaxAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      // roomType 파라미터를 받아오고, 값이 없으면 기본값으로 설정
      String roomType = request.getParameter("room_type");
      if (roomType == null || roomType.isEmpty()) {
         roomType = "Delus Room_S"; // 기본값 설정
      }

      // 예시 데이터: 각 객실 타입에 대한 객실 호수 목록
      int[] roomNumbers;
      switch (roomType) {
      case "Delus Room_S":
         roomNumbers = new int[] { 201, 202, 203, 204, 205, 206, 207, 208, 209, 210 };
         break;
      case "Delus Room_D":
         roomNumbers = new int[] { 211, 212, 213, 214, 215, 216, 217, 218, 219, 220 };
         break;
      case "Spa Delus Room":
         roomNumbers = new int[] { 301, 302, 303, 304, 305, 306, 307, 308, 309 };
         break;
      case "Pool Delus Room":
         roomNumbers = new int[] { 401, 402, 403, 404, 405, 406, 407, 408, 409 };
         break;
      case "Pool Premier Room":
         roomNumbers = new int[] { 501, 502, 503, 504, 505, 506, 507 };
         break;
      case "Spa Premier Room":
         roomNumbers = new int[] { 601, 602, 603, 604, 605, 606, 607 };
         break;
      case "Pool Suite Room":
         roomNumbers = new int[] { 701, 702, 703, 704, 705 };
         break;
      default:
         roomNumbers = new int[] {};
         break;
      }

      // JSON 배열 생성
      JSONArray jsonArray = new JSONArray();
      for (int roomNumber : roomNumbers) {
         jsonArray.add(roomNumber);
      }

   

      PrintWriter out = response.getWriter();
      
      // 공지사항 리스트를 JSON 형식으로 변환하여 클라이언트에 반환
      response.setContentType("application/json;charset=UTF-8");
      response.setCharacterEncoding("UTF-8");
      out.print(jsonArray.toJSONString());
      out.flush();

      return null; // AJAX 응답을 보내고 JSP 페이지로 포워드하지 않음
   }

}