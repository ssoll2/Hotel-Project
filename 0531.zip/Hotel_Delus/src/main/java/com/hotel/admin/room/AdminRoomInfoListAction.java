package com.hotel.admin.room;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;

public class AdminRoomInfoListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		List<RoomInfoDTO> list = dao.getRoomInfoList();
		

		request.setAttribute("List", list);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/room/admin_room_info_list.jsp");

		return forward;
	}

}
