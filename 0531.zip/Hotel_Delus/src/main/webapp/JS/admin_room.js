
$(document).ready(function() {
    $('#room_type').change(function() {
        var selectedRoomType = $(this).val();
        $.ajax({
            url: 'admin_room_register_ajax',
            type: 'GET',
            data: { room_type: selectedRoomType },
            success: function(datas) {
            var optionHtml = "<option value=''>-- Select Room Number --</option>";
            $.each(datas, function(index, data) {
               optionHtml += "<option value='" + data + "'>" + data + "</option>";
            })
            $("#room_number").html(optionHtml);
            },
            error: function(xhr, status, error) {
                console.error('Error fetching room numbers:', status, error);
            }
        });
    });

    $("#file").on('change', function() {
        var fileName = $(this).val().split('\\').pop();
        $(".upload-name").val(fileName);
    });
});